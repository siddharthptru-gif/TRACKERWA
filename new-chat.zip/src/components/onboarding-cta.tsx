import Link from "next/link";
import { Orbit, ArrowRight } from "lucide-react";

export function OnboardingCTA() {
  return (
    <div className="grid min-h-[70vh] place-items-center animate-fade-up">
      <div className="max-w-md text-center">
        <span className="mx-auto grid size-14 place-items-center rounded-2xl border border-accent/30 bg-accent/10 text-accent">
          <Orbit size={26} />
        </span>
        <h1 className="mt-5 font-display text-2xl font-bold tracking-tight">
          Set up your <span className="text-accent">Tracker 360</span>
        </h1>
        <p className="mt-2 text-sm leading-relaxed text-ink-3">
          Connect your JEE batch snapshot (manual import), set your targets and daily hours — the engine
          builds your chapters, revision cycles, backlog plan and today's schedule automatically.
        </p>
        <Link
          href="/onboarding"
          className="mt-6 inline-flex items-center gap-2 rounded-xl bg-accent px-6 py-3 text-sm font-semibold text-black transition hover:bg-accent-2"
        >
          Start 60-second setup <ArrowRight size={15} />
        </Link>
      </div>
    </div>
  );
}
