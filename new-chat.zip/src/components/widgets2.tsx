"use client";

import { useState, useTransition, type ReactNode } from "react";
import { useRouter } from "next/navigation";
import {
  Loader2, Star, MoreHorizontal, Play, Pause, CheckCircle2,
  ExternalLink, Zap, Download, Upload, Trash2, SplitSquareHorizontal,
  CalendarPlus, PencilLine, Plus, Megaphone,
} from "lucide-react";
import {
  updateLectureProgress, setChapterOverride, updatePracticeCounts,
  logTestFull, postponeTask, splitTask, resizeTask, deleteTask,
  setAvailableToday, planMyDay, applyKillerPlanAction, togglePromise,
  startSession, finishSession, saveTimetableBlocks, addCustomEvent,
  deleteCustomEvent, saveSettings, addErrorEntry, cycleErrorStatus,
  exportDataAction, importDataAction, resetTodayPlan, resetPlanner,
  resetProgress, saveAnnouncement,
} from "@/lib/actions2";
import { cn } from "@/components/ui";

const spin = (p: boolean) => (p ? <Loader2 size={13} className="animate-spin" /> : null);

const inputCls =
  "rounded-lg border border-line bg-panel-2 px-3 py-2 text-sm text-ink outline-none placeholder:text-ink-3 focus:border-accent/50 transition";
const labelCls = "mb-1 block text-[10px] font-medium uppercase tracking-[0.12em] text-ink-3";

/* ──────────────── lecture partial % control ──────────────── */

export function LecturePct({ id, pct }: { id: number; pct: number }) {
  const [pending, start] = useTransition();
  return (
    <div className="flex items-center gap-1">
      {[0, 25, 50, 75, 100].map((v) => (
        <button
          key={v}
          disabled={pending}
          onClick={() => start(async () => { await updateLectureProgress(id, v); })}
          className={cn(
            "rounded-md border px-1.5 py-0.5 text-[10px] tabular transition",
            Math.round(pct) === v
              ? "border-accent bg-accent/15 text-accent"
              : "border-line text-ink-3 hover:border-accent/40 hover:text-ink-2"
          )}
        >
          {pending && Math.round(pct) === v ? spin(true) : `${v}%`}
        </button>
      ))}
    </div>
  );
}

/* ──────────────── practice counts editor ──────────────── */

export function PracticeCounts({ id, solved, total }: { id: number; solved: number; total: number }) {
  const [val, setVal] = useState(String(solved));
  const [pending, start] = useTransition();
  return (
    <div className="flex items-center gap-1.5">
      <input
        value={val}
        inputMode="numeric"
        onChange={(e) => setVal(e.target.value.replace(/[^0-9]/g, ""))}
        className={cn(inputCls, "w-16 !py-1 !px-2 text-xs tabular")}
      />
      <span className="text-[10px] text-ink-3">/{total}</span>
      <button
        disabled={pending}
        onClick={() => start(async () => { await updatePracticeCounts(id, { solved: parseInt(val) || 0, correct: Math.round((parseInt(val) || 0) * 0.65) }); })}
        className="rounded-md border border-line px-2 py-1 text-[10px] font-medium text-ink-2 transition hover:border-accent/40 hover:text-accent"
      >
        {pending ? spin(true) : "Save"}
      </button>
    </div>
  );
}

/* ──────────────── task edit menu ──────────────── */

export function TaskMenu({ id, estMin }: { id: number; estMin: number }) {
  const [open, setOpen] = useState(false);
  const [pending, start] = useTransition();
  const run = (fn: () => Promise<void | string>) => start(async () => { await fn(); setOpen(false); });
  if (!open) {
    return (
      <button onClick={() => setOpen(true)} className="grid size-6 place-items-center rounded-md text-ink-3 transition hover:bg-panel-3 hover:text-ink-2" aria-label="task options">
        <MoreHorizontal size={14} />
      </button>
    );
  }
  const Item = ({ icon, children, onClick }: { icon: ReactNode; children: ReactNode; onClick: () => void }) => (
    <button onClick={onClick} className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-[11px] text-ink-2 transition hover:bg-panel-3">
      {icon}{children}
    </button>
  );
  return (
    <div className="absolute right-0 z-30 w-48 rounded-xl border border-line-2 bg-panel-2 p-1.5 shadow-2xl shadow-black/60">
      {pending && <div className="px-2 py-1 text-[10px] text-ink-3">Working…</div>}
      <Item icon={<CalendarPlus size={12} />} onClick={() => run(() => postponeTask(id, 1))}>Postpone +1 day</Item>
      <Item icon={<CalendarPlus size={12} />} onClick={() => run(() => postponeTask(id, 2))}>Postpone +2 days</Item>
      {estMin >= 30 && <Item icon={<SplitSquareHorizontal size={12} />} onClick={() => run(() => splitTask(id))}>Split into two halves</Item>}
      {[30, 60, 90].filter((m) => m !== estMin).map((m) => (
        <Item key={m} icon={<PencilLine size={12} />} onClick={() => run(() => resizeTask(id, m))}>Resize to {m} min</Item>
      ))}
      <Item icon={<Trash2 size={12} className="text-danger" />} onClick={() => run(() => deleteTask(id))}>Remove from plan</Item>
      <button onClick={() => setOpen(false)} className="mt-1 w-full rounded-md px-2 py-1 text-[10px] text-ink-3 hover:text-ink-2">Close</button>
    </div>
  );
}

export function PromiseStar({ id, promised }: { id: number; promised: boolean }) {
  const [pending, start] = useTransition();
  return (
    <button
      disabled={pending}
      onClick={() => start(async () => { await togglePromise(id); })}
      title={promised ? "Remove from today's promise" : "Add to today's promise"}
      className={cn(
        "grid size-6 shrink-0 place-items-center rounded-md transition",
        promised ? "text-warn" : "text-ink-3 hover:text-warn"
      )}
    >
      {pending ? spin(true) : <Star size={14} fill={promised ? "currentColor" : "none"} />}
    </button>
  );
}

/* ──────────────── replan with reduced hours ──────────────── */

export function ReplanForm({ current }: { current: number }) {
  const [hrs, setHrs] = useState(String(Math.round(current / 60)));
  const [msg, setMsg] = useState("");
  const [pending, start] = useTransition();
  return (
    <form
      className="flex flex-wrap items-center gap-2"
      onSubmit={(e) => {
        e.preventDefault();
        start(async () => {
          const m = (parseInt(hrs) || 0) * 60;
          const res = await setAvailableToday(Math.max(30, m));
          setMsg(res ?? "");
        });
      }}
    >
      <input value={hrs} inputMode="numeric" onChange={(e) => setHrs(e.target.value.replace(/[^0-9]/g, ""))} className={cn(inputCls, "w-16 !py-1.5 text-sm tabular")} />
      <span className="text-xs text-ink-3">hours available today</span>
      <button className="rounded-lg bg-accent px-3 py-1.5 text-xs font-semibold text-black transition hover:bg-accent-2">
        {pending ? spin(true) : "Replan my day"}
      </button>
      <button
        type="button"
        onClick={() => start(async () => { await planMyDay(); setMsg("Fresh plan generated for today."); })}
        className="rounded-lg border border-line px-3 py-1.5 text-xs font-medium text-ink-2 transition hover:border-accent/40 hover:text-accent"
      >
        Plan my day
      </button>
      {msg && <p className="w-full text-[11px] leading-relaxed text-accent">{msg}</p>}
    </form>
  );
}

/* ──────────────── backlog killer launcher ──────────────── */

export function KillerLauncher() {
  const [days, setDays] = useState(14);
  const [mode, setMode] = useState<"safe" | "balanced" | "aggressive">("balanced");
  const [pending, start] = useTransition();
  const [done, setDone] = useState(false);
  return (
    <div className="flex flex-wrap items-center gap-2">
      <div className="flex gap-1">
        {[7, 14, 21, 30].map((d) => (
          <button key={d} type="button" onClick={() => setDays(d)} className={cn("rounded-lg border px-2.5 py-1.5 text-[11px] tabular transition", days === d ? "border-accent bg-accent/12 text-accent" : "border-line text-ink-3 hover:text-ink-2")}>
            {d}d
          </button>
        ))}
      </div>
      <div className="flex gap-1">
        {(["safe", "balanced", "aggressive"] as const).map((m) => (
          <button key={m} type="button" onClick={() => setMode(m)} className={cn("rounded-lg border px-2.5 py-1.5 text-[11px] capitalize transition", mode === m ? "border-accent bg-accent/12 text-accent" : "border-line text-ink-3 hover:text-ink-2")}>
            {m}
          </button>
        ))}
      </div>
      <button
        onClick={() => start(async () => { await applyKillerPlanAction(days, mode); setDone(true); })}
        className="inline-flex items-center gap-1.5 rounded-lg bg-danger px-3.5 py-1.5 text-xs font-semibold text-black transition hover:opacity-85"
      >
        {pending ? spin(true) : <Zap size={12} />}
        {done ? "Killer plan applied" : `Kill backlog in ${days} days`}
      </button>
    </div>
  );
}

/* ──────────────── study mode (session runner) ──────────────── */

type StudyTask = { id: number; title: string; kind: string; estMin: number; subjectName: string | null; refType: string | null };

export function StudyMode({ tasks }: { tasks: StudyTask[] }) {
  const [active, setActive] = useState<StudyTask | null>(null);
  const [sessionId, setSessionId] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const [running, setRunning] = useState(false);
  const [pending, start] = useTransition();
  const [timer, setTimer] = useState<ReturnType<typeof setInterval> | null>(null);
  const router = useRouter();

  const begin = (t: StudyTask) => {
    start(async () => {
      const id = await startSession(t.id);
      setSessionId(id);
      setActive(t);
      setElapsed(0);
      setRunning(true);
      const iv = setInterval(() => setElapsed((e) => e + 1), 1000);
      setTimer(iv);
    });
  };
  const stopClock = () => { if (timer) clearInterval(timer); setTimer(null); };

  const finish = (outcome: "completed" | "partial" | "not", pct?: number) => {
    stopClock();
    const minutes = Math.max(1, Math.round(elapsed / 60));
    start(async () => {
      await finishSession(sessionId, { minutes, outcome, pct });
      setActive(null);
      setRunning(false);
      router.refresh();
    });
  };

  const fmt = (s: number) => `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;

  if (active) {
    return (
      <div className="rounded-2xl border border-accent/30 bg-gradient-to-b from-accent/[0.07] to-panel p-6 text-center animate-fade-up">
        <div className="text-[10px] font-semibold uppercase tracking-[0.18em] text-accent">Study mode · {active.subjectName ?? "Self study"}</div>
        <div className="mx-auto mt-3 max-w-md font-display text-lg font-semibold text-ink">{active.title}</div>
        <div className="mt-2 text-xs text-ink-3">estimated {active.estMin} min · minimal distractions</div>

        {active.refType === "lecture" && (
          <a
            href="https://www.pw.live/"
            target="_blank"
            rel="noreferrer"
            className="mt-4 inline-flex items-center gap-2 rounded-xl border border-line bg-panel-2 px-4 py-2.5 text-xs font-semibold text-ink transition hover:border-accent/50 hover:text-accent"
          >
            <ExternalLink size={13} /> Open class on PW
            <span className="text-[10px] font-normal text-ink-3">(opens pw.live · sign in with your own account)</span>
          </a>
        )}

        <div className="mt-6 font-mono text-5xl font-bold tabular text-ink">{fmt(elapsed)}</div>
        <div className="mt-1 text-[10px] uppercase tracking-[0.18em] text-ink-3">{running ? "live session" : "paused"}</div>

        <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
          <button
            onClick={() => {
              if (running) { stopClock(); setRunning(false); }
              else { const iv = setInterval(() => setElapsed((e) => e + 1), 1000); setTimer(iv); setRunning(true); }
            }}
            className="inline-flex items-center gap-1.5 rounded-xl border border-line bg-panel-2 px-4 py-2.5 text-xs font-semibold text-ink-2 transition hover:text-ink"
          >
            {running ? <Pause size={13} /> : <Play size={13} />} {running ? "Pause" : "Resume"}
          </button>
          <button onClick={() => finish("completed")} className="inline-flex items-center gap-1.5 rounded-xl bg-accent px-4 py-2.5 text-xs font-bold text-black transition hover:bg-accent-2">
            <CheckCircle2 size={13} /> Completed
          </button>
          {[25, 50, 75].map((p) => (
            <button key={p} onClick={() => finish("partial", p)} className="rounded-xl border border-warn/40 bg-warn/10 px-3 py-2.5 text-[11px] font-semibold text-warn transition hover:bg-warn/20">
              {p}% done
            </button>
          ))}
          <button onClick={() => finish("not")} className="rounded-xl border border-line px-3 py-2.5 text-[11px] font-medium text-ink-3 transition hover:text-ink-2">
            Not completed
          </button>
        </div>
        <p className="mx-auto mt-4 max-w-sm text-[11px] leading-relaxed text-ink-3">
          Honest tracking only: completion is recorded from what you declare here — never assumed from playback speed.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-1.5">
      {tasks.length === 0 && <p className="py-6 text-center text-xs text-ink-3">No tasks left today. Study mode unlocks when your plan has pending work.</p>}
      {tasks.map((t) => (
        <div key={t.id} className="flex items-center gap-3 rounded-xl border border-line bg-panel-2 px-3 py-2.5">
          <div className="min-w-0 flex-1">
            <div className="truncate text-[13px] font-medium text-ink">{t.title}</div>
            <div className="text-[10px] text-ink-3">{t.subjectName ?? "General"} · {t.estMin} min</div>
          </div>
          <button
            onClick={() => begin(t)}
            disabled={pending}
            className="inline-flex items-center gap-1.5 rounded-lg bg-accent px-3 py-1.5 text-[11px] font-semibold text-black transition hover:bg-accent-2"
          >
            {pending ? spin(true) : <Play size={11} />} Start
          </button>
        </div>
      ))}
    </div>
  );
}

/* ──────────────── test analysis form ──────────────── */

export function TestAnalysisForm({ id, max }: { id: number; max: number }) {
  const [f, setF] = useState({ marks: "", attempted: "", correct: "", incorrect: "", unattempted: "", conceptual: "", calculation: "", silly: "", time: "" });
  const [open, setOpen] = useState(false);
  const [pending, start] = useTransition();
  const num = (s: string) => (s === "" ? undefined : parseInt(s) || 0);
  const set = (k: keyof typeof f) => (v: string) => setF({ ...f, [k]: v.replace(/[^0-9]/g, "") });
  if (!open) {
    return (
      <button onClick={() => setOpen(true)} className="rounded-lg border border-accent/40 bg-accent/10 px-3 py-1.5 text-xs font-semibold text-accent transition hover:bg-accent/20">
        Log score + analysis
      </button>
    );
  }
  return (
    <form
      className="space-y-2.5"
      onSubmit={(e) => {
        e.preventDefault();
        start(async () => {
          await logTestFull(id, {
            marks: num(f.marks) ?? 0, attempted: num(f.attempted), correct: num(f.correct),
            incorrect: num(f.incorrect), unattempted: num(f.unattempted),
            conceptual: num(f.conceptual), calculation: num(f.calculation), silly: num(f.silly), time: num(f.time),
          });
        });
      }}
    >
      <div className="grid grid-cols-3 gap-2">
        <label><span className={labelCls}>Marks /{max}</span><input value={f.marks} onChange={(e) => set("marks")(e.target.value)} className={cn(inputCls, "w-full")} /></label>
        <label><span className={labelCls}>Attempted</span><input value={f.attempted} onChange={(e) => set("attempted")(e.target.value)} className={cn(inputCls, "w-full")} /></label>
        <label><span className={labelCls}>Correct</span><input value={f.correct} onChange={(e) => set("correct")(e.target.value)} className={cn(inputCls, "w-full")} /></label>
        <label><span className={labelCls}>Incorrect</span><input value={f.incorrect} onChange={(e) => set("incorrect")(e.target.value)} className={cn(inputCls, "w-full")} /></label>
        <label><span className={labelCls}>Unattempted</span><input value={f.unattempted} onChange={(e) => set("unattempted")(e.target.value)} className={cn(inputCls, "w-full")} /></label>
      </div>
      <div className="text-[10px] font-medium uppercase tracking-[0.12em] text-ink-3">Mistake breakdown</div>
      <div className="grid grid-cols-4 gap-2">
        <label><span className={labelCls}>Concept</span><input value={f.conceptual} onChange={(e) => set("conceptual")(e.target.value)} className={cn(inputCls, "w-full")} /></label>
        <label><span className={labelCls}>Calc</span><input value={f.calculation} onChange={(e) => set("calculation")(e.target.value)} className={cn(inputCls, "w-full")} /></label>
        <label><span className={labelCls}>Silly</span><input value={f.silly} onChange={(e) => set("silly")(e.target.value)} className={cn(inputCls, "w-full")} /></label>
        <label><span className={labelCls}>Time</span><input value={f.time} onChange={(e) => set("time")(e.target.value)} className={cn(inputCls, "w-full")} /></label>
      </div>
      <button className="rounded-lg bg-accent px-3.5 py-2 text-xs font-semibold text-black transition hover:bg-accent-2">
        {pending ? spin(true) : "Save analysis"}
      </button>
    </form>
  );
}

/* ──────────────── timetable editor ──────────────── */

export type BlockRow = { dayOfWeek: number; startMin: number; endMin: number; kind: string; label: string; fixed: boolean; focus: string };
const KINDS = ["sleep", "school", "college", "travel", "meal", "pw_class", "coaching", "study", "break", "exercise", "personal", "other"];
const minToHH = (m: number) => `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;
const hhToMin = (s: string) => { const [h, m] = s.split(":").map(Number); return (h || 0) * 60 + (m || 0); };

export function TimetableEditor({ initial }: { initial: BlockRow[] }) {
  const [rows, setRows] = useState<BlockRow[]>(initial);
  const [msg, setMsg] = useState("");
  const [pending, start] = useTransition();
  const set = (i: number, patch: Partial<BlockRow>) => setRows(rows.map((r, j) => (j === i ? { ...r, ...patch } : r)));
  return (
    <div className="space-y-2">
      {rows.map((r, i) => (
        <div key={i} className="flex flex-wrap items-center gap-1.5 rounded-xl border border-line bg-panel-2 p-2">
          <input value={r.label} onChange={(e) => set(i, { label: e.target.value })} className={cn(inputCls, "min-w-40 flex-1 !py-1.5 text-xs")} />
          <select value={r.kind} onChange={(e) => set(i, { kind: e.target.value })} className={cn(inputCls, "!py-1.5 text-xs capitalize")}>
            {KINDS.map((k) => <option key={k} value={k}>{k.replace("_", " ")}</option>)}
          </select>
          <input type="time" value={minToHH(r.startMin)} onChange={(e) => set(i, { startMin: hhToMin(e.target.value) })} className={cn(inputCls, "!py-1.5 text-xs [color-scheme:dark]")} />
          <span className="text-[10px] text-ink-3">→</span>
          <input type="time" value={minToHH(r.endMin)} onChange={(e) => set(i, { endMin: hhToMin(e.target.value) })} className={cn(inputCls, "!py-1.5 text-xs [color-scheme:dark]")} />
          <select value={r.fixed ? "fixed" : "flex"} onChange={(e) => set(i, { fixed: e.target.value === "fixed" })} className={cn(inputCls, "!py-1.5 text-xs")}>
            <option value="fixed">Fixed</option><option value="flex">Flexible</option>
          </select>
          {r.kind === "study" && (
            <select value={r.focus} onChange={(e) => set(i, { focus: e.target.value })} className={cn(inputCls, "!py-1.5 text-xs")}>
              {["any", "high", "medium", "low"].map((f) => <option key={f} value={f}>{f} focus</option>)}
            </select>
          )}
          <button type="button" onClick={() => setRows(rows.filter((_, j) => j !== i))} className="grid size-7 place-items-center rounded-md text-ink-3 transition hover:bg-danger/10 hover:text-danger" aria-label="remove block">
            <Trash2 size={13} />
          </button>
        </div>
      ))}
      <div className="flex flex-wrap items-center gap-2">
        <button
          type="button"
          onClick={() => setRows([...rows, { dayOfWeek: -1, startMin: 1080, endMin: 1200, kind: "study", label: "New block", fixed: false, focus: "any" }])}
          className="inline-flex items-center gap-1.5 rounded-lg border border-line px-3 py-2 text-xs font-medium text-ink-2 transition hover:border-accent/40 hover:text-accent"
        >
          <Plus size={12} /> Add block
        </button>
        <button
          onClick={() => start(async () => { setMsg(await saveTimetableBlocks(rows) ?? ""); })}
          className="rounded-lg bg-accent px-4 py-2 text-xs font-semibold text-black transition hover:bg-accent-2"
        >
          {pending ? spin(true) : "Save timetable"}
        </button>
      </div>
      {msg && <p className="text-[11px] leading-relaxed" style={{ color: msg.includes("Overlap") ? "var(--color-danger)" : "var(--color-accent)" }}>{msg}</p>}
      <p className="text-[11px] text-ink-3">Blocks apply to every day by default. Fixed blocks are never overwritten by the planner — study availability is computed around them.</p>
    </div>
  );
}

/* ──────────────── custom events ──────────────── */

export function EventForm() {
  const [f, setF] = useState({ date: "", label: "", kind: "holiday", hours: "0" });
  const [pending, start] = useTransition();
  return (
    <form
      className="flex flex-wrap items-end gap-2"
      onSubmit={(e) => {
        e.preventDefault();
        if (!f.date || !f.label) return;
        start(async () => {
          await addCustomEvent({ date: f.date, label: f.label, kind: f.kind, availableMinutes: (parseInt(f.hours) || 0) * 60 });
          setF({ date: "", label: "", kind: "holiday", hours: "0" });
        });
      }}
    >
      <label><span className={labelCls}>Date</span><input type="date" value={f.date} onChange={(e) => setF({ ...f, date: e.target.value })} className={cn(inputCls, "[color-scheme:dark]")} /></label>
      <label className="min-w-40 flex-1"><span className={labelCls}>Event</span><input value={f.label} onChange={(e) => setF({ ...f, label: e.target.value })} placeholder="Family function, sick day…" className={cn(inputCls, "w-full")} /></label>
      <label><span className={labelCls}>Type</span>
        <select value={f.kind} onChange={(e) => setF({ ...f, kind: e.target.value })} className={inputCls}>
          {["holiday", "sick", "travel", "function", "school_exam", "rest"].map((k) => <option key={k} value={k}>{k.replace("_", " ")}</option>)}
        </select>
      </label>
      <label><span className={labelCls}>Study hrs that day</span><input value={f.hours} inputMode="numeric" onChange={(e) => setF({ ...f, hours: e.target.value.replace(/[^0-9]/g, "") })} className={cn(inputCls, "w-20")} /></label>
      <button className="rounded-lg bg-accent px-3.5 py-2 text-xs font-semibold text-black transition hover:bg-accent-2">{pending ? spin(true) : "Add"}</button>
    </form>
  );
}

export function DeleteEvent({ id }: { id: number }) {
  const [pending, start] = useTransition();
  return (
    <button onClick={() => start(async () => { await deleteCustomEvent(id); })} className="grid size-7 place-items-center rounded-md text-ink-3 transition hover:bg-danger/10 hover:text-danger" aria-label="delete event">
      {pending ? spin(true) : <Trash2 size={13} />}
    </button>
  );
}

/* ──────────────── settings form ──────────────── */

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export function SettingsForm({ initial }: {
  initial: {
    planningMode: string; planningStyle: string; playbackSpeed: number; motivation: boolean;
    revisionIntervals: string; weeklyMinutes: Record<string, number>; priorityOrder: string;
    paceLectures: number; paceQuestions: number; paceRevisions: number; paceBacklog: number;
    studentType: string;
  };
}) {
  const [f, setF] = useState(initial);
  const [saved, setSaved] = useState(false);
  const [pending, start] = useTransition();
  const Sel = ({ k, options, label }: { k: "planningMode" | "planningStyle" | "studentType"; options: [string, string][]; label: string }) => (
    <label className="block">
      <span className={labelCls}>{label}</span>
      <select value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} className={cn(inputCls, "w-full")}>
        {options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
      </select>
    </label>
  );
  return (
    <form
      className="space-y-4"
      onSubmit={(e) => {
        e.preventDefault();
        start(async () => {
          await saveSettings({
            planningMode: f.planningMode, planningStyle: f.planningStyle,
            playbackSpeed: f.playbackSpeed, motivation: f.motivation,
            revisionIntervals: f.revisionIntervals, weeklyMinutes: JSON.stringify(f.weeklyMinutes),
            priorityOrder: f.priorityOrder,
            paceLectures: f.paceLectures, paceQuestions: f.paceQuestions,
            paceRevisions: f.paceRevisions, paceBacklog: f.paceBacklog,
            studentType: f.studentType,
          });
          setSaved(true);
        });
      }}
    >
      <div className="grid grid-cols-2 gap-3">
        <Sel k="studentType" label="Student type" options={[["school", "Regular School"], ["dummy", "Dummy School"], ["dropper", "Dropper"], ["college", "College + Prep"], ["self", "Self-study"], ["other", "Other"]]} />
        <Sel k="planningMode" label="Planning mode" options={[["hybrid", "Hybrid (suggest + you decide)"], ["auto", "Auto (engine plans)"], ["manual", "Manual (you plan)"]]} />
        <Sel k="planningStyle" label="Planning style" options={[["balanced", "Balanced"], ["backlog", "Backlog focused"], ["current", "Current batch focused"], ["revision", "Revision focused"], ["practice", "Practice focused"], ["exam", "Exam focused"]]} />
        <label className="block">
          <span className={labelCls}>Preferred lecture speed</span>
          <select value={String(f.playbackSpeed)} onChange={(e) => setF({ ...f, playbackSpeed: parseFloat(e.target.value) })} className={cn(inputCls, "w-full")}>
            {[0.75, 1, 1.25, 1.5, 1.75, 2, 2.5, 3].map((s) => <option key={s} value={s}>{s}x</option>)}
          </select>
        </label>
        <label className="block">
          <span className={labelCls}>Revision intervals (days, comma-separated)</span>
          <input value={f.revisionIntervals} onChange={(e) => setF({ ...f, revisionIntervals: e.target.value.replace(/[^0-9,]/g, "") })} className={cn(inputCls, "w-full tabular")} />
        </label>
        <label className="flex items-end gap-2 pb-2">
          <input type="checkbox" checked={f.motivation} onChange={(e) => setF({ ...f, motivation: e.target.checked })} className="size-4 accent-emerald-400" />
          <span className="text-xs text-ink-2">Show daily motivation quotes</span>
        </label>
      </div>

      <div>
        <span className={labelCls}>Available study hours per weekday</span>
        <div className="grid grid-cols-7 gap-1.5">
          {DAYS.map((d, i) => (
            <label key={d} className="block text-center">
              <span className="mb-1 block text-[10px] text-ink-3">{d}</span>
              <input
                value={String(Math.round((f.weeklyMinutes[String(i)] ?? 360) / 60))}
                inputMode="numeric"
                onChange={(e) => setF({ ...f, weeklyMinutes: { ...f.weeklyMinutes, [String(i)]: (parseInt(e.target.value) || 0) * 60 } })}
                className={cn(inputCls, "w-full !px-1 text-center text-xs tabular")}
              />
            </label>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-4 gap-2">
        {([["paceLectures", "Lectures/day"], ["paceQuestions", "Questions/day"], ["paceRevisions", "Revisions/day"], ["paceBacklog", "Backlog/day"]] as const).map(([k, l]) => (
          <label key={k} className="block">
            <span className={labelCls}>{l}</span>
            <input value={String(f[k])} inputMode="numeric" onChange={(e) => setF({ ...f, [k]: parseInt(e.target.value) || 0 })} className={cn(inputCls, "w-full tabular")} />
          </label>
        ))}
      </div>

      <button className="rounded-xl bg-accent px-5 py-2.5 text-sm font-semibold text-black transition hover:bg-accent-2">
        {pending ? spin(true) : saved ? "Saved — planner recalibrated" : "Save planning configuration"}
      </button>
    </form>
  );
}

/* ──────────────── error book ──────────────── */

export function ErrorForm({ subjects, chapters }: { subjects: { id: number; name: string }[]; chapters: { id: number; name: string; subjectId: number }[] }) {
  const [f, setF] = useState({ question: "", mistakeType: "conceptual", correctConcept: "", chapterId: "" });
  const [pending, start] = useTransition();
  return (
    <form
      className="space-y-2.5"
      onSubmit={(e) => {
        e.preventDefault();
        if (!f.question.trim()) return;
        start(async () => {
          const ch = chapters.find((c) => String(c.id) === f.chapterId);
          await addErrorEntry({
            question: f.question, mistakeType: f.mistakeType,
            correctConcept: f.correctConcept || undefined,
            chapterId: ch?.id ?? null, subjectId: ch?.subjectId ?? null,
            reattemptDate: undefined,
          });
          setF({ question: "", mistakeType: "conceptual", correctConcept: "", chapterId: "" });
        });
      }}
    >
      <input value={f.question} onChange={(e) => setF({ ...f, question: e.target.value })} placeholder="Describe the question / error…" className={cn(inputCls, "w-full")} />
      <div className="grid grid-cols-3 gap-2">
        <select value={f.chapterId} onChange={(e) => setF({ ...f, chapterId: e.target.value })} className={inputCls}>
          <option value="">Chapter (optional)</option>
          {chapters.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
        <select value={f.mistakeType} onChange={(e) => setF({ ...f, mistakeType: e.target.value })} className={inputCls}>
          {["conceptual", "calculation", "silly", "formula", "reading", "time", "guess"].map((m) => <option key={m} value={m}>{m}</option>)}
        </select>
        <input value={f.correctConcept} onChange={(e) => setF({ ...f, correctConcept: e.target.value })} placeholder="Correct concept…" className={inputCls} />
      </div>
      <button className="rounded-lg bg-accent px-3.5 py-2 text-xs font-semibold text-black transition hover:bg-accent-2">{pending ? spin(true) : "Add to error book"}</button>
    </form>
  );
}

export function ErrorCycle({ id, status }: { id: number; status: string }) {
  const [pending, start] = useTransition();
  const map: Record<string, { label: string; color: string }> = {
    open: { label: "Open", color: "#FB7185" },
    reattempt_scheduled: { label: "Reattempt set", color: "#FBBF24" },
    mastered: { label: "Mastered", color: "#34D399" },
  };
  const m = map[status] ?? map.open;
  return (
    <button
      onClick={() => start(async () => { await cycleErrorStatus(id); })}
      className="rounded-full border px-2.5 py-1 text-[10px] font-semibold transition"
      style={{ color: m.color, borderColor: `${m.color}55`, background: `${m.color}14` }}
    >
      {pending ? spin(true) : m.label}
    </button>
  );
}

/* ──────────────── import/export + resets ──────────────── */

export function ExportButton() {
  const [pending, start] = useTransition();
  return (
    <button
      onClick={() => start(async () => {
        const json = await exportDataAction();
        const blob = new Blob([json], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `tracker360-export-${new Date().toISOString().slice(0, 10)}.json`;
        a.click();
        URL.revokeObjectURL(url);
      })}
      className="inline-flex items-center gap-1.5 rounded-lg border border-line px-3.5 py-2 text-xs font-semibold text-ink-2 transition hover:border-accent/40 hover:text-accent"
    >
      {pending ? spin(true) : <Download size={13} />} Export all data (JSON)
    </button>
  );
}

export function ImportBox() {
  const [val, setVal] = useState("");
  const [msg, setMsg] = useState("");
  const [pending, start] = useTransition();
  return (
    <div className="space-y-2">
      <textarea
        value={val}
        onChange={(e) => setVal(e.target.value)}
        rows={4}
        placeholder='Paste progress payload, e.g. {"lectures":[{"id":12,"watchedPct":75}],"practice":[{"id":4,"solved":18}]}'
        className={cn(inputCls, "w-full font-mono !text-[11px]")}
      />
      <button
        onClick={() => start(async () => { setMsg(await importDataAction(val)); })}
        disabled={!val.trim()}
        className="inline-flex items-center gap-1.5 rounded-lg bg-accent px-3.5 py-2 text-xs font-semibold text-black transition hover:bg-accent-2 disabled:opacity-40"
      >
        {pending ? spin(true) : <Upload size={13} />} Import progress
      </button>
      {msg && <p className="text-[11px] text-ink-2">{msg}</p>}
    </div>
  );
}

export function ResetZone() {
  const [pending, start] = useTransition();
  const [msg, setMsg] = useState("");
  const Btn = ({ label, danger, action }: { label: string; danger?: boolean; action: () => Promise<void> }) => (
    <button
      onClick={() => {
        if (!window.confirm(`${label}? This cannot be undone.`)) return;
        start(async () => { await action(); setMsg(`${label} — done.`); });
      }}
      className={cn(
        "rounded-lg border px-3.5 py-2 text-xs font-semibold transition",
        danger ? "border-danger/40 bg-danger/10 text-danger hover:bg-danger/20" : "border-line text-ink-2 hover:border-warn/40 hover:text-warn"
      )}
    >
      {pending ? spin(true) : label}
    </button>
  );
  return (
    <div className="space-y-2">
      <div className="flex flex-wrap gap-2">
        <Btn label="Reset today's plan" action={resetTodayPlan} />
        <Btn label="Reset planner (today onwards)" action={resetPlanner} />
        <Btn label="Reset all progress" danger action={resetProgress} />
      </div>
      {msg && <p className="text-[11px] text-ink-3">{msg}</p>}
    </div>
  );
}

/* ──────────────── admin ──────────────── */

export function AnnouncementForm() {
  const [val, setVal] = useState("");
  const [pending, start] = useTransition();
  const [saved, setSaved] = useState(false);
  return (
    <form
      className="flex items-center gap-2"
      onSubmit={(e) => {
        e.preventDefault();
        if (!val.trim()) return;
        start(async () => { await saveAnnouncement(val); setVal(""); setSaved(true); });
      }}
    >
      <input value={val} onChange={(e) => setVal(e.target.value)} placeholder="Publish an announcement…" className={cn(inputCls, "flex-1")} />
      <button className="inline-flex items-center gap-1.5 rounded-lg bg-accent px-3.5 py-2 text-xs font-semibold text-black transition hover:bg-accent-2">
        {pending ? spin(true) : <Megaphone size={13} />} {saved ? "Published" : "Publish"}
      </button>
    </form>
  );
}

/* ──────────────── chapter override ──────────────── */

export function ChapterOverride({ id, pct, level }: { id: number; pct: number | null; level: string | null }) {
  const [open, setOpen] = useState(false);
  const [pending, start] = useTransition();
  if (!open) {
    return (
      <button onClick={() => setOpen(true)} className="text-[11px] font-medium text-accent hover:underline">
        {pct != null || level ? `Manual override active (${pct != null ? `${pct}%` : level}) · edit` : "Set manual override"}
      </button>
    );
  }
  const ChipBtn = ({ v, children }: { v: number | null; children: ReactNode }) => (
    <button
      onClick={() => start(async () => { await setChapterOverride(id, v, level); })}
      className={cn("rounded-md border px-2 py-1 text-[10px] tabular transition", pct === v ? "border-accent bg-accent/15 text-accent" : "border-line text-ink-3 hover:text-ink-2")}
    >
      {children}
    </button>
  );
  return (
    <div className="flex flex-wrap items-center gap-1.5">
      <span className="text-[10px] uppercase tracking-wider text-ink-3">Prep %</span>
      {[25, 50, 75, 90, 100].map((v) => <ChipBtn key={v} v={v}>{v}%</ChipBtn>)}
      <span className="mx-1 h-4 w-px bg-line" />
      {(["weak", "average", "strong", "mastered"] as const).map((l) => (
        <button
          key={l}
          onClick={() => start(async () => { await setChapterOverride(id, pct, l); })}
          className={cn("rounded-md border px-2 py-1 text-[10px] capitalize transition", level === l ? "border-warn bg-warn/15 text-warn" : "border-line text-ink-3 hover:text-ink-2")}
        >
          {l}
        </button>
      ))}
      <button
        onClick={() => start(async () => { await setChapterOverride(id, null, null); setOpen(false); })}
        className="rounded-md border border-line px-2 py-1 text-[10px] text-ink-3 hover:text-danger"
      >
        {pending ? spin(true) : "Clear override"}
      </button>
    </div>
  );
}
