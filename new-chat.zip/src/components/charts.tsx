"use client";

import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
} from "recharts";

const axisStyle = { fill: "#6b7280", fontSize: 10, fontFamily: "var(--font-jbmono)" };
const gridStroke = "rgba(255,255,255,0.05)";
const tip = {
  contentStyle: {
    background: "#151824", border: "1px solid rgba(255,255,255,0.1)",
    borderRadius: 10, fontSize: 11, color: "#e8eaf0",
  },
  labelStyle: { color: "#a5abbb", fontSize: 10 },
  itemStyle: { color: "#e8eaf0" },
};

export function HoursArea({ data }: { data: { d: string; hours: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height={190}>
      <AreaChart data={data} margin={{ top: 6, right: 4, left: -18, bottom: 0 }}>
        <defs>
          <linearGradient id="hoursGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#34d399" stopOpacity={0.35} />
            <stop offset="100%" stopColor="#34d399" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid stroke={gridStroke} vertical={false} />
        <XAxis dataKey="d" tick={axisStyle} tickLine={false} axisLine={false} interval="preserveStartEnd" />
        <YAxis tick={axisStyle} tickLine={false} axisLine={false} unit="h" />
        <Tooltip {...tip} formatter={(v) => [`${v}h`, "Study"]} />
        <Area type="monotone" dataKey="hours" stroke="#34d399" strokeWidth={1.8} fill="url(#hoursGrad)" />
      </AreaChart>
    </ResponsiveContainer>
  );
}

export function QuestionsBar({ data }: { data: { d: string; q: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height={190}>
      <BarChart data={data} margin={{ top: 6, right: 4, left: -18, bottom: 0 }}>
        <CartesianGrid stroke={gridStroke} vertical={false} />
        <XAxis dataKey="d" tick={axisStyle} tickLine={false} axisLine={false} interval="preserveStartEnd" />
        <YAxis tick={axisStyle} tickLine={false} axisLine={false} />
        <Tooltip {...tip} formatter={(v) => [`${v}`, "Questions"]} cursor={{ fill: "rgba(255,255,255,0.03)" }} />
        <Bar dataKey="q" fill="#a78bfa" radius={[3, 3, 0, 0]} maxBarSize={14} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function TrendLine({ data, dataKey, color, unit }: { data: Record<string, string | number>[]; dataKey: string; color: string; unit?: string }) {
  return (
    <ResponsiveContainer width="100%" height={190}>
      <LineChart data={data} margin={{ top: 6, right: 4, left: -18, bottom: 0 }}>
        <CartesianGrid stroke={gridStroke} vertical={false} />
        <XAxis dataKey="d" tick={axisStyle} tickLine={false} axisLine={false} interval="preserveStartEnd" />
        <YAxis tick={axisStyle} tickLine={false} axisLine={false} unit={unit} domain={["auto", "auto"]} />
        <Tooltip {...tip} />
        <Line type="monotone" dataKey={dataKey} stroke={color} strokeWidth={1.8} dot={false} />
      </LineChart>
    </ResponsiveContainer>
  );
}

export function BalanceDonut({ data }: { data: { name: string; value: number; color: string }[] }) {
  const total = data.reduce((s, x) => s + x.value, 0);
  return (
    <div className="relative">
      <ResponsiveContainer width="100%" height={190}>
        <PieChart>
          <Pie data={data} dataKey="value" innerRadius={58} outerRadius={82} paddingAngle={3} strokeWidth={0}>
            {data.map((d) => (
              <Cell key={d.name} fill={d.color} />
            ))}
          </Pie>
          <Tooltip {...tip} formatter={(v, n) => [`${Math.round(((v as number) / total) * 100)}%`, n]} />
        </PieChart>
      </ResponsiveContainer>
      <div className="pointer-events-none absolute inset-0 grid place-content-center text-center">
        <div className="font-display text-lg font-bold tabular text-ink">{Math.round(total / 60)}h</div>
        <div className="text-[9px] uppercase tracking-[0.14em] text-ink-3">last 7 days</div>
      </div>
    </div>
  );
}

export function Spark({ data, color = "#34d399", height = 40 }: { data: number[]; color?: string; height?: number }) {
  const pts = data.map((v, i) => ({ i, v }));
  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart data={pts} margin={{ top: 2, right: 2, left: 2, bottom: 2 }}>
        <Line type="monotone" dataKey="v" stroke={color} strokeWidth={1.6} dot={false} />
      </LineChart>
    </ResponsiveContainer>
  );
}
