"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard, CalendarCheck2, CalendarRange, Layers, BookOpen,
  History, Repeat2, PenLine, ClipboardList, BarChart3, Sparkles,
  Trophy, Settings2, Orbit, Zap, Map, Play, BookMarked, CalendarClock, LifeBuoy, ShieldCheck,
} from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/components/ui";

const GROUPS: { label: string; items: { href: string; label: string; icon: ReactNode }[] }[] = [
  {
    label: "Overview",
    items: [
      { href: "/", label: "Dashboard", icon: <LayoutDashboard size={16} /> },
      { href: "/today", label: "Today", icon: <CalendarCheck2 size={16} /> },
      { href: "/planner", label: "Planner", icon: <CalendarRange size={16} /> },
      { href: "/study", label: "Study Mode", icon: <Play size={16} /> },
    ],
  },
  {
    label: "Preparation",
    items: [
      { href: "/prep", label: "My Preparation", icon: <Map size={16} /> },
      { href: "/subjects", label: "Subjects", icon: <Layers size={16} /> },
      { href: "/chapters", label: "Chapters", icon: <BookOpen size={16} /> },
      { href: "/backlog", label: "Backlog Killer", icon: <History size={16} /> },
      { href: "/revision", label: "Revision", icon: <Repeat2 size={16} /> },
      { href: "/practice", label: "Practice", icon: <PenLine size={16} /> },
      { href: "/errors", label: "Error Book", icon: <BookMarked size={16} /> },
      { href: "/tests", label: "Tests", icon: <ClipboardList size={16} /> },
    ],
  },
  {
    label: "Life",
    items: [
      { href: "/timetable", label: "Timetable", icon: <CalendarClock size={16} /> },
      { href: "/analytics", label: "Analytics", icon: <BarChart3 size={16} /> },
      { href: "/ai", label: "Assistant", icon: <Sparkles size={16} /> },
      { href: "/goals", label: "Goals", icon: <Trophy size={16} /> },
      { href: "/docs", label: "Docs & Help", icon: <LifeBuoy size={16} /> },
    ],
  },
];

const ALL = [...GROUPS.flatMap((g) => g.items), { href: "/settings", label: "Settings", icon: <Settings2 size={16} /> }, { href: "/admin", label: "Admin", icon: <ShieldCheck size={16} /> }];

function NavLink({ href, label, icon, exact }: { href: string; label: string; icon: ReactNode; exact?: boolean }) {
  const pathname = usePathname();
  const active = exact ?? (href === "/" ? pathname === "/" : pathname.startsWith(href));
  return (
    <Link
      href={href}
      className={cn(
        "group flex items-center gap-2.5 rounded-lg px-3 py-2 text-[13px] font-medium transition-all",
        active
          ? "bg-accent/12 text-accent"
          : "text-ink-2 hover:bg-panel-2 hover:text-ink"
      )}
    >
      <span className={cn("transition-colors", active ? "text-accent" : "text-ink-3 group-hover:text-ink-2")}>{icon}</span>
      {label}
    </Link>
  );
}

export function Sidebar() {
  return (
    <aside className="fixed inset-y-0 left-0 z-40 hidden w-60 flex-col border-r border-line bg-base/80 backdrop-blur lg:flex">
      <div className="flex items-center gap-2.5 px-5 pt-5 pb-4">
        <span className="grid size-9 place-items-center rounded-xl border border-accent/30 bg-accent/10 text-accent">
          <Orbit size={18} />
        </span>
        <div>
          <div className="font-display text-[15px] font-bold leading-none tracking-tight">
            Tracker <span className="text-accent">360</span>
          </div>
          <div className="mt-1 text-[10px] font-medium uppercase tracking-[0.16em] text-ink-3">
            JEE Command Center
          </div>
        </div>
      </div>

      <nav className="flex-1 space-y-4 overflow-y-auto px-3 pb-4">
        {GROUPS.map((g) => (
          <div key={g.label}>
            <div className="px-3 pb-1.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-ink-3">
              {g.label}
            </div>
            <div className="space-y-0.5">
              {g.items.map((it) => (
                <NavLink key={it.href} {...it} />
              ))}
            </div>
          </div>
        ))}
        <div>
          <div className="px-3 pb-1.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-ink-3">System</div>
          <NavLink href="/settings" label="Settings" icon={<Settings2 size={16} />} />
          <NavLink href="/admin" label="Admin" icon={<ShieldCheck size={16} />} />
        </div>
      </nav>

      <div className="border-t border-line p-3">
        <div className="flex items-center gap-2.5 rounded-xl border border-line bg-panel p-2.5">
          <span className="grid size-8 shrink-0 place-items-center rounded-lg bg-accent/15 font-display text-xs font-bold text-accent">
            AS
          </span>
          <div className="min-w-0">
            <div className="truncate text-xs font-semibold text-ink">Aarav Sharma</div>
            <div className="flex items-center gap-1 text-[10px] text-ink-3">
              <Zap size={10} className="text-accent" /> Arjuna JEE 2026
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}

export function MobileNav() {
  const pathname = usePathname();
  return (
    <div className="sticky top-0 z-40 border-b border-line bg-base/90 backdrop-blur lg:hidden">
      <div className="flex items-center gap-2 px-4 pt-3 pb-2">
        <span className="grid size-7 place-items-center rounded-lg border border-accent/30 bg-accent/10 text-accent">
          <Orbit size={14} />
        </span>
        <span className="font-display text-sm font-bold tracking-tight">
          Tracker <span className="text-accent">360</span>
        </span>
      </div>
      <nav className="no-scrollbar flex gap-1.5 overflow-x-auto px-4 pb-2.5">
        {ALL.map((it) => {
          const active = it.href === "/" ? pathname === "/" : pathname.startsWith(it.href);
          return (
            <Link
              key={it.href}
              href={it.href}
              className={cn(
                "flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium transition",
                active ? "border-accent/40 bg-accent/12 text-accent" : "border-line bg-panel text-ink-2"
              )}
            >
              {it.icon}
              {it.label}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}

export function PageHeader({
  title, sub, right,
}: { title: string; sub?: string; right?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3 animate-fade-up">
      <div>
        <h1 className="font-display text-2xl font-bold tracking-tight text-ink md:text-[26px]">{title}</h1>
        {sub && <p className="mt-1 text-sm text-ink-3">{sub}</p>}
      </div>
      {right}
    </div>
  );
}
