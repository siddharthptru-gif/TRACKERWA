import type { ReactNode } from "react";
import Link from "next/link";

export const cn = (...xs: (string | false | null | undefined)[]) =>
  xs.filter(Boolean).join(" ");

/* ── surfaces ── */

export function Card({
  children, className, accent,
}: { children: ReactNode; className?: string; accent?: boolean }) {
  return (
    <section
      className={cn(
        "rounded-2xl border border-line bg-panel p-5",
        accent && "border-accent/25 bg-gradient-to-b from-accent/[0.06] to-panel",
        className
      )}
    >
      {children}
    </section>
  );
}

export function CardHeader({
  icon, title, sub, right,
}: { icon?: ReactNode; title: string; sub?: string; right?: ReactNode }) {
  return (
    <header className="mb-4 flex items-start justify-between gap-3">
      <div className="flex items-center gap-2.5">
        {icon && (
          <span className="grid size-8 place-items-center rounded-lg border border-line bg-panel-2 text-ink-2">
            {icon}
          </span>
        )}
        <div>
          <h2 className="font-display text-[15px] font-semibold tracking-tight text-ink">
            {title}
          </h2>
          {sub && <p className="mt-0.5 text-xs text-ink-3">{sub}</p>}
        </div>
      </div>
      {right}
    </header>
  );
}

/* ── progress ── */

export function Bar({
  pct, color = "var(--color-accent)", className, track,
}: { pct: number; color?: string; className?: string; track?: string }) {
  return (
    <div className={cn("h-1.5 w-full overflow-hidden rounded-full", className)} style={{ background: track ?? "rgba(255,255,255,0.06)" }}>
      <div
        className="h-full rounded-full transition-all duration-700"
        style={{ width: `${Math.min(100, Math.max(0, pct))}%`, background: color }}
      />
    </div>
  );
}

export function Ring({
  pct, size = 148, stroke = 10, label, sub, color = "var(--color-accent)",
}: { pct: number; size?: number; stroke?: number; label?: string; sub?: string; color?: string }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative grid place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth={stroke} />
        <circle
          cx={size / 2} cy={size / 2} r={r} fill="none"
          stroke={color} strokeWidth={stroke} strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c - (c * Math.min(100, Math.max(0, pct))) / 100}
          style={{ transition: "stroke-dashoffset 1s cubic-bezier(0.22,1,0.36,1)" }}
        />
      </svg>
      <div className="absolute inset-0 grid place-content-center text-center">
        <div className="font-display text-3xl font-bold tabular text-ink">{label ?? `${pct}%`}</div>
        {sub && <div className="mt-0.5 text-[10px] font-medium uppercase tracking-[0.14em] text-ink-3">{sub}</div>}
      </div>
    </div>
  );
}

/* ── primitives ── */

export function Chip({
  children, color, className,
}: { children: ReactNode; color?: string; className?: string }) {
  return (
    <span
      className={cn("inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-medium", className)}
      style={color ? { color, borderColor: `${color}44`, background: `${color}14` } : { color: "var(--color-ink-2)", borderColor: "var(--color-line)" }}
    >
      {children}
    </span>
  );
}

export function Stat({
  label, value, sub, tone,
}: { label: string; value: string; sub?: string; tone?: "good" | "warn" | "bad" }) {
  return (
    <div>
      <div className="text-[11px] font-medium uppercase tracking-[0.12em] text-ink-3">{label}</div>
      <div
        className="mt-1 font-display text-xl font-bold tabular"
        style={{
          color: tone === "good" ? "var(--color-accent)" : tone === "warn" ? "var(--color-warn)" : tone === "bad" ? "var(--color-danger)" : "var(--color-ink)",
        }}
      >
        {value}
      </div>
      {sub && <div className="mt-0.5 text-xs text-ink-3">{sub}</div>}
    </div>
  );
}

export function Empty({
  icon, title, body, actionLabel, actionHref,
}: { icon?: ReactNode; title: string; body?: string; actionLabel?: string; actionHref?: string }) {
  return (
    <div className="grid place-items-center gap-2 py-10 text-center">
      {icon && <div className="grid size-12 place-items-center rounded-2xl border border-line bg-panel-2 text-ink-3">{icon}</div>}
      <div className="font-display text-sm font-semibold text-ink">{title}</div>
      {body && <p className="max-w-sm text-xs leading-relaxed text-ink-3">{body}</p>}
      {actionLabel && actionHref && (
        <Link href={actionHref} className="mt-2 rounded-lg bg-accent px-4 py-2 text-xs font-semibold text-black transition hover:bg-accent-2">
          {actionLabel}
        </Link>
      )}
    </div>
  );
}

/* ── task kind + status metadata ── */

export const KIND_META: Record<string, { label: string; color: string }> = {
  lecture: { label: "Lecture", color: "#38BDF8" },
  backlog: { label: "Backlog", color: "#FB7185" },
  revision: { label: "Revision", color: "#34D399" },
  dpp: { label: "DPP", color: "#FBBF24" },
  pyq: { label: "PYQ", color: "#F97316" },
  practice: { label: "Module", color: "#A78BFA" },
  test_prep: { label: "Test Prep", color: "#E879F9" },
  test: { label: "Test", color: "#F43F5E" },
  weak_topic: { label: "Weak Topic", color: "#FB7185" },
};

export const PRACTICE_STATUS: Record<string, { label: string; color: string }> = {
  not_started: { label: "Not started", color: "#6b7280" },
  in_progress: { label: "In progress", color: "#38BDF8" },
  completed: { label: "Completed", color: "#34D399" },
  weak: { label: "Weak", color: "#FB7185" },
  needs_revision: { label: "Needs revision", color: "#FBBF24" },
};

export function ProgressMini({ done, total, color }: { done: number; total: number; color?: string }) {
  return (
    <div className="flex items-center gap-2">
      <Bar pct={total ? (done / total) * 100 : 0} color={color} className="w-16" />
      <span className="text-[11px] tabular text-ink-3">{done}/{total}</span>
    </div>
  );
}

export const SUBJECT_COLORS: Record<string, string> = {
  Physics: "#38BDF8",
  Chemistry: "#A78BFA",
  Mathematics: "#FBBF24",
};
