"use client";

import { useRef, useState, useTransition } from "react";
import { SendHorizonal, Sparkles, Loader2 } from "lucide-react";
import { askAiAction } from "@/lib/actions";
import { cn } from "@/components/ui";

type Msg = { role: "user" | "assistant"; content: string };

const SUGGESTIONS = [
  "What should I study today?",
  "How much backlog do I have?",
  "Which chapter should I revise?",
  "Can I finish this backlog in 10 days?",
  "Why is my progress slowing down?",
  "Give me a plan for Sunday",
  "Which subject should I prioritise?",
  "Am I on track for my target rank?",
];

/* lightweight markdown renderer: **bold**, _italic_, bullet lines, newlines */
function renderMD(text: string) {
  return text.split("\n").map((line, i) => {
    const parts = line
      .split(/(\*\*[^*]+\*\*|_[^_]+_)/g)
      .filter(Boolean)
      .map((seg, j) => {
        if (seg.startsWith("**") && seg.endsWith("**"))
          return <strong key={j} className="font-semibold text-ink">{seg.slice(2, -2)}</strong>;
        if (seg.startsWith("_") && seg.endsWith("_") && seg.length > 2)
          return <em key={j} className="text-ink-3 not-italic text-xs">{seg.slice(1, -1)}</em>;
        return <span key={j}>{seg}</span>;
      });
    if (line.trim() === "") return <div key={i} className="h-2.5" />;
    return <p key={i} className="leading-relaxed">{parts}</p>;
  });
}

export function AiChat({ initial }: { initial: Msg[] }) {
  const [msgs, setMsgs] = useState<Msg[]>(initial);
  const [input, setInput] = useState("");
  const [pending, start] = useTransition();
  const endRef = useRef<HTMLDivElement>(null);

  const ask = (q: string) => {
    const question = q.trim();
    if (!question || pending) return;
    setMsgs((m) => [...m, { role: "user", content: question }]);
    setInput("");
    start(async () => {
      const answer = await askAiAction(question);
      setMsgs((m) => [...m, { role: "assistant", content: answer }]);
      setTimeout(() => endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" }), 50);
    });
  };

  return (
    <div className="flex h-[calc(100dvh-220px)] min-h-[420px] flex-col">
      <div className="flex-1 space-y-4 overflow-y-auto pr-1">
        {msgs.length === 0 && (
          <div className="grid place-items-center gap-3 py-10 text-center animate-fade-up">
            <span className="grid size-12 place-items-center rounded-2xl border border-accent/30 bg-accent/10 text-accent">
              <Sparkles size={20} />
            </span>
            <div>
              <div className="font-display text-sm font-semibold text-ink">Ask about your preparation</div>
              <p className="mx-auto mt-1 max-w-md text-xs leading-relaxed text-ink-3">
                I read your live tracker state — plans, backlog, revisions, tests and goals — and answer with real numbers, not generic advice.
              </p>
            </div>
            <div className="mt-2 flex max-w-xl flex-wrap justify-center gap-1.5">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  onClick={() => ask(s)}
                  className="rounded-full border border-line bg-panel px-3 py-1.5 text-[11px] font-medium text-ink-2 transition hover:border-accent/40 hover:text-accent"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {msgs.map((m, i) => (
          <div key={i} className={cn("flex animate-fade-up", m.role === "user" ? "justify-end" : "justify-start")}>
            <div
              className={cn(
                "max-w-[85%] rounded-2xl px-4 py-3 text-[13px]",
                m.role === "user"
                  ? "rounded-br-md bg-accent/15 text-ink"
                  : "rounded-bl-md border border-line bg-panel text-ink-2"
              )}
            >
              {m.role === "assistant" ? renderMD(m.content) : m.content}
            </div>
          </div>
        ))}

        {pending && (
          <div className="flex justify-start">
            <div className="flex items-center gap-2 rounded-2xl rounded-bl-md border border-line bg-panel px-4 py-3 text-xs text-ink-3">
              <Loader2 size={13} className="animate-spin text-accent" /> Analysing your tracker data…
            </div>
          </div>
        )}
        <div ref={endRef} />
      </div>

      <form
        className="mt-4 flex items-center gap-2"
        onSubmit={(e) => { e.preventDefault(); ask(input); }}
      >
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask: what should I do today? · can I clear backlog in 10 days?…"
          className="flex-1 rounded-xl border border-line bg-panel px-4 py-3 text-sm text-ink outline-none placeholder:text-ink-3 focus:border-accent/50"
        />
        <button
          type="submit"
          disabled={pending || !input.trim()}
          className="grid size-11 shrink-0 place-items-center rounded-xl bg-accent text-black transition hover:bg-accent-2 disabled:opacity-40"
        >
          <SendHorizonal size={16} />
        </button>
      </form>
    </div>
  );
}
