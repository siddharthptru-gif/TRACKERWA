"use client";

import { useState, useTransition, type ReactNode } from "react";
import { useRouter } from "next/navigation";
import { Check, Loader2, RefreshCw, Wand2, RotateCcw } from "lucide-react";
import {
  toggleTask, completeRevisionAction, toggleLectureAction,
  updatePracticeStatus, logTestScore, submitCheckin, saveGoalsAction,
  applyBacklogPlanAction, regeneratePlanAction, runOnboardingAction, reseedAction,
} from "@/lib/actions";
import { cn, PRACTICE_STATUS } from "@/components/ui";
import Link from "next/link";

const spin = (pending: boolean) => (pending ? <Loader2 size={14} className="animate-spin" /> : null);

export function TaskToggle({ id, done }: { id: number; done: boolean }) {
  const [pending, start] = useTransition();
  return (
    <button
      onClick={() => start(async () => { await toggleTask(id); })}
      disabled={pending}
      aria-label="toggle task"
      className={cn(
        "grid size-6 shrink-0 place-items-center rounded-md border transition-all",
        done
          ? "border-accent bg-accent text-black"
          : "border-line-2 bg-panel-2 text-transparent hover:border-accent/60 hover:text-accent/40"
      )}
    >
      {pending ? <Loader2 size={12} className="animate-spin text-accent" /> : <Check size={14} strokeWidth={3} />}
    </button>
  );
}

export function ReplanButton() {
  const [pending, start] = useTransition();
  return (
    <button
      onClick={() => start(async () => { await regeneratePlanAction(); })}
      className="inline-flex items-center gap-1.5 rounded-lg border border-line bg-panel px-3 py-1.5 text-xs font-medium text-ink-2 transition hover:border-accent/40 hover:text-accent"
    >
      {pending ? spin(pending) : <RefreshCw size={13} />} Re-plan today
    </button>
  );
}

export function ApplyBacklogButton() {
  const [pending, start] = useTransition();
  const [done, setDone] = useState(false);
  return (
    <button
      onClick={() => start(async () => { await applyBacklogPlanAction(); setDone(true); })}
      className="inline-flex items-center gap-1.5 rounded-lg bg-accent px-3.5 py-2 text-xs font-semibold text-black transition hover:bg-accent-2"
    >
      {pending ? spin(pending) : <Wand2 size={13} />}
      {done ? "Applied to planner" : "Apply to planner"}
    </button>
  );
}

const RECALL_LEVELS: { score: number; label: string; color: string }[] = [
  { score: 20, label: "Forgot", color: "#FB7185" },
  { score: 40, label: "Weak", color: "#FB923C" },
  { score: 60, label: "Average", color: "#FBBF24" },
  { score: 80, label: "Good", color: "#6EE7B7" },
  { score: 95, label: "Excellent", color: "#34D399" },
];

export function RevisionDone({ id }: { id: number }) {
  const [pending, start] = useTransition();
  const [open, setOpen] = useState(false);
  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        className="rounded-lg border border-accent/40 bg-accent/10 px-3 py-1.5 text-xs font-semibold text-accent transition hover:bg-accent/20"
      >
        Mark done
      </button>
    );
  }
  return (
    <div className="flex flex-wrap items-center gap-1">
      <span className="mr-1 text-[10px] uppercase tracking-wider text-ink-3">Recall?</span>
      {RECALL_LEVELS.map((l) => (
        <button
          key={l.score}
          onClick={() => start(async () => { await completeRevisionAction(id, l.score); })}
          className="rounded-md border px-2 py-1 text-[10px] font-semibold transition"
          style={{ color: l.color, borderColor: `${l.color}55`, background: `${l.color}12` }}
          title={`Next revision: ${l.label === "Forgot" ? "tomorrow" : l.label === "Weak" ? "in 2 days" : l.label === "Average" ? "standard interval" : l.label === "Good" ? "interval ×1.3" : "interval ×1.6"}`}
        >
          {pending ? spin(pending) : l.label}
        </button>
      ))}
    </div>
  );
}

export function LectureCheck({ id, done }: { id: number; done: boolean }) {
  const [pending, start] = useTransition();
  return (
    <button
      onClick={() => start(async () => { await toggleLectureAction(id); })}
      disabled={pending}
      className={cn(
        "grid size-5.5 shrink-0 place-items-center rounded border transition-all",
        done ? "border-accent bg-accent text-black" : "border-line-2 text-transparent hover:border-accent/60 hover:text-accent/40"
      )}
    >
      {pending ? <Loader2 size={11} className="animate-spin text-accent" /> : <Check size={12} strokeWidth={3} />}
    </button>
  );
}

export function PracticeStatus({ id, status }: { id: number; status: string }) {
  const [pending, start] = useTransition();
  const meta = PRACTICE_STATUS[status] ?? PRACTICE_STATUS.not_started;
  return (
    <div className="relative">
      <select
        value={status}
        disabled={pending}
        onChange={(e) => start(async () => { await updatePracticeStatus(id, e.target.value); })}
        className="cursor-pointer appearance-none rounded-full border bg-panel-2 py-1 pl-2.5 pr-6 text-[11px] font-medium outline-none transition"
        style={{ color: meta.color, borderColor: `${meta.color}55` }}
      >
        {Object.entries(PRACTICE_STATUS).map(([k, v]) => (
          <option key={k} value={k} className="bg-panel text-ink">{v.label}</option>
        ))}
      </select>
      <span className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 text-[9px]" style={{ color: meta.color }}>▾</span>
    </div>
  );
}

export function TestLogForm({ id, max }: { id: number; max: number }) {
  const [val, setVal] = useState("");
  const [pending, start] = useTransition();
  return (
    <form
      className="flex items-center gap-2"
      onSubmit={(e) => {
        e.preventDefault();
        const m = parseInt(val);
        if (!isNaN(m)) start(async () => { await logTestScore(id, m); setVal(""); });
      }}
    >
      <input
        value={val}
        onChange={(e) => setVal(e.target.value.replace(/[^0-9]/g, ""))}
        placeholder={`Score /${max}`}
        className="w-24 rounded-lg border border-line bg-panel-2 px-2.5 py-1.5 text-xs tabular text-ink outline-none placeholder:text-ink-3 focus:border-accent/50"
      />
      <button className="rounded-lg bg-accent px-2.5 py-1.5 text-[11px] font-semibold text-black transition hover:bg-accent-2">
        {pending ? spin(pending) : "Log"}
      </button>
    </form>
  );
}

/* ────────────────────────── check-in form ────────────────────────── */

export function CheckinForm() {
  const [f, setF] = useState({ hours: "6", minutes: "30", lectures: "2", questions: "60", revisions: "1", tests: "0", energy: 3, note: "" });
  const [pending, start] = useTransition();
  const [saved, setSaved] = useState(false);
  const num = (s: string) => parseInt(s) || 0;
  const Field = ({ k, label }: { k: "hours" | "minutes" | "lectures" | "questions" | "revisions" | "tests"; label: string }) => (
    <label className="block">
      <span className="mb-1 block text-[10px] font-medium uppercase tracking-[0.12em] text-ink-3">{label}</span>
      <input
        value={f[k]} inputMode="numeric"
        onChange={(e) => setF({ ...f, [k]: e.target.value.replace(/[^0-9]/g, "") })}
        className="w-full rounded-lg border border-line bg-panel-2 px-3 py-2 text-sm tabular text-ink outline-none focus:border-accent/50"
      />
    </label>
  );
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        start(async () => {
          await submitCheckin({
            minutes: num(f.hours) * 60 + num(f.minutes),
            lecturesDone: num(f.lectures), questionsSolved: num(f.questions),
            revisionsDone: num(f.revisions), testsAttempted: num(f.tests),
            energy: f.energy, note: f.note || undefined,
          });
          setSaved(true);
        });
      }}
      className="space-y-4"
    >
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        <Field k="hours" label="Study hours" />
        <Field k="minutes" label="Extra minutes" />
        <Field k="lectures" label="Lectures done" />
        <Field k="questions" label="Questions solved" />
        <Field k="revisions" label="Revisions done" />
        <Field k="tests" label="Tests attempted" />
      </div>
      <div>
        <span className="mb-1.5 block text-[10px] font-medium uppercase tracking-[0.12em] text-ink-3">Energy level</span>
        <div className="flex gap-1.5">
          {[1, 2, 3, 4, 5].map((n) => (
            <button
              type="button" key={n}
              onClick={() => setF({ ...f, energy: n })}
              className={cn(
                "h-8 flex-1 rounded-lg border text-xs font-semibold tabular transition",
                f.energy === n ? "border-accent bg-accent/15 text-accent" : "border-line bg-panel-2 text-ink-3 hover:text-ink-2"
              )}
            >
              {n}
            </button>
          ))}
        </div>
      </div>
      <input
        value={f.note}
        onChange={(e) => setF({ ...f, note: e.target.value })}
        placeholder="Anything that blocked you today? (optional)"
        className="w-full rounded-lg border border-line bg-panel-2 px-3 py-2 text-sm text-ink outline-none placeholder:text-ink-3 focus:border-accent/50"
      />
      <button className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-accent py-2.5 text-sm font-semibold text-black transition hover:bg-accent-2">
        {pending ? spin(pending) : saved ? "Tomorrow's plan recalibrated" : "Submit check-in & re-plan tomorrow"}
      </button>
      {saved && (
        <p className="text-xs leading-relaxed text-ink-3">
          Load scale, unfinished work and tomorrow's priorities were automatically adjusted based on this check-in.
        </p>
      )}
    </form>
  );
}

/* ────────────────────────── goals form ────────────────────────── */

export function GoalForm({ initial }: {
  initial: {
    dailyMinutes: number; weeklyQuestions: number; monthlyChapters: number;
    targetRankMain: number; targetRankAdv: number; examDateMain?: string | null; examDateAdv?: string | null;
  };
}) {
  const [f, setF] = useState({
    dailyMinutes: String(initial.dailyMinutes),
    weeklyQuestions: String(initial.weeklyQuestions),
    monthlyChapters: String(initial.monthlyChapters),
    targetRankMain: String(initial.targetRankMain),
    targetRankAdv: String(initial.targetRankAdv),
    examDateMain: initial.examDateMain ?? "",
    examDateAdv: initial.examDateAdv ?? "",
  });
  const [pending, start] = useTransition();
  const [saved, setSaved] = useState(false);
  const num = (s: string) => parseInt(s) || 0;
  const Row = ({ k, label }: { k: "dailyMinutes" | "weeklyQuestions" | "monthlyChapters" | "targetRankMain" | "targetRankAdv"; label: string }) => (
    <label className="block">
      <span className="mb-1 block text-[10px] font-medium uppercase tracking-[0.12em] text-ink-3">{label}</span>
      <input
        value={f[k]} inputMode="numeric"
        onChange={(e) => setF({ ...f, [k]: e.target.value.replace(/[^0-9]/g, "") })}
        className="w-full rounded-lg border border-line bg-panel-2 px-3 py-2 text-sm tabular text-ink outline-none focus:border-accent/50"
      />
    </label>
  );
  return (
    <form
      className="space-y-3"
      onSubmit={(e) => {
        e.preventDefault();
        start(async () => {
          await saveGoalsAction({
            dailyMinutes: num(f.dailyMinutes), weeklyQuestions: num(f.weeklyQuestions),
            monthlyChapters: num(f.monthlyChapters), targetRankMain: num(f.targetRankMain),
            targetRankAdv: num(f.targetRankAdv),
            examDateMain: f.examDateMain || undefined, examDateAdv: f.examDateAdv || undefined,
          });
          setSaved(true);
        });
      }}
    >
      <div className="grid grid-cols-2 gap-3">
        <Row k="dailyMinutes" label="Daily study target (min)" />
        <Row k="weeklyQuestions" label="Weekly questions" />
        <Row k="monthlyChapters" label="Monthly chapters" />
        <Row k="targetRankMain" label="JEE Main target rank" />
        <Row k="targetRankAdv" label="JEE Adv target rank" />
      </div>
      <div className="grid grid-cols-2 gap-3">
        {(["examDateMain", "examDateAdv"] as const).map((k) => (
          <label key={k} className="block">
            <span className="mb-1 block text-[10px] font-medium uppercase tracking-[0.12em] text-ink-3">
              {k === "examDateMain" ? "JEE Main date" : "JEE Adv date"}
            </span>
            <input
              type="date" value={f[k]}
              onChange={(e) => setF({ ...f, [k]: e.target.value })}
              className="w-full rounded-lg border border-line bg-panel-2 px-3 py-2 text-sm text-ink outline-none [color-scheme:dark] focus:border-accent/50"
            />
          </label>
        ))}
      </div>
      <button className="inline-flex items-center gap-2 rounded-xl bg-accent px-4 py-2.5 text-sm font-semibold text-black transition hover:bg-accent-2">
        {pending ? spin(pending) : saved ? "Saved" : "Save goals"}
      </button>
    </form>
  );
}

/* ────────────────────────── onboarding form ────────────────────────── */

export function OnboardingForm() {
  const [step, setStep] = useState(0);
  const [pending, start] = useTransition();
  const router = useRouter();
  const [f, setF] = useState({
    name: "Aarav Sharma", className: "Class 12", exam: "JEE Main + Advanced",
    batchName: "Arjuna JEE 2026 — PW Batch", hours: "7", minutes: "0",
    schoolHours: "8:00 AM – 2:00 PM", targetRank: "500",
  });

  const steps = ["Profile", "Batch", "Capacity"];

  return (
    <div>
      <div className="mb-6 flex items-center gap-2">
        {steps.map((s, i) => (
          <div key={s} className="flex items-center gap-2">
            <span className={cn(
              "grid size-6 place-items-center rounded-full border text-[10px] font-bold tabular",
              i <= step ? "border-accent bg-accent/15 text-accent" : "border-line text-ink-3"
            )}>{i + 1}</span>
            <span className={cn("text-xs font-medium", i <= step ? "text-ink" : "text-ink-3")}>{s}</span>
            {i < steps.length - 1 && <span className="mx-1 h-px w-6 bg-line" />}
          </div>
        ))}
      </div>

      {step === 0 && (
        <div className="space-y-3 animate-fade-up">
          <Field label="Your name" value={f.name} onChange={(v) => setF({ ...f, name: v })} />
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Lbl>Class</Lbl>
              <div className="flex gap-1.5">
                {["Class 11", "Class 12", "Dropper"].map((c) => (
                  <Pick key={c} active={f.className === c} onClick={() => setF({ ...f, className: c })}>{c.replace("Class ", "")}</Pick>
                ))}
              </div>
            </div>
            <div>
              <Lbl>Target rank (JEE Main)</Lbl>
              <input value={f.targetRank} inputMode="numeric" onChange={(e) => setF({ ...f, targetRank: e.target.value.replace(/[^0-9]/g, "") })}
                className="w-full rounded-lg border border-line bg-panel-2 px-3 py-2 text-sm tabular text-ink outline-none focus:border-accent/50" />
            </div>
          </div>
        </div>
      )}

      {step === 1 && (
        <div className="space-y-3 animate-fade-up">
          <Field label="Coaching batch" value={f.batchName} onChange={(v) => setF({ ...f, batchName: v })} />
          <div>
            <Lbl>Exam</Lbl>
            <div className="flex flex-wrap gap-1.5">
              {["JEE Main + Advanced", "JEE Main only", "NEET (coming soon)"].map((x) => (
                <Pick key={x} active={f.exam === x} onClick={() => setF({ ...f, exam: x })}>{x}</Pick>
              ))}
            </div>
          </div>
          <div className="rounded-xl border border-line bg-panel-2 p-3 text-xs leading-relaxed text-ink-3">
            <span className="font-semibold text-ink-2">Manual import mode.</span> Tracker 360 never scrapes or asks for your coaching password.
            For the demo we preload a realistic PW-style batch snapshot — 52 chapters, lectures, DPPs, PYQs and tests — which you can edit as your own.
          </div>
        </div>
      )}

      {step === 2 && (
        <div className="space-y-3 animate-fade-up">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Daily self-study hours" value={f.hours} numeric onChange={(v) => setF({ ...f, hours: v })} />
            <Field label="School / college timing" value={f.schoolHours} onChange={(v) => setF({ ...f, schoolHours: v })} />
          </div>
          <div className="rounded-xl border border-line bg-panel-2 p-3 text-xs leading-relaxed text-ink-3">
            On launch, Tracker 360 will assume a mid-batch state (some chapters complete, a running chapter per subject,
            a realistic backlog and spaced-revision queue) so the full system is immediately explorable. Adjust afterwards from each tracker's page.
          </div>
        </div>
      )}

      <div className="mt-6 flex items-center justify-between">
        <button
          onClick={() => setStep(Math.max(0, step - 1))}
          className={cn("text-xs font-medium text-ink-3 transition hover:text-ink", step === 0 && "invisible")}
        >
          ← Back
        </button>
        {step < 2 ? (
          <button onClick={() => setStep(step + 1)} className="rounded-xl bg-accent px-5 py-2.5 text-sm font-semibold text-black transition hover:bg-accent-2">
            Continue
          </button>
        ) : (
          <button
            onClick={() => start(async () => {
              await runOnboardingAction({
                name: f.name, className: f.className, exam: f.exam, batchName: f.batchName,
                dailyMinutes: (parseInt(f.hours) || 7) * 60 + 0,
                schoolHours: f.schoolHours, targetRank: parseInt(f.targetRank) || 500,
              });
              router.push("/");
            })}
            className="inline-flex items-center gap-2 rounded-xl bg-accent px-5 py-2.5 text-sm font-semibold text-black transition hover:bg-accent-2"
          >
            {pending ? spin(pending) : <Wand2 size={14} />} Generate my Tracker 360
          </button>
        )}
      </div>
    </div>
  );
}

function Lbl({ children }: { children: ReactNode }) {
  return <span className="mb-1.5 block text-[10px] font-medium uppercase tracking-[0.12em] text-ink-3">{children}</span>;
}
function Field({ label, value, onChange, numeric }: { label: string; value: string; onChange: (v: string) => void; numeric?: boolean }) {
  return (
    <label className="block">
      <Lbl>{label}</Lbl>
      <input
        value={value} inputMode={numeric ? "numeric" : undefined}
        onChange={(e) => onChange(numeric ? e.target.value.replace(/[^0-9]/g, "") : e.target.value)}
        className="w-full rounded-lg border border-line bg-panel-2 px-3 py-2 text-sm text-ink outline-none focus:border-accent/50"
      />
    </label>
  );
}
function Pick({ active, onClick, children }: { active: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <button
      type="button" onClick={onClick}
      className={cn(
        "rounded-lg border px-3 py-2 text-xs font-medium transition",
        active ? "border-accent bg-accent/12 text-accent" : "border-line bg-panel-2 text-ink-2 hover:text-ink"
      )}
    >
      {children}
    </button>
  );
}

/* ────────────────────────── danger zone ────────────────────────── */

export function ReseedButton() {
  const [pending, start] = useTransition();
  return (
    <button
      onClick={() => start(async () => { await reseedAction(); })}
      className="inline-flex items-center gap-1.5 rounded-lg border border-danger/40 bg-danger/10 px-3.5 py-2 text-xs font-semibold text-danger transition hover:bg-danger/20"
    >
      {pending ? spin(pending) : <RotateCcw size={13} />} Reset & reseed demo data
    </button>
  );
}

export function LinkBtn({ href, children }: { href: string; children: ReactNode }) {
  return (
    <Link href={href} className="text-xs font-medium text-accent transition hover:underline">
      {children}
    </Link>
  );
}
