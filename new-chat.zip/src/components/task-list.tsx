import Link from "next/link";
import { cn, KIND_META } from "@/components/ui";
import { TaskToggle } from "@/components/widgets";
import { TaskMenu, PromiseStar } from "@/components/widgets2";
import { fmtMin } from "@/lib/engine";

type Task = {
  id: number;
  title: string;
  kind: string;
  reason: string;
  estMin: number;
  priority: number;
  status: string;
  subjectId: number | null;
  refType: string | null;
  refId: number | null;
  promised?: boolean;
};

export function TaskList({
  tasks, subjectColors, chapterOf, compact,
}: {
  tasks: Task[];
  subjectColors: Map<number, string>;
  chapterOf?: (lectureId: number) => number | null;
  compact?: boolean;
}) {
  if (tasks.length === 0) {
    return <p className="py-6 text-center text-xs text-ink-3">No tasks here. Your planner will populate automatically.</p>;
  }
  return (
    <div className="space-y-1">
      {tasks.map((t, i) => {
        const meta = KIND_META[t.kind] ?? KIND_META.practice;
        const done = t.status === "done";
        const subjColor = t.subjectId != null ? subjectColors.get(t.subjectId) : undefined;
        const chapterId =
          t.refType === "lecture" && t.refId && chapterOf ? chapterOf(t.refId) :
          t.refType === "chapter" ? t.refId : null;

        const inner = (
          <>
            <TaskToggle id={t.id} done={done} />
            <span
              className="mt-0.5 h-9 w-1 shrink-0 rounded-full"
              style={{ background: meta.color }}
              title={meta.label}
            />
            <div className="min-w-0 flex-1">
              <div className={cn("truncate text-[13px] font-medium", done ? "text-ink-3 line-through" : "text-ink")}>
                {t.title}
              </div>
              {!compact && (
                <div className="mt-0.5 truncate text-[11px] text-ink-3">{t.reason}</div>
              )}
            </div>
          </>
        );

        return (
          <div
            key={t.id}
            className={cn(
              "flex items-center gap-3 rounded-xl border border-transparent px-2.5 py-2 transition hover:border-line hover:bg-panel-2",
              done && "opacity-60"
            )}
          >
            {chapterId ? (
              <Link href={`/chapters/${chapterId}`} className="flex min-w-0 flex-1 items-center gap-3">
                {inner}
              </Link>
            ) : (
              <div className="flex min-w-0 flex-1 items-center gap-3">{inner}</div>
            )}
            <div className="flex shrink-0 items-center gap-1.5">
              {subjColor && <span className="size-1.5 rounded-full" style={{ background: subjColor }} />}
              {i === 0 && !done && (
                <span className="rounded-full border border-accent/40 bg-accent/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-accent">
                  Next
                </span>
              )}
              <span className="w-14 text-right font-mono text-[11px] tabular text-ink-3">{fmtMin(t.estMin)}</span>
              {!done && (
                <>
                  <PromiseStar id={t.id} promised={t.promised ?? false} />
                  <span className="relative">
                    <TaskMenu id={t.id} estMin={t.estMin} />
                  </span>
                </>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
