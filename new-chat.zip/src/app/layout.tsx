import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Inter, Space_Grotesk, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { Sidebar, MobileNav } from "@/components/shell";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });
const grotesk = Space_Grotesk({ subsets: ["latin"], variable: "--font-grotesk" });
const jbmono = JetBrains_Mono({ subsets: ["latin"], variable: "--font-jbmono" });

export const metadata: Metadata = {
  title: "Tracker 360 — JEE Preparation Command Center",
  description:
    "Intelligent study tracking and planning for JEE Main + Advanced: lectures, revisions, backlog, practice, tests, analytics and an AI study assistant.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${inter.variable} ${grotesk.variable} ${jbmono.variable}`}>
      <body className="min-h-dvh antialiased">
        <Sidebar />
        <MobileNav />
        <main className="px-4 pb-16 pt-6 sm:px-6 lg:pl-[264px] lg:pr-8 lg:pt-8">
          <div className="mx-auto max-w-[1320px]">{children}</div>
        </main>
      </body>
    </html>
  );
}
