import { LifeBuoy } from "lucide-react";
import { Card, CardHeader } from "@/components/ui";
import { PageHeader } from "@/components/shell";

export const dynamic = "force-dynamic";

const SECTIONS: { title: string; body: string[] }[] = [
  {
    title: "Accounts & sign-in model",
    body: [
      "What is this? Tracker 360 is a personal preparation workspace. In this build it runs as a single authenticated workspace; the production deployment uses Google Sign-In (Firebase Auth) — no passwords for Google, PW, or anyone else are ever asked for or stored.",
      "Your identity (name, exam, class, student type, target) is editable any time from Settings → Profile. All planner math immediately recalculates.",
    ],
  },
  {
    title: "Connecting your batch (honest integration policy)",
    body: [
      "Three legitimate paths exist. (1) Official authorized integration (OAuth/API) — activates automatically if ever available; only then does the UI show 'Synced'. (2) Manual configuration — full power: batch, subjects, chapters, lectures, durations, completion states. (3) JSON/CSV import via Settings → Import.",
      "Never real: we do not collect PW passwords, scrape PW, or fake synchronization. 'Open class on PW' simply opens pw.live in a new tab where you sign in with your own account; you then report progress back here (or an authorized sync does it, when available).",
      "Every piece of data carries a source tag: pw_authorized / manual / imported.",
    ],
  },
  {
    title: "Teachers",
    body: [
      "Assign a teacher per subject during onboarding or from Batch setup. Teachers are metadata for organization and backlog-by-teacher views — changing a teacher never touches progress.",
    ],
  },
  {
    title: "Student types & how the planner treats them",
    body: [
      "Regular School: fixed school blocks are hard-blocked; planning fits evening slots. Dummy School: more flexible, higher yields, still guarded against impossible days. Dropper: aggressive revision/practice/test weights. College + Prep: college blocks fixed, weekend-heavy. Self-study: you define every slot.",
      "Switch anytime in Settings → Planning configuration; tomorrow's plan regenerates accordingly.",
    ],
  },
  {
    title: "Timetable builder, weekly hours & events",
    body: [
      "The /timetable page models real life: sleep, school, coaching, PW classes, meals, study blocks with focus levels (high/medium/low). Fixed blocks are never overwritten; overlapping fixed blocks are rejected on save.",
      "Weekly hours: set available study hours per weekday (Mon 5h … Sun 10h). The planner's capacity for any date = weekday hours × adaptive load, overridden by custom events.",
      "Events: holidays, sick days, travel, family functions, school-exam weeks. Add with a study-hour override; pending work redistributes automatically. School-exam mode simply lowers JEE capacity during that week and restores after.",
    ],
  },
  {
    title: "The Planner (how plans are made)",
    body: [
      "Pipeline each day: compute capacity → generate candidates (today's running lectures, test prep ≤3d, due/overdue revisions, overdue DPPs, backlog dose, weak-topic drills, PYQ and module blocks) → priority-score each (urgency × importance × weakness × overdue × exam relevance) → greedily fill the day without overflow → persist with a 'why' reason.",
      "Every generated task shows its reason. 'Plan my day' regenerates fresh. 'Replan my day' re-fits the plan into actually-available hours, protecting running classes → revisions → DPPs → tests, and tells you what moved and why.",
      "Modes: Auto (engine plans), Manual (you build), Hybrid (default: engine suggests, you edit). Styles: Balanced, Backlog-focused, Current-focused, Revision-focused, Practice-focused, Exam-focused.",
    ],
  },
  {
    title: "Editing the plan",
    body: [
      "Every task on Today/Planner has a menu (⋯): postpone +1/+2 days, split into two halves (90m → 45m today + 45m tomorrow), resize (30/60/90), or remove. You can never break the plan — editing always recalculates around your change.",
    ],
  },
  {
    title: "Lectures, percentages & playback speed",
    body: [
      "Lectures track watched_pct (0–100), watched minutes and status. Quick-set completion from chapter pages (0/25/50/75/100%) or declare after a Study Mode session (Completed / 25% / 50% / 75% / Not completed).",
      "Preferred playback speed (0.5–3x) only shrinks *time estimates* (a 90-min lecture plans as 60 min at 1.5x). It never marks completion — that stays honest.",
    ],
  },
  {
    title: "Backlog & the Backlog Killer",
    body: [
      "Backlog is computed type-wise and time-weighted: lectures (speed-adjusted remaining), DPPs (3 min/question), PYQs (2.5 min/question), revisions (45 min), tests, notes. /backlog shows each stream plus total estimated hours (e.g., 34 lectures · 32h 10m).",
      "Backlog Killer: pick 7/14/21/30 days × Safe (×1.0) / Balanced (×1.5) / Aggressive (×2.2). It computes the feasible daily backlog dose while protecting running classes + revision + practice, tells you plainly if your window is unrealistic, and applies the distribution to the planner in one click.",
    ],
  },
  {
    title: "Revision engine",
    body: [
      "Completed chapters enter a spaced cycle R1→R6 (default 1/3/7/15/30/60 days — fully customizable in Settings). After each revision you rate recall: Forgot → re-revise tomorrow; Weak → +2 days; Average → standard interval; Good → interval ×1.3; Excellent → interval ×1.6. Due and overdue revisions outrank almost everything because forgotten chapters score zero in the exam.",
    ],
  },
  {
    title: "DPPs, practice & PYQs",
    body: [
      "DPPs track exact question counts (12/20 stays 12/20), accuracy, and honest statuses including Weak and Needs Revision. The Practice page is filterable by subject and source. PYQ sets are tracked per chapter for JEE Main and Advanced.",
    ],
  },
  {
    title: "Tests & deterministic analysis",
    body: [
      "Schedule and attempt tests; log marks + attempted/correct/incorrect/unattempted + mistake taxonomy (conceptual/calculation/silly/time). The analysis rules surface the weakest section, accuracy vs target, and mistake patterns, then the planner injects revision + practice for those chapters automatically. Overdue tests form their own backlog stream with catch-up plans.",
    ],
  },
  {
    title: "Error Book",
    body: [
      "Log any question you got wrong with its mistake type and correct concept. Cycle open → reattempt scheduled (+3 days) → mastered. Due reattempts feed weak-topic drills in the planner.",
    ],
  },
  {
    title: "Study Promise & Study Mode",
    body: [
      "Star tasks on the Today page to form Today's Promise. In /study, start any promised/pending task: the session timer records real minutes into analytics; 'Open class on PW' launches the live class externally; on finish you declare honest completion (Completed / Partial % / Not) and the plan resizes remaining work automatically. Missed promise → no punishment: move, split, backlog, or remove.",
    ],
  },
  {
    title: "Missed-day recovery",
    body: [
      "Miss a day and nothing simply becomes a red blob. The recovery engine identifies unfinished tasks, recalculates future capacity, keeps today's classes untouched, and spreads everything else over the next days with an explanation on the Today screen.",
    ],
  },
  {
    title: "Preparation meters, health & analytics",
    body: [
      "Chapter Prep % = Lectures 25% + DPP 15% + Practice 15% + PYQ 15% + Revision 15% + Tests 10% + Notes 5% (each component visible; manual override available). Preparation Health (Excellent→Critical) combines readiness, backlog trend, revision adherence, practice velocity and schedule adherence — always with reasons. Analytics shows hours, questions, accuracy, backlog trends, subject balance and weekly vs previous-week deltas.",
    ],
  },
  {
    title: "Import, export & data resets",
    body: [
      "Settings → Data: export your entire workspace as JSON anytime. Import accepts progress payloads ({\"lectures\":[{\"id\":12,\"watchedPct\":75}], \"practice\":[{\"id\":4,\"solved\":18}]}) with validation; invalid entries are rejected safely. Resets are tiered and confirmation-guarded: today's plan / planner forward / all progress.",
    ],
  },
  {
    title: "Troubleshooting",
    body: [
      "Sync error? Server actions retry safely and never double-apply — refreshes are idempotent. Page didn't update after an action? Hard refresh once; the app re-streams fresh data. Something looks impossible (negative time, overlapping fixed blocks)? The validators reject it — check the on-screen message. Need help? The Assistant page answers from your live data, deterministically.",
    ],
  },
];

export default function DocsPage() {
  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader
        title="Docs & Help Center"
        sub="What is this? How does it work? How should you use it? — for every part of Tracker 360"
      />
      <div className="space-y-4">
        {SECTIONS.map((s, i) => (
          <Card key={s.title} className={`animate-fade-up`}>
            <CardHeader
              icon={<LifeBuoy size={15} />}
              title={`${i + 1}. ${s.title}`}
            />
            <div className="space-y-2.5">
              {s.body.map((p, j) => (
                <p key={j} className="text-[13px] leading-relaxed text-ink-2">{p}</p>
              ))}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
