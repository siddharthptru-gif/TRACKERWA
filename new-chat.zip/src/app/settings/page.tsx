import Link from "next/link";
import { Settings2, User, Plug, ShieldCheck, Database, FileText, SlidersHorizontal, Download, CalendarClock } from "lucide-react";
import { Card, CardHeader, Chip, Stat } from "@/components/ui";
import { PageHeader } from "@/components/shell";
import { OnboardingCTA } from "@/components/onboarding-cta";
import { ReseedButton, GoalForm } from "@/components/widgets";
import { SettingsForm, ExportButton, ImportBox, ResetZone } from "@/components/widgets2";
import { getUser, getContext, fmtMin } from "@/lib/engine";

export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const user = await getUser();
  if (!user) return <OnboardingCTA />;
  const ctx = await getContext(user.id);
  const s = ctx.settings;
  let weekly: Record<string, number> = { "0": 540, "1": 360, "2": 360, "3": 360, "4": 360, "5": 360, "6": 480 };
  try { weekly = JSON.parse(s?.weeklyMinutes ?? "") ?? weekly; } catch { /* default */ }

  return (
    <div>
      <PageHeader title="Settings" sub="Profile, planning configuration, data & integrations — every knob is real" />

      <div className="grid gap-4 lg:grid-cols-2">
        <Card accent className="lg:col-span-2 animate-fade-up delay-1">
          <CardHeader icon={<SlidersHorizontal size={15} className="text-accent" />} title="Planning configuration" sub="The engine obeys all of this deterministically" />
          <SettingsForm
            initial={{
              planningMode: s?.planningMode ?? "hybrid",
              planningStyle: s?.planningStyle ?? "balanced",
              playbackSpeed: s?.playbackSpeed ?? 1.5,
              motivation: s?.motivation ?? true,
              revisionIntervals: s?.revisionIntervals ?? "1,3,7,15,30,60",
              weeklyMinutes: weekly,
              priorityOrder: s?.priorityOrder ?? "class,revision,dpp,test,backlog,practice,pyq,optional",
              paceLectures: s?.paceLectures ?? 3,
              paceQuestions: s?.paceQuestions ?? 60,
              paceRevisions: s?.paceRevisions ?? 1,
              paceBacklog: s?.paceBacklog ?? 2,
              studentType: user.studentType,
            }}
          />
        </Card>

        <Card className="animate-fade-up delay-2">
          <CardHeader icon={<User size={15} />} title="Profile" />
          <dl className="space-y-3 text-xs">
            {[
              ["Name", user.name],
              ["Class", user.className],
              ["Exam", user.exam],
              ["Student type", user.studentType],
              ["Target rank", `< ${user.targetRank.toLocaleString("en-IN")}`],
              ["Base daily budget", fmtMin(user.dailyMinutes)],
              ["School / college", user.schoolHours],
              ["Adaptive load", `${Math.round(user.adaptiveLoad * 100)}% (auto-tuned by check-ins)`],
            ].map(([k, v]) => (
              <div key={k as string} className="flex items-center justify-between border-b border-line pb-2.5 last:border-0 last:pb-0">
                <dt className="text-ink-3">{k}</dt>
                <dd className="font-medium capitalize text-ink">{v}</dd>
              </div>
            ))}
          </dl>
          <div className="mt-4 border-t border-line pt-4">
            <GoalForm
              initial={{
                dailyMinutes: ctx.goals?.dailyMinutes ?? user.dailyMinutes,
                weeklyQuestions: ctx.goals?.weeklyQuestions ?? 450,
                monthlyChapters: ctx.goals?.monthlyChapters ?? 9,
                targetRankMain: ctx.goals?.targetRankMain ?? user.targetRank,
                targetRankAdv: ctx.goals?.targetRankAdv ?? 1200,
                examDateMain: ctx.goals?.examDateMain,
                examDateAdv: ctx.goals?.examDateAdv,
              }}
            />
          </div>
        </Card>

        <div className="space-y-4">
          <Card className="animate-fade-up delay-3">
            <CardHeader icon={<Plug size={15} />} title="Batch integration" sub={ctx.batch?.name} />
            <div className="rounded-xl border border-line bg-panel-2 p-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-ink">{ctx.batch?.name}</span>
                <Chip color="#FBBF24">manual import</Chip>
              </div>
              <p className="mt-2 text-[11px] leading-relaxed text-ink-3">
                Running in <span className="font-medium text-ink-2">manual configuration mode</span>. Tracker 360 never
                stores coaching passwords, never scrapes, and never claims sync that didn't happen. The
                {" "}<span className="font-mono text-[10px]">LearningPlatformIntegration</span> seam is ready for an
                official authorized PW connection; until then every value here carries a <span className="font-medium text-ink-2">manual</span> source tag.
              </p>
              <div className="mt-3 flex items-center gap-2 text-[10px] text-ink-3">
                <ShieldCheck size={12} className="text-accent" /> No passwords · no scraping · no fake sync
              </div>
            </div>
            <div className="mt-3 grid grid-cols-3 gap-2">
              {ctx.teachers.map((t) => (
                <div key={t.id} className="rounded-lg border border-line bg-panel-2 p-2 text-[10px]">
                  <div className="uppercase tracking-wider text-ink-3">{t.subjectSlug}</div>
                  <div className="mt-0.5 font-medium text-ink-2">{t.name}</div>
                </div>
              ))}
            </div>
          </Card>

          <Card className="animate-fade-up delay-4">
            <CardHeader icon={<CalendarClock size={15} />} title="Timetable & events" />
            <p className="mb-2 text-[11px] text-ink-3">Blocks, weekly hours and exceptions live on their own screen.</p>
            <Link href="/timetable" className="text-xs font-medium text-accent hover:underline">Open timetable builder →</Link>
          </Card>

          <Card className="animate-fade-up delay-5">
            <CardHeader icon={<Download size={15} />} title="Data — export & import" sub="Your data is yours" />
            <ExportButton />
            <div className="mt-3 border-t border-line pt-3">
              <ImportBox />
            </div>
          </Card>
        </div>

        <Card className="animate-fade-up delay-4">
          <CardHeader icon={<Database size={15} />} title="Workspace & resets" sub="Confirmation-guarded, tiered" />
          <div className="mb-4 grid grid-cols-3 gap-3">
            <Stat label="Chapters" value={String(ctx.chapters.length)} />
            <Stat label="Lectures" value={String(ctx.lectures.length)} />
            <Stat label="Practice sets" value={String(ctx.practice.length)} />
          </div>
          <ResetZone />
          <div className="mt-4 border-t border-line pt-3">
            <p className="mb-2 text-[11px] text-ink-3">Restore the complete realistic demo dataset (fresh dates):</p>
            <ReseedButton />
          </div>
        </Card>

        <Card className="animate-fade-up delay-5">
          <CardHeader icon={<FileText size={15} />} title="Product blueprint & help" />
          <p className="mb-3 text-[11px] leading-relaxed text-ink-3">
            The v2 PRD — deterministic planner math, revision/backlog/health engines, integration & security architecture, roadmap.
          </p>
          <div className="flex gap-3">
            <Link href="/prd" className="text-xs font-medium text-accent hover:underline">Read the PRD →</Link>
            <Link href="/docs" className="text-xs font-medium text-accent hover:underline">Docs & Help Center →</Link>
          </div>
        </Card>
      </div>
    </div>
  );
}
