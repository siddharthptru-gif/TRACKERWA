import { readFile } from "fs/promises";
import path from "path";
import { Card, CardHeader } from "@/components/ui";
import { PageHeader } from "@/components/shell";
import { FileText } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function PrdPage() {
  let content = "PRD.md not found in the project root.";
  try {
    content = await readFile(path.join(process.cwd(), "PRD.md"), "utf-8");
  } catch {
    /* keep fallback */
  }
  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader title="Product Requirements Document" sub="The blueprint Tracker 360 was built from" />
      <Card>
        <CardHeader icon={<FileText size={15} />} title="PRD.md" sub="23 sections · strategy → algorithms → roadmap" />
        <pre className="whitespace-pre-wrap font-sans text-[13px] leading-relaxed text-ink-2">{content}</pre>
      </Card>
    </div>
  );
}
