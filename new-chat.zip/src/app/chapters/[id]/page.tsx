import Link from "next/link";
import { notFound } from "next/navigation";
import {
  BookOpen, PenLine, Repeat2, ClipboardList,
  AlertTriangle, Compass, CheckCircle2, Radio, Gauge, Info,
} from "lucide-react";
import { Card, CardHeader, Bar, Chip, Stat, PRACTICE_STATUS } from "@/components/ui";
import { PageHeader } from "@/components/shell";
import { OnboardingCTA } from "@/components/onboarding-cta";
import { PracticeStatus } from "@/components/widgets";
import { LecturePct, PracticeCounts, ChapterOverride } from "@/components/widgets2";
import { chapterPrepBreakdown } from "@/lib/ops";
import {
  getUser, getContext, chapterLectures, chapterPractice, revisionLadder,
  nextAction, todayStr, fmtMin, fmtDate, viewMin,
} from "@/lib/engine";

export const dynamic = "force-dynamic";

const TYPE_LABEL: Record<string, string> = {
  dpp: "DPP", module: "Module", pyq_main: "PYQ · JEE Main", pyq_adv: "PYQ · JEE Adv",
};

export default async function ChapterPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = await getUser();
  if (!user) return <OnboardingCTA />;
  const today = todayStr();
  const ctx = await getContext(user.id);
  const chapter = ctx.chapters.find((c) => c.id === Number(id));
  if (!chapter) notFound();

  const subject = ctx.subjects.find((s) => s.id === chapter.subjectId)!;
  const lecs = chapterLectures(ctx, chapter.id);
  const doneLecs = lecs.filter((l) => l.status === "completed").length;
  const practice = chapterPractice(ctx, chapter.id);
  const ladder = revisionLadder(ctx, chapter.id);
  const weak = ctx.weakTopics.filter((w) => w.chapterId === chapter.id && !w.resolvedAt);
  const tests = ctx.tests.filter((t) => t.subjectId === chapter.subjectId && t.status === "attempted");
  const prep = chapterPrepBreakdown(ctx, chapter.id);
  const next = nextAction(ctx, chapter.id, today);

  const PREP_ROWS: { k: keyof typeof prep; label: string; color: string }[] = [
    { k: "lectures", label: "Lectures", color: "#38BDF8" },
    { k: "dpp", label: "DPP", color: "#FBBF24" },
    { k: "practice", label: "Module practice", color: "#A78BFA" },
    { k: "pyq", label: "PYQs", color: "#F97316" },
    { k: "revision", label: "Revision", color: "#34D399" },
    { k: "tests", label: "Tests", color: "#E879F9" },
    { k: "notes", label: "Notes", color: "#9CA3AF" },
  ];

  return (
    <div>
      <PageHeader
        title={chapter.name}
        sub={`${subject.name} · weightage ${"★".repeat(chapter.weightage)}${"☆".repeat(5 - chapter.weightage)} · ${
          chapter.isCurrent ? "running in batch now" : chapter.status.replace("_", " ")
        }`}
        right={
          <div className="flex gap-2">
            <Chip color={subject.color}>{subject.name}</Chip>
            {chapter.isCurrent && <Chip color="#38BDF8"><Radio size={10} /> LIVE</Chip>}
            {chapter.manualLevel && <Chip color="#FBBF24">{chapter.manualLevel}</Chip>}
          </div>
        }
      />

      {/* chapter control center */}
      <Card accent className="mb-4 animate-fade-up">
        <div className="flex flex-wrap items-start gap-6">
          <div className="flex items-center gap-4">
            <div>
              <div className="text-[10px] font-semibold uppercase tracking-[0.16em] text-accent">Chapter preparation</div>
              <div className="mt-1 flex items-baseline gap-2">
                <span className="font-display text-4xl font-bold tabular text-ink">{prep.total}%</span>
                <Chip color={prep.total >= 76 ? "#34D399" : prep.total >= 51 ? "#FBBF24" : "#A5ABBB"}>{prep.level}</Chip>
              </div>
              <div className="mt-2"><ChapterOverride id={chapter.id} pct={chapter.prepOverride} level={chapter.manualLevel} /></div>
            </div>
          </div>
          <div className="min-w-56 flex-1 space-y-1.5">
            {PREP_ROWS.map((r) => (
              <div key={r.k} className="flex items-center gap-2.5">
                <span className="w-28 shrink-0 text-[10px] text-ink-3">{r.label}</span>
                <Bar pct={prep[r.k] as number} color={r.color} className="flex-1" />
                <span className="w-9 shrink-0 text-right font-mono text-[10px] tabular text-ink-2">{prep[r.k] as number}%</span>
              </div>
            ))}
            <p className="pt-1 text-[10px] text-ink-3">
              Weighted: Lectures 25% · DPP 15% · Practice 15% · PYQ 15% · Revision 15% · Tests 10% · Notes 5%
            </p>
          </div>
          <div className="w-full rounded-xl border border-line bg-panel-2 p-3.5 lg:w-72">
            <div className="flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.16em] text-accent">
              <Compass size={11} /> Next best action
            </div>
            <div className="mt-1.5 font-display text-sm font-semibold text-ink">{next}</div>
            <div className="mt-1 text-[10px] leading-relaxed text-ink-3">
              Computed from: pending lectures → due revision → DPP → PYQ → notes, in that order.
            </div>
            <div className="mt-2 flex gap-1.5">
              <Link href="/study" className="rounded-lg bg-accent px-3 py-1.5 text-[11px] font-semibold text-black transition hover:bg-accent-2">Study now</Link>
              <Link href="/practice" className="rounded-lg border border-line px-3 py-1.5 text-[11px] font-medium text-ink-2 transition hover:text-ink">Practice</Link>
            </div>
          </div>
        </div>
      </Card>

      <div className="mb-4 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Card><Stat label="Lectures" value={`${doneLecs}/${lecs.length}`} sub="watched" /></Card>
        <Card><Stat label="Mastery" value={`${chapter.mastery}%`} tone={chapter.mastery >= 78 ? "good" : chapter.mastery > 0 && chapter.mastery < 55 ? "bad" : undefined} sub="tests + revisions" /></Card>
        <Card><Stat label="Notes" value={chapter.notesDone ? "Done" : "Pending"} tone={chapter.notesDone ? "good" : "warn"} /></Card>
        <Card><Stat label="Revisions" value={`${ladder.filter((r) => r.status === "completed").length}/${ladder.length || ctx.revisionIntervals.length}`} sub="spaced stages" /></Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        {/* lectures with % tracking */}
        <Card className="lg:col-span-1 animate-fade-up delay-1">
          <CardHeader icon={<BookOpen size={15} />} title="Lectures" sub={`honest % tracking · planned at ${ctx.playbackSpeed}x`} />
          <div className="space-y-1">
            {lecs.map((l) => (
              <div key={l.id} className="rounded-lg px-2 py-2 transition hover:bg-panel-2">
                <div className="flex items-center gap-2">
                  <div className="min-w-0 flex-1">
                    <div className={`truncate text-xs font-medium ${l.status === "completed" ? "text-ink-3 line-through" : "text-ink-2"}`}>
                      {l.title}
                    </div>
                    <div className="mt-0.5 flex items-center gap-2 text-[10px] text-ink-3">
                      <span>{l.taughtAt ? (l.taughtAt > today ? `class ${fmtDate(l.taughtAt)}` : `taught ${fmtDate(l.taughtAt)}`) : "upcoming"}</span>
                      <span>·</span>
                      <span>{l.durationMin}m → {viewMin(Math.ceil(l.durationMin * (1 - l.watchedPct / 100)), ctx.playbackSpeed)}m to finish</span>
                      {l.status === "partial" && <span className="text-warn">resumes {Math.round(l.watchedPct)}%</span>}
                    </div>
                  </div>
                  <span className="shrink-0 font-mono text-[10px] tabular" style={{ color: l.watchedPct >= 95 ? "#34D399" : l.watchedPct > 0 ? "#FBBF24" : "#6b7280" }}>
                    {Math.round(l.watchedPct)}%
                  </span>
                </div>
                <div className="mt-1.5 flex items-center gap-2">
                  <div className="flex-1"><Bar pct={l.watchedPct} color={l.watchedPct >= 95 ? "#34D399" : "#38BDF8"} /></div>
                  <LecturePct id={l.id} pct={l.watchedPct} />
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* practice with counts */}
        <Card className="lg:col-span-1 animate-fade-up delay-2">
          <CardHeader icon={<PenLine size={15} />} title="Practice" sub="12/20 stays 12/20 — never auto-rounded" />
          <div className="space-y-2.5">
            {practice.map((p) => {
              const meta = PRACTICE_STATUS[p.status] ?? PRACTICE_STATUS.not_started;
              return (
                <div key={p.id} className="rounded-xl border border-line bg-panel-2 p-3">
                  <div className="flex items-center justify-between gap-2">
                    <div className="text-xs font-medium text-ink">{TYPE_LABEL[p.type] ?? p.type}</div>
                    <PracticeStatus id={p.id} status={p.status} />
                  </div>
                  <div className="mt-1.5 flex items-center justify-between text-[10px] text-ink-3">
                    <span className="truncate">{p.title}</span>
                    {p.correct != null && <span className="tabular">{p.correct}✓ / {p.incorrect}✗{p.accuracy != null ? ` · ${Math.round(p.accuracy)}%` : ""}</span>}
                  </div>
                  <div className="mt-2 flex items-center gap-2">
                    <div className="flex-1"><Bar pct={(p.solved / Math.max(1, p.totalQuestions)) * 100} color={meta.color} /></div>
                    <PracticeCounts id={p.id} solved={p.solved} total={p.totalQuestions} />
                  </div>
                </div>
              );
            })}
          </div>
        </Card>

        {/* revision + tests + weak */}
        <div className="space-y-4 lg:col-span-1">
          <Card className="animate-fade-up delay-3">
            <CardHeader icon={<Repeat2 size={15} />} title="Revision ladder" sub={`intervals: ${ctx.revisionIntervals.join("/")} days`} />
            {ladder.length === 0 ? (
              <p className="text-xs text-ink-3">The cycle starts automatically when all lectures of this chapter complete.</p>
            ) : (
              <div className="space-y-1.5">
                {ladder.map((r) => {
                  const state =
                    r.status === "completed" ? { c: "#34D399", t: r.feedback ? `${r.feedback} recall` : "done" }
                    : r.dueDate <= today ? { c: "#FBBF24", t: r.dueDate < today ? "overdue" : "due today" }
                    : { c: "#6b7280", t: `due ${fmtDate(r.dueDate)}` };
                  return (
                    <div key={r.id} className="flex items-center justify-between rounded-lg border border-line bg-panel-2 px-3 py-2">
                      <span className="text-xs font-medium text-ink-2">R{r.stage}</span>
                      <span className="text-[11px] tabular" style={{ color: state.c }}>{state.t}</span>
                    </div>
                  );
                })}
              </div>
            )}
          </Card>

          <Card className="animate-fade-up delay-4">
            <CardHeader icon={<ClipboardList size={15} />} title="Test performance" sub={subject.name} />
            {tests.length === 0 ? (
              <p className="text-xs text-ink-3">No attempted {subject.name} tests yet.</p>
            ) : (
              <div className="space-y-1.5">
                {tests.slice(0, 4).map((t) => (
                  <div key={t.id} className="flex items-center justify-between rounded-lg border border-line bg-panel-2 px-3 py-2 text-xs">
                    <span className="truncate text-ink-2">{t.title}</span>
                    <span className="tabular text-ink">{t.obtainedMarks}/{t.totalMarks}</span>
                  </div>
                ))}
              </div>
            )}
          </Card>

          <Card className="animate-fade-up delay-5">
            <CardHeader icon={<AlertTriangle size={15} className="text-danger" />} title="Weak topics" sub="deterministic flags from test accuracy + repeated misses" />
            {weak.length === 0 ? (
              <div className="flex items-center gap-2 text-xs text-ink-3"><CheckCircle2 size={13} className="text-accent" /> None flagged in this chapter.</div>
            ) : (
              <ul className="space-y-1.5">
                {weak.map((w) => (
                  <li key={w.id} className="rounded-lg border border-danger/25 bg-danger/[0.06] px-3 py-2">
                    <div className="text-xs font-medium text-ink">{w.topic}</div>
                    <div className="mt-0.5 text-[10px] text-ink-3">severity {w.severity}/3 · {w.source}</div>
                  </li>
                ))}
              </ul>
            )}
            <div className="mt-3 flex items-start gap-1.5 text-[10px] leading-relaxed text-ink-3">
              <Info size={11} className="mt-0.5 shrink-0" />
              Weak topics add drill blocks to your plan automatically until resolved.
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
