import Link from "next/link";
import { BookOpen } from "lucide-react";
import { Card, CardHeader, Chip, Bar } from "@/components/ui";
import { PageHeader } from "@/components/shell";
import { OnboardingCTA } from "@/components/onboarding-cta";
import {
  getUser, getContext, lectureProgress, chapterPractice, nextAction, todayStr,
} from "@/lib/engine";

export const dynamic = "force-dynamic";

export default async function ChaptersPage({
  searchParams,
}: { searchParams: Promise<{ subject?: string; status?: string }> }) {
  const { subject, status } = await searchParams;
  const user = await getUser();
  if (!user) return <OnboardingCTA />;
  const today = todayStr();
  const ctx = await getContext(user.id);

  const selSubject = subject ?? "all";
  const selStatus = status ?? "all";

  const rows = ctx.chapters
    .filter((c) => (selSubject === "all" ? true : ctx.subjects.find((s) => s.slug === selSubject)?.id === c.subjectId))
    .filter((c) => (selStatus === "all" ? true : c.status === selStatus))
    .sort((a, b) => a.position - b.position)
    .map((c) => {
      const subj = ctx.subjects.find((s) => s.id === c.subjectId)!;
      const lp = lectureProgress(ctx, c.id);
      const pr = chapterPractice(ctx, c.id);
      return {
        c, subj, lp,
        prDone: pr.filter((p) => p.status === "completed").length,
        prTotal: pr.length,
        next: nextAction(ctx, c.id, today),
      };
    });

  const filterLink = (s: string, st: string) => `/chapters?subject=${s}&status=${st}`;

  return (
    <div>
      <PageHeader title="Chapters" sub={`${rows.length} chapters · every lecture, DPP, PYQ and revision tracked`} />

      <div className="mb-4 flex flex-wrap items-center gap-1.5 animate-fade-up">
        <Chip className="mr-1">Subject:</Chip>
        {[{ slug: "all", name: "All" }, ...ctx.subjects].map((s) => (
          <Link key={s.slug} href={filterLink(s.slug, selStatus)}>
            <Chip color={selSubject === s.slug ? ("color" in s && s.color ? s.color : "#34D399") : undefined}>
              {s.name}
            </Chip>
          </Link>
        ))}
        <span className="mx-2 h-4 w-px bg-line" />
        {["all", "completed", "in_progress", "not_started"].map((st) => (
          <Link key={st} href={filterLink(selSubject, st)}>
            <Chip color={selStatus === st ? "#34D399" : undefined}>
              {st === "all" ? "Any status" : st.replace("_", " ")}
            </Chip>
          </Link>
        ))}
      </div>

      <Card className="animate-fade-up delay-1">
        <CardHeader icon={<BookOpen size={15} />} title="Syllabus tracker" sub={`${ctx.batch?.name ?? ""}`} />
        <div className="divide-y divide-line">
          {rows.map(({ c, subj, lp, prDone, prTotal, next }) => (
            <Link key={c.id} href={`/chapters/${c.id}`} className="flex items-center gap-3 px-1 py-2.5 transition hover:bg-panel-2">
              <span className="hidden w-28 shrink-0 truncate text-[11px] font-medium sm:block" style={{ color: subj.color }}>
                {subj.name}
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span className="truncate text-[13px] font-medium text-ink">{c.name}</span>
                  {c.isCurrent && <Chip color="#38BDF8">LIVE</Chip>}
                  {c.mastery > 0 && c.mastery < 55 && <Chip color="#FB7185">weak</Chip>}
                </div>
                <div className="mt-0.5 truncate text-[11px] text-ink-3">{next}</div>
              </div>
              <div className="hidden w-36 shrink-0 md:block">
                <div className="mb-1 flex justify-between text-[10px] text-ink-3">
                  <span>L {lp.done}/{lp.total}</span>
                  <span>P {prDone}/{prTotal}</span>
                  <span className="tabular">{lp.pct}%</span>
                </div>
                <Bar pct={lp.pct} color={subj.color} />
              </div>
              <span className="w-10 text-right font-mono text-[10px] tabular text-ink-3">W{c.weightage}</span>
            </Link>
          ))}
        </div>
      </Card>
    </div>
  );
}
