import { ShieldCheck, Sparkles, ClipboardCheck, HeartPulse, CalendarCheck2 } from "lucide-react";
import { Card, CardHeader, Bar, Chip } from "@/components/ui";
import Link from "next/link";
import { Star } from "lucide-react";
import { PageHeader } from "@/components/shell";
import { TaskList } from "@/components/task-list";
import { OnboardingCTA } from "@/components/onboarding-cta";
import { ReplanButton, CheckinForm } from "@/components/widgets";
import { ReplanForm } from "@/components/widgets2";
import {
  getUser, getContext, ensurePlan, tasksFor, todayStr, fmtMin, fmtDateFull,
  availableMinutesFor,
} from "@/lib/engine";
import { eq, and } from "drizzle-orm";
import { db } from "@/db";
import { checkins } from "@/db/schema";

export const dynamic = "force-dynamic";

export default async function TodayPage() {
  const user = await getUser();
  if (!user) return <OnboardingCTA />;

  const today = todayStr();
  const result = await ensurePlan(user.id);
  const ctx = await getContext(user.id);
  const tasks = await tasksFor(user.id, today);
  const pending = tasks.filter((t) => t.status === "pending");
  const done = tasks.filter((t) => t.status === "done");
  const plannedMin = tasks.reduce((s, t) => s + t.estMin, 0);
  const doneMin = done.reduce((s, t) => s + t.estMin, 0);
  const cap = availableMinutesFor(ctx, today);
  const promised = tasks.filter((t) => t.promised);
  const promisedDone = promised.filter((t) => t.status === "done").length;
  const todayEvent = ctx.events.find((e) => e.date === today);
  const subjectColors = new Map(ctx.subjects.map((s) => [s.id, s.color]));
  const chapterOf = (lecId: number) => ctx.lectures.find((l) => l.id === lecId)?.chapterId ?? null;

  const existingCheckin = await db
    .select()
    .from(checkins)
    .where(and(eq(checkins.userId, user.id), eq(checkins.date, today)));

  const recovered = tasks.filter((t) => t.reason.includes("Recovered"));

  return (
    <div>
      <PageHeader
        title="Today"
        sub={`${fmtDateFull(today)} · ${pending.length} pending · ${done.length} done`}
        right={<ReplanButton />}
      />

      {(result.recovered ?? 0) > 0 || recovered.length > 0 ? (
        <div className="mb-4 flex items-start gap-3 rounded-2xl border border-warn/25 bg-warn/[0.06] px-4 py-3 animate-fade-up">
          <ShieldCheck size={16} className="mt-0.5 shrink-0 text-warn" />
          <p className="text-xs leading-relaxed text-ink-2">
            <span className="font-semibold text-warn">Recovery mode is on.</span>{" "}
            You missed a day recently — nothing is marked as a failure. {recovered.length || result.recovered} pending task(s)
            were redistributed across the next 3 days at a sustainable load. Don't try to do everything at once.
          </p>
        </div>
      ) : null}

      <div className="grid grid-cols-12 gap-4">
        <div className="col-span-12 space-y-4 lg:col-span-7">
          {/* promise strip */}
          <Card className="animate-fade-up delay-1 !p-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <Star size={15} className="text-warn" />
                <div>
                  <div className="font-display text-sm font-semibold text-ink">Today's promise</div>
                  <div className="text-[11px] text-ink-3">
                    {promised.length === 0
                      ? "Star tasks below to promise them — then run them in Study Mode"
                      : `${promisedDone}/${promised.length} kept · ${promised.filter((t) => t.status !== "done").length} remaining`}
                  </div>
                </div>
              </div>
              <Link href="/study" className="rounded-lg bg-accent px-3.5 py-2 text-xs font-semibold text-black transition hover:bg-accent-2">
                Open Study Mode →
              </Link>
            </div>
          </Card>

          <Card className="animate-fade-up delay-1">
            <CardHeader
              icon={<CalendarCheck2 size={15} />}
              title="Today's priority queue"
              sub="Ordered by the planner's priority score · every task shows WHY it exists"
              right={<Chip color="#34D399">{pending.length} left</Chip>}
            />
            <TaskList tasks={pending} subjectColors={subjectColors} chapterOf={chapterOf} />
          </Card>

          {done.length > 0 && (
            <Card className="animate-fade-up delay-2">
              <CardHeader icon={<Sparkles size={15} />} title={`Completed (${done.length})`} />
              <TaskList tasks={done} subjectColors={subjectColors} chapterOf={chapterOf} compact />
            </Card>
          )}
        </div>

        <div className="col-span-12 space-y-4 lg:col-span-5">
          <Card className="animate-fade-up delay-1">
            <CardHeader
              icon={<HeartPulse size={15} />}
              title="Capacity"
              sub={todayEvent ? `Override active: ${todayEvent.label}` : `Weekly hours × adaptive load (${Math.round(user.adaptiveLoad * 100)}%)`}
            />
            <div className="mb-2 flex items-end justify-between">
              <div className="font-display text-2xl font-bold tabular text-ink">{fmtMin(plannedMin)}</div>
              <div className="text-xs text-ink-3">of {fmtMin(cap)} capacity</div>
            </div>
            <Bar pct={(plannedMin / Math.max(1, cap)) * 100} />
            <div className="mt-4 border-t border-line pt-3.5">
              <div className="mb-2 text-[10px] font-semibold uppercase tracking-[0.14em] text-ink-3">Got less time than expected?</div>
              <ReplanForm current={cap} />
            </div>
          </Card>

          <Card accent className="animate-fade-up delay-2">
            <CardHeader
              icon={<ClipboardCheck size={15} className="text-accent" />}
              title="Evening check-in"
              sub="2 minutes · recalibrates tomorrow automatically"
            />
            {existingCheckin.length > 0 ? (
              <div className="space-y-2 text-xs text-ink-2">
                <p className="font-semibold text-accent">Checked in — tomorrow's plan is recalibrated.</p>
                {(() => {
                  const c = existingCheckin[existingCheckin.length - 1];
                  return (
                    <ul className="space-y-1 text-ink-3">
                      <li>Study time: <span className="tabular text-ink-2">{fmtMin(c.minutes)}</span></li>
                      <li>Lectures {c.lecturesDone} · Questions {c.questionsSolved} · Revisions {c.revisionsDone}</li>
                      <li>Energy {c.energy}/5 · Completion {Math.round(c.completionRate * 100)}%</li>
                    </ul>
                  );
                })()}
              </div>
            ) : (
              <CheckinForm />
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
