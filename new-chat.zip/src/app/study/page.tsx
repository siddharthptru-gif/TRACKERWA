import { Play, Star, ShieldCheck, Timer } from "lucide-react";
import { Card, CardHeader, Chip, Ring } from "@/components/ui";
import { PageHeader } from "@/components/shell";
import { OnboardingCTA } from "@/components/onboarding-cta";
import { StudyMode } from "@/components/widgets2";
import {
  getUser, ensurePlan, tasksFor, todayStr, fmtMin, fmtDateFull, getContext,
} from "@/lib/engine";
import { db } from "@/db";
import { studySessions } from "@/db/schema";
import { eq, and } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function StudyPage() {
  const user = await getUser();
  if (!user) return <OnboardingCTA />;
  const today = todayStr();
  await ensurePlan(user.id);
  const ctx = await getContext(user.id);
  const tasks = await tasksFor(user.id, today);
  const pending = tasks.filter((t) => t.status === "pending");
  const promised = tasks.filter((t) => t.promised);
  const promisedDone = promised.filter((t) => t.status === "done").length;
  const promisePct = promised.length ? Math.round((promisedDone / promised.length) * 100) : 0;

  const sessions = await db.select().from(studySessions)
    .where(and(eq(studySessions.userId, user.id), eq(studySessions.date, today)));
  const sessionMin = sessions.reduce((s, x) => s + x.minutes, 0);

  const subjectName = (id: number | null) => ctx.subjects.find((s) => s.id === id)?.name ?? null;
  const studyTasks = (promised.length ? promised : pending).map((t) => ({
    id: t.id, title: t.title, kind: t.kind, estMin: t.estMin,
    subjectName: subjectName(t.subjectId), refType: t.refType,
  })).filter((t) => t.id && pending.some((p) => p.id === t.id));

  return (
    <div>
      <PageHeader
        title="Study Mode"
        sub={`${fmtDateFull(today)} · promise it, start it, track it honestly`}
        right={<Chip color="#34D399"><Timer size={10} /> {fmtMin(sessionMin)} in sessions today</Chip>}
      />

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-4">
          <Card accent className="animate-fade-up delay-1">
            <CardHeader
              icon={<Play size={15} className="text-accent" />}
              title="Start a task"
              sub={promised.length ? "Working from your promise list" : "Star tasks in Today to build a promise list"}
            />
            <StudyMode tasks={studyTasks} />
          </Card>

          <Card className="animate-fade-up delay-2">
            <CardHeader icon={<ShieldCheck size={15} />} title="Honest-tracking contract" sub="Why Tracker 360 never lies to you" />
            <ul className="space-y-2 text-xs leading-relaxed text-ink-3">
              <li><span className="font-medium text-ink-2">Completion = your declaration + tracked progress.</span> Playback speed only adjusts *estimates*, never marks anything done.</li>
              <li><span className="font-medium text-ink-2">Partial is real.</span> 42% watched is stored as 42% — remaining minutes are re-planned, not forgotten.</li>
              <li><span className="font-medium text-ink-2">Sessions are real minutes.</span> The timer feeds your daily/weekly/monthly study analytics.</li>
            </ul>
          </Card>
        </div>

        <div className="space-y-4">
          <Card className="animate-fade-up delay-1">
            <CardHeader icon={<Star size={15} className="text-warn" />} title="Today's promise" sub="Star tasks on the Today page" />
            {promised.length === 0 ? (
              <p className="py-4 text-center text-xs text-ink-3">
                No promise yet. Star up to 4 tasks on the <a href="/today" className="text-accent hover:underline">Today</a> page and they appear here.
              </p>
            ) : (
              <div className="flex items-center gap-5">
                <Ring pct={promisePct} size={110} stroke={9} color="var(--color-warn)" sub="kept" />
                <div className="space-y-1.5 text-xs">
                  {promised.map((t) => (
                    <div key={t.id} className="flex items-center gap-1.5">
                      <span className={t.status === "done" ? "text-accent" : "text-ink-3"}>
                        {t.status === "done" ? "✓" : "○"}
                      </span>
                      <span className={`truncate ${t.status === "done" ? "text-ink-3 line-through" : "text-ink-2"}`}>{t.title}</span>
                    </div>
                  ))}
                  <div className="pt-1 font-mono text-[10px] tabular text-ink-3">{promisedDone}/{promised.length} tasks kept</div>
                </div>
              </div>
            )}
          </Card>

          <Card className="animate-fade-up delay-2">
            <CardHeader icon={<Timer size={15} />} title="Recent sessions" />
            {sessions.length === 0 ? (
              <p className="py-3 text-center text-xs text-ink-3">No sessions logged today yet.</p>
            ) : (
              <div className="space-y-1.5">
                {sessions.slice(-6).reverse().map((s) => (
                  <div key={s.id} className="flex items-center justify-between rounded-lg border border-line bg-panel-2 px-3 py-2 text-xs">
                    <span className="text-ink-2">{s.startedAt ? s.startedAt.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" }) : "—"}</span>
                    <span className="tabular text-ink">{fmtMin(s.minutes)}</span>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
