import Link from "next/link";
import { History, ShieldCheck, Info, Zap } from "lucide-react";
import { Card, CardHeader, Chip, Stat } from "@/components/ui";
import { PageHeader } from "@/components/shell";
import { OnboardingCTA } from "@/components/onboarding-cta";
import { KillerLauncher } from "@/components/widgets2";
import { Spark } from "@/components/charts";
import { getUser, getContext, todayStr, fmtMin, fmtDate, dayName } from "@/lib/engine";
import { backlogBreakdown, backlogKiller } from "@/lib/ops";

export const dynamic = "force-dynamic";

export default async function BacklogPage() {
  const user = await getUser();
  if (!user) return <OnboardingCTA />;
  const today = todayStr();
  const ctx = await getContext(user.id);
  const bd = backlogBreakdown(ctx, today);
  const preview = backlogKiller(ctx, today, 14, "balanced");
  const trend = ctx.metrics.slice(-30).map((m) => m.backlogCount);

  const lecSlice = bd.slices.find((s) => s.key === "lecture");

  return (
    <div>
      <PageHeader
        title="Backlog Killer"
        sub="Every backlog type, with real time attached — and a recovery plan that protects your current batch"
      />

      {bd.totalCount === 0 ? (
        <Card accent className="animate-fade-up">
          <div className="flex items-start gap-3">
            <ShieldCheck size={18} className="mt-0.5 text-accent" />
            <div>
              <div className="font-display text-sm font-semibold text-ink">Zero backlog across every stream.</div>
              <p className="mt-1 max-w-lg text-xs leading-relaxed text-ink-3">
                Lectures, DPPs, revisions, tests, PYQs, notes — all clear. The planner reinvests this capacity into
                PYQ velocity and Advanced-level practice automatically.
              </p>
            </div>
          </div>
        </Card>
      ) : (
        <>
          <div className="mb-4 grid grid-cols-2 gap-4 lg:grid-cols-4">
            <Card className="animate-fade-up delay-1">
              <Stat label="Total backlog time" value={fmtMin(bd.totalMin)} tone={bd.totalMin > 1800 ? "bad" : "warn"} sub="speed-adjusted, type-weighted" />
            </Card>
            <Card className="animate-fade-up delay-2">
              <Stat label="Lecture backlog" value={String(lecSlice?.count ?? 0)} sub={fmtMin(lecSlice?.minutes ?? 0)} />
            </Card>
            <Card className="animate-fade-up delay-3">
              <Stat label="Balanced kill time" value={`${preview.rows.length}d`} tone="good" sub={`${fmtMin(preview.dailyBacklogMin)}/day dose`} />
            </Card>
            <Card className="animate-fade-up delay-4">
              <Stat label="Protected daily" value={fmtMin(preview.protectedMin)} tone="good" sub="current + revision + practice" />
            </Card>
          </div>

          {/* type-wise breakdown */}
          <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
            {bd.slices.map((s, i) => (
              <Card key={s.key} className={`animate-fade-up delay-${Math.min(5, i)} !p-4`}>
                <div className="flex items-center gap-2">
                  <span className="size-2 rounded-full" style={{ background: s.color }} />
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-ink-3">{s.label}</span>
                </div>
                <div className="mt-2 font-display text-2xl font-bold tabular text-ink">{s.key === "pyq" ? s.count : s.count}</div>
                <div className="text-[10px] text-ink-3">{s.key === "pyq" ? "questions" : "items"} · {fmtMin(s.minutes)}</div>
                <div className="mt-1 text-[10px] text-ink-3">{s.detail}</div>
              </Card>
            ))}
          </div>

          {/* killer console */}
          <Card accent className="mb-4 animate-fade-up delay-2">
            <CardHeader
              icon={<Zap size={15} className="text-danger" />}
              title="Kill switch"
              sub="Pick a window and a mode — the engine checks feasibility honestly before writing anything to your planner"
            />
            <KillerLauncher />
            <div className="mt-3 rounded-xl border border-line bg-panel-2 p-3 text-xs leading-relaxed text-ink-3">
              <span className="font-semibold text-ink-2">Balanced mode preview (14 days):</span> {preview.verdict}
            </div>
          </Card>

          <div className="grid gap-4 lg:grid-cols-3">
            {/* distribution preview */}
            <Card className="lg:col-span-2 animate-fade-up delay-3">
              <CardHeader icon={<History size={15} />} title="Distribution preview" sub="First 8 days of the balanced plan · oldest-first" />
              <div className="space-y-1.5">
                {preview.rows.slice(0, 8).map((r) => (
                  <div key={r.date} className="flex items-start gap-3 rounded-xl border border-line bg-panel-2 px-3 py-2.5">
                    <div className="w-16 shrink-0 pt-0.5">
                      <div className="text-[11px] font-semibold text-ink">{dayName(r.date).slice(0, 3)}</div>
                      <div className="text-[10px] text-ink-3">{fmtDate(r.date)}</div>
                    </div>
                    <div className="min-w-0 flex-1 space-y-1">
                      {r.items.length === 0 && <span className="text-[11px] text-ink-3">No backlog dose — rest or current batch only</span>}
                      {r.items.map((it, i) => (
                        <div key={i} className="flex items-center justify-between gap-2 text-xs">
                          <span className="truncate text-ink-2">{it.title}</span>
                          <span className="shrink-0 font-mono text-[10px] tabular text-ink-3">{fmtMin(it.minutes)}</span>
                        </div>
                      ))}
                    </div>
                    <span className="shrink-0 pt-0.5 font-mono text-[10px] tabular text-accent">{fmtMin(r.minutes)}</span>
                  </div>
                ))}
              </div>
            </Card>

            <div className="space-y-4">
              <Card className="animate-fade-up delay-4">
                <CardHeader icon={<History size={15} />} title="Backlog trend" sub="Last 30 days · lecture count" />
                <Spark data={trend} color={(lecSlice?.count ?? 0) > 15 ? "#FB7185" : "#34D399"} height={90} />
                <div className="mt-2 flex justify-between text-[10px] text-ink-3">
                  <span>30d ago: {trend[0] ?? 0}</span>
                  <span>now: {lecSlice?.count ?? 0}</span>
                </div>
              </Card>
              <Card className="animate-fade-up delay-5">
                <div className="flex items-start gap-2.5 text-xs leading-relaxed text-ink-3">
                  <Info size={14} className="mt-0.5 shrink-0 text-accent" />
                  <p>
                    <span className="font-semibold text-ink-2">Current batch protection is a hard law.</span>{" "}
                    Even in Aggressive mode, {fmtMin(Math.round(preview.protectedMin * 0.7))}/day stays reserved for
                    running classes, revision and questions. In Balanced/Safe modes the full {fmtMin(preview.protectedMin)}
                    {" "}is untouchable. Backlog dies daily — it never eats today.
                  </p>
                </div>
              </Card>
              <Card className="animate-fade-up delay-5">
                <div className="text-xs leading-relaxed text-ink-3">
                  <span className="font-semibold text-ink-2">Time math:</span> lectures priced at your {ctx.playbackSpeed}x
                  speed against <em>remaining</em> content (partial watches count), DPPs at 3 min/question, PYQs at 2.5,
                  revisions at 45 min flat, tests at 3h. Totals always add up to the cards above.
                </div>
              </Card>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
