import { ShieldCheck, Megaphone, Layers, BookOpen, FileText } from "lucide-react";
import { Card, CardHeader, Chip, Stat } from "@/components/ui";
import { PageHeader } from "@/components/shell";
import { OnboardingCTA } from "@/components/onboarding-cta";
import { AnnouncementForm } from "@/components/widgets2";
import { getUser, getContext, todayStr } from "@/lib/engine";
import { db } from "@/db";
import { announcements } from "@/db/schema";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const user = await getUser();
  if (!user) return <OnboardingCTA />;
  const ctx = await getContext(user.id);
  const all = await db.select().from(announcements);
  const latest = all.sort((a, b) => (b.updatedAt?.getTime() ?? 0) - (a.updatedAt?.getTime() ?? 0));

  return (
    <div>
      <PageHeader
        title="Admin"
        sub="Global templates & announcements · student private data is never accessible here"
        right={<Chip color="#FBBF24">guarded by admin flag in production rules</Chip>}
      />

      <div className="grid gap-4 lg:grid-cols-2">
        <Card accent className="animate-fade-up delay-1">
          <CardHeader icon={<Megaphone size={15} className="text-accent" />} title="Announcements" sub="Shown on every student dashboard" />
          <AnnouncementForm />
          <div className="mt-4 space-y-2">
            {latest.slice(0, 5).map((a) => (
              <div key={a.id} className="rounded-xl border border-line bg-panel-2 p-3">
                <p className="text-xs leading-relaxed text-ink-2">{a.text}</p>
                <p className="mt-1 text-[10px] text-ink-3">{a.updatedAt?.toLocaleString("en-IN")}</p>
              </div>
            ))}
          </div>
        </Card>

        <div className="space-y-4">
          <Card className="animate-fade-up delay-2">
            <CardHeader icon={<Layers size={15} />} title="Batch template" sub={ctx.batch?.name ?? "—"} />
            <div className="grid grid-cols-3 gap-3">
              <Stat label="Subjects" value={String(ctx.subjects.length)} />
              <Stat label="Chapters" value={String(ctx.chapters.length)} />
              <Stat label="Lectures" value={String(ctx.lectures.length)} />
            </div>
            <div className="mt-3 text-[11px] leading-relaxed text-ink-3">
              Template source: <span className="font-medium text-ink-2">{ctx.batch?.source ?? "manual"}</span>.
              Global templates are read-only for students; a student may only restructure their own workspace.
            </div>
          </Card>

          <Card className="animate-fade-up delay-3">
            <CardHeader icon={<BookOpen size={15} />} title="Template subjects" />
            <div className="space-y-1.5">
              {ctx.subjects.map((s) => (
                <div key={s.id} className="flex items-center justify-between rounded-lg border border-line bg-panel-2 px-3 py-2 text-xs">
                  <span style={{ color: s.color }}>{s.name}</span>
                  <span className="tabular text-ink-3">
                    {ctx.chapters.filter((c) => c.subjectId === s.id).length} chapters ·{" "}
                    {ctx.lectures.filter((l) => ctx.chapters.some((c) => c.id === l.chapterId && c.subjectId === s.id)).length} lectures
                  </span>
                </div>
              ))}
            </div>
          </Card>

          <Card className="animate-fade-up delay-4">
            <CardHeader icon={<ShieldCheck size={15} />} title="Access boundaries" />
            <ul className="space-y-1.5 text-[11px] leading-relaxed text-ink-3">
              <li>• Students can read/write only their own workspace (profile, plans, progress, goals, timetable).</li>
              <li>• Global batch/chapter templates and announcements are read-only for students.</li>
              <li>• Admin writes (announcements, templates) require the admin flag; student clients can't reach them in production.</li>
              <li>• Unauthenticated requests get nothing. Firebase Security Rules mirror these exact scopes at deploy.</li>
            </ul>
            <div className="mt-3 flex items-center gap-2 text-[11px] text-ink-3">
              <FileText size={12} className="text-accent" />
              <a href="/prd" className="text-accent hover:underline">Full security mapping in the PRD →</a>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
