import Link from "next/link";
import { Repeat2, AlarmClock, CalendarClock, BrainCircuit } from "lucide-react";
import { Card, CardHeader, Chip, Stat, Empty } from "@/components/ui";
import { PageHeader } from "@/components/shell";
import { OnboardingCTA } from "@/components/onboarding-cta";
import { RevisionDone } from "@/components/widgets";
import { getUser, getContext, todayStr, fmtDate, diffDays } from "@/lib/engine";

export const dynamic = "force-dynamic";

export default async function RevisionPage() {
  const user = await getUser();
  if (!user) return <OnboardingCTA />;
  const today = todayStr();
  const ctx = await getContext(user.id);

  const active = ctx.revisions.filter((r) => r.status !== "skipped");
  const dueNow = active
    .filter((r) => r.status !== "completed" && r.dueDate <= today)
    .sort((a, b) => (a.dueDate < b.dueDate ? -1 : 1));
  const upcoming = active
    .filter((r) => r.status !== "completed" && r.dueDate > today)
    .sort((a, b) => (a.dueDate < b.dueDate ? -1 : 1));
  const completed = active
    .filter((r) => r.status === "completed")
    .sort((a, b) => ((b.completedAt?.toISOString() ?? "") > (a.completedAt?.toISOString() ?? "") ? 1 : -1));

  const chName = (id: number) => ctx.chapters.find((c) => c.id === id);
  const subjOf = (id: number) => {
    const ch = chName(id);
    return ch ? ctx.subjects.find((s) => s.id === ch.subjectId) : undefined;
  };

  return (
    <div>
      <PageHeader
        title="Revision"
        sub="Spaced repetition — R1 next day · R2 +3d · R3 +7d · R4 +15d · R5 +30d · adaptive to recall"
        right={<Chip color="#34D399">{completed.length} stages done</Chip>}
      />

      <div className="mb-4 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Card><Stat label="Due now" value={String(dueNow.length)} tone={dueNow.length >= 3 ? "bad" : dueNow.length ? "warn" : "good"} sub="≈45 min each" /></Card>
        <Card><Stat label="Overdue" value={String(dueNow.filter((r) => r.dueDate < today).length)} tone="warn" sub="memory decays daily" /></Card>
        <Card><Stat label="Upcoming stages" value={String(upcoming.length)} sub="next 30 days" /></Card>
        <Card><Stat label="Chapters in cycle" value={String(new Set(active.map((r) => r.chapterId)).size)} sub="completed syllabus" /></Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card accent className="animate-fade-up delay-1">
          <CardHeader icon={<AlarmClock size={15} className="text-accent" />} title="Due now" sub="Do these before any new lecture" />
          {dueNow.length === 0 ? (
            <Empty icon={<Repeat2 size={20} />} title="Queue is clean" body="Nothing due today. The planner has redirected this slot to PYQ practice." />
          ) : (
            <div className="space-y-2">
              {dueNow.map((r) => {
                const ch = chName(r.chapterId);
                const od = diffDays(today, r.dueDate);
                return (
                  <div key={r.id} className="flex items-center gap-3 rounded-xl border border-line bg-panel-2 px-3 py-2.5">
                    <div className="min-w-0 flex-1">
                      <Link href={`/chapters/${r.chapterId}`} className="block truncate text-[13px] font-medium text-ink hover:text-accent">
                        Revision {r.stage} · {ch?.name}
                      </Link>
                      <div className="mt-0.5 flex items-center gap-2 text-[10px] text-ink-3">
                        <span style={{ color: subjOf(r.chapterId)?.color }}>{subjOf(r.chapterId)?.name}</span>
                        {od > 0
                          ? <span className="text-danger">overdue by {od}d — boosted priority</span>
                          : <span>due today · stage R{r.stage} of 5</span>}
                      </div>
                    </div>
                    <RevisionDone id={r.id} />
                  </div>
                );
              })}
            </div>
          )}
        </Card>

        <Card className="animate-fade-up delay-2">
          <CardHeader icon={<CalendarClock size={15} />} title="Upcoming" sub="Scheduled by the spaced-repetition engine" />
          {upcoming.length === 0 ? (
            <Empty icon={<CalendarClock size={20} />} title="Nothing scheduled" body="Complete a chapter's lectures and its 5-stage revision cycle appears here automatically." />
          ) : (
            <div className="space-y-1.5">
              {upcoming.slice(0, 10).map((r) => {
                const ch = chName(r.chapterId);
                return (
                  <div key={r.id} className="flex items-center justify-between rounded-lg border border-line bg-panel-2 px-3 py-2">
                    <Link href={`/chapters/${r.chapterId}`} className="min-w-0 truncate text-xs font-medium text-ink-2 hover:text-ink">
                      R{r.stage} · {ch?.name}
                    </Link>
                    <span className="shrink-0 font-mono text-[10px] tabular text-ink-3">
                      {fmtDate(r.dueDate)} · in {diffDays(r.dueDate, today)}d
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </Card>
      </div>

      <Card className="mt-4 animate-fade-up delay-3">
        <CardHeader icon={<BrainCircuit size={15} />} title="Adaptive rules" sub="The cycle bends to your performance" />
        <div className="grid gap-4 text-xs leading-relaxed text-ink-3 md:grid-cols-3">
          <div><span className="font-semibold text-ink-2">Recall &lt; 60%?</span> The chapter regresses two stages and is due again tomorrow, and its weak topics get drills injected into your plan.</div>
          <div><span className="font-semibold text-ink-2">Poor test in a chapter?</span> Its revision priority rises automatically — test analysis feeds the scheduler.</div>
          <div><span className="font-semibold text-ink-2">Consistently strong recall?</span> Later stages stretch out, freeing capacity for new syllabus and Advanced practice.</div>
        </div>
      </Card>
    </div>
  );
}
