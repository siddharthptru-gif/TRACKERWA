import { CalendarClock, CalendarX2, ShieldAlert } from "lucide-react";
import { Card, CardHeader, Chip } from "@/components/ui";
import { PageHeader } from "@/components/shell";
import { OnboardingCTA } from "@/components/onboarding-cta";
import { TimetableEditor, EventForm, DeleteEvent, type BlockRow } from "@/components/widgets2";
import { getUser, getContext, todayStr, fmtDate, fmtMin, availableMinutesFor, addDays } from "@/lib/engine";

export const dynamic = "force-dynamic";

const KIND_COLOR: Record<string, string> = {
  sleep: "#6b7280", school: "#FB7185", college: "#FB7185", travel: "#A5ABBB",
  meal: "#FBBF24", pw_class: "#38BDF8", coaching: "#38BDF8", study: "#34D399",
  break: "#A78BFA", exercise: "#6EE7B7", personal: "#E879F9", other: "#A5ABBB",
};

const hh = (m: number) => {
  const h = Math.floor(m / 60), mm = m % 60;
  const ampm = h >= 12 ? "PM" : "AM";
  const h12 = h % 12 === 0 ? 12 : h % 12;
  return `${h12}:${String(mm).padStart(2, "0")} ${ampm}`;
};

export default async function TimetablePage() {
  const user = await getUser();
  if (!user) return <OnboardingCTA />;
  const today = todayStr();
  const ctx = await getContext(user.id);

  const blocks = ctx.blocks.slice().sort((a, b) => a.startMin - b.startMin);
  const fixed = blocks.filter((b) => b.fixed);
  const study = blocks.filter((b) => b.kind === "study");

  const next7 = Array.from({ length: 7 }, (_, i) => {
    const d = addDays(today, i);
    return { date: d, mins: availableMinutesFor(ctx, d), event: ctx.events.find((e) => e.date === d) };
  });

  return (
    <div>
      <PageHeader
        title="Timetable"
        sub="Your real life, modeled. Fixed blocks are sacred — the planner only fills what remains."
        right={<Chip color="#34D399">{fmtMin(availableMinutesFor(ctx, today))} available today</Chip>}
      />

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2 animate-fade-up delay-1">
          <CardHeader icon={<CalendarClock size={15} />} title="Daily schedule builder" sub="Recurring every day · edit anything" />
          <TimetableEditor
            initial={blocks.map((b) => ({
              dayOfWeek: b.dayOfWeek, startMin: b.startMin, endMin: b.endMin,
              kind: b.kind, label: b.label, fixed: b.fixed, focus: b.focus,
            })) satisfies BlockRow[]}
          />
        </Card>

        <div className="space-y-4">
          <Card className="animate-fade-up delay-2">
            <CardHeader icon={<CalendarClock size={15} />} title="Your day at a glance" sub={`${fixed.length} fixed · ${study.length} study blocks`} />
            <div className="space-y-1">
              {blocks.map((b) => (
                <div key={b.id} className="flex items-center gap-2.5">
                  <span className="w-20 shrink-0 text-right font-mono text-[10px] tabular text-ink-3">{hh(b.startMin)}</span>
                  <span className="h-6 w-1 shrink-0 rounded-full" style={{ background: KIND_COLOR[b.kind] ?? "#A5ABBB" }} />
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-xs font-medium text-ink-2">
                      {b.label}
                      {!b.fixed && <span className="ml-1.5 text-[9px] text-accent">flexible · planner-fills</span>}
                      {b.kind === "study" && b.focus !== "any" && <span className="ml-1.5 text-[9px] text-ink-3">{b.focus} focus</span>}
                    </div>
                  </div>
                  <span className="shrink-0 font-mono text-[10px] tabular text-ink-3">{b.endMin - b.startMin}m</span>
                </div>
              ))}
            </div>
          </Card>

          <Card className="animate-fade-up delay-3">
            <CardHeader icon={<CalendarX2 size={15} />} title="Events & exceptions" sub="Holidays, sick days, school exams" />
            <EventForm />
            <div className="mt-3 space-y-1.5">
              {ctx.events.length === 0 && <p className="text-xs text-ink-3">No events. Add one and the planner redistributes automatically.</p>}
              {ctx.events
                .slice()
                .sort((a, b) => (a.date < b.date ? -1 : 1))
                .map((e) => (
                  <div key={e.id} className="flex items-center gap-2 rounded-lg border border-line bg-panel-2 px-3 py-2">
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-xs font-medium text-ink">{e.label}</div>
                      <div className="text-[10px] text-ink-3">{fmtDate(e.date)} · {e.kind.replace("_", " ")} · {fmtMin(e.availableMinutes)} study</div>
                    </div>
                    <DeleteEvent id={e.id} />
                  </div>
                ))}
            </div>
          </Card>

          <Card className="animate-fade-up delay-4">
            <CardHeader icon={<ShieldAlert size={15} />} title="Next 7 days availability" sub="Weekly hours × events × adaptive load" />
            <div className="space-y-1.5">
              {next7.map((d) => (
                <div key={d.date} className="flex items-center justify-between text-xs">
                  <span className="text-ink-2">{i18nDay(d.date)} <span className="text-ink-3">{fmtDate(d.date)}</span></span>
                  <span className="tabular" style={{ color: d.mins < 180 ? "var(--color-warn)" : "var(--color-accent)" }}>
                    {fmtMin(d.mins)}{d.event ? ` · ${d.event.label}` : ""}
                  </span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function i18nDay(d: string) {
  return new Date(d + "T00:00:00").toLocaleDateString("en-IN", { weekday: "short" });
}
