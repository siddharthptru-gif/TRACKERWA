import Link from "next/link";
import { BookMarked, Repeat2 } from "lucide-react";
import { Card, CardHeader, Chip, Stat, Empty } from "@/components/ui";
import { PageHeader } from "@/components/shell";
import { OnboardingCTA } from "@/components/onboarding-cta";
import { ErrorForm, ErrorCycle } from "@/components/widgets2";
import { getUser, getContext, todayStr, fmtDate } from "@/lib/engine";

export const dynamic = "force-dynamic";

const MISTAKE_COLORS: Record<string, string> = {
  conceptual: "#FB7185", calculation: "#FBBF24", silly: "#FB923C",
  formula: "#E879F9", reading: "#38BDF8", time: "#A78BFA", guess: "#A5ABBB",
};

export default async function ErrorsPage() {
  const user = await getUser();
  if (!user) return <OnboardingCTA />;
  const today = todayStr();
  const ctx = await getContext(user.id);

  const entries = ctx.errorBook
    .slice()
    .sort((a, b) => (b.createdAt?.getTime() ?? 0) - (a.createdAt?.getTime() ?? 0));
  const open = entries.filter((e) => e.status !== "mastered");
  const dueToday = entries.filter((e) => e.status === "reattempt_scheduled" && e.reattemptDate && e.reattemptDate <= today);

  return (
    <div>
      <PageHeader title="Error Book" sub="Your mistakes, converted into a reattack schedule — this is where rank actually grows" />

      <div className="mb-4 grid grid-cols-3 gap-4">
        <Card><Stat label="Open errors" value={String(open.length)} tone={open.length > 5 ? "warn" : "good"} /></Card>
        <Card><Stat label="Reattempts due" value={String(dueToday.length)} tone={dueToday.length ? "warn" : "good"} sub="scheduled reviews" /></Card>
        <Card><Stat label="Mastered" value={String(entries.filter((e) => e.status === "mastered").length)} tone="good" /></Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2 animate-fade-up delay-1">
          <CardHeader icon={<BookMarked size={15} />} title="Entries" sub="Click the status to cycle: open → reattempt → mastered" />
          {entries.length === 0 ? (
            <Empty icon={<BookMarked size={20} />} title="Error book is empty" body="Log your first mistake below — conceptual, calculation, silly or formula. The planner schedules reattempts." />
          ) : (
            <div className="space-y-2">
              {entries.map((e) => {
                const ch = ctx.chapters.find((c) => c.id === e.chapterId);
                return (
                  <div key={e.id} className="rounded-xl border border-line bg-panel-2 p-3">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <div className="text-xs font-medium leading-relaxed text-ink">{e.question}</div>
                        <div className="mt-1 flex flex-wrap items-center gap-2 text-[10px] text-ink-3">
                          <Chip color={MISTAKE_COLORS[e.mistakeType] ?? "#A5ABBB"}>{e.mistakeType}</Chip>
                          {ch && <Link href={`/chapters/${ch.id}`} className="hover:text-accent">{ch.name}</Link>}
                          {e.reattemptDate && (
                            <span className="flex items-center gap-1">
                              <Repeat2 size={9} /> reattempt {e.reattemptDate <= today ? "today" : fmtDate(e.reattemptDate)}
                            </span>
                          )}
                        </div>
                        {e.correctConcept && (
                          <div className="mt-1.5 rounded-lg bg-accent/[0.06] px-2.5 py-1.5 text-[11px] leading-relaxed text-accent/90">
                            ✓ {e.correctConcept}
                          </div>
                        )}
                      </div>
                      <ErrorCycle id={e.id} status={e.status} />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </Card>

        <Card className="animate-fade-up delay-2">
          <CardHeader icon={<BookMarked size={15} />} title="Log a mistake" sub="30 seconds now saves a wrong answer in the exam" />
          <ErrorForm
            subjects={ctx.subjects.map((s) => ({ id: s.id, name: s.name }))}
            chapters={ctx.chapters.map((c) => ({ id: c.id, name: c.name, subjectId: c.subjectId }))}
          />
          <div className="mt-4 rounded-xl border border-line bg-panel-2 p-3 text-[11px] leading-relaxed text-ink-3">
            <span className="font-semibold text-ink-2">How reattempts work (deterministic):</span> marking an error
            "Reattempt set" schedules it +3 days. Reattempts due today surface here and get drilled into your
            weak-topic practice blocks by the planner.
          </div>
        </Card>
      </div>
    </div>
  );
}
