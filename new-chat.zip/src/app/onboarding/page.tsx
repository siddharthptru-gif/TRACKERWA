import { Orbit } from "lucide-react";
import { Card } from "@/components/ui";
import { PageHeader } from "@/components/shell";
import { OnboardingForm } from "@/components/widgets";

export const dynamic = "force-dynamic";

export default function OnboardingPage() {
  return (
    <div className="mx-auto max-w-xl">
      <div className="mb-8 text-center animate-fade-up">
        <span className="mx-auto grid size-12 place-items-center rounded-2xl border border-accent/30 bg-accent/10 text-accent">
          <Orbit size={22} />
        </span>
        <h1 className="mt-4 font-display text-2xl font-bold tracking-tight">
          Welcome to <span className="text-accent">Tracker 360</span>
        </h1>
        <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-ink-3">
          Sixty seconds of setup. Then your personal preparation manager builds the syllabus graph,
          revision cycles, backlog plan — and today&apos;s schedule.
        </p>
      </div>
      <Card className="animate-fade-up delay-1">
        <OnboardingForm />
      </Card>
    </div>
  );
}
