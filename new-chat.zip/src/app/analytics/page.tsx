import { BarChart3, Sparkles, Clock, Target, History, PieChart as PieIcon } from "lucide-react";
import { Card, CardHeader, Chip, Stat } from "@/components/ui";
import { PageHeader } from "@/components/shell";
import { OnboardingCTA } from "@/components/onboarding-cta";
import { HoursArea, QuestionsBar, TrendLine, BalanceDonut } from "@/components/charts";
import { db } from "@/db";
import { planTasks } from "@/db/schema";
import { eq, gte, and } from "drizzle-orm";
import {
  getUser, getContext, generateInsights, todayStr, fmtDate, addDays, fmtMin, diffDays,
} from "@/lib/engine";

export const dynamic = "force-dynamic";

export default async function AnalyticsPage() {
  const user = await getUser();
  if (!user) return <OnboardingCTA />;
  const today = todayStr();
  const ctx = await getContext(user.id);
  const insights = generateInsights(ctx, today);

  const window30 = ctx.metrics.filter((m) => diffDays(today, m.date) < 30 && m.date <= today);
  const hoursData = window30.map((m) => ({ d: fmtDate(m.date), hours: Math.round((m.studyMin / 60) * 10) / 10 }));
  const qData = window30.map((m) => ({ d: fmtDate(m.date), q: m.questions }));
  const accData = window30.filter((m) => m.accuracy > 0).map((m) => ({ d: fmtDate(m.date), acc: m.accuracy }));
  const blData = window30.map((m) => ({ d: fmtDate(m.date), backlog: m.backlogCount }));

  // subject balance = executed (done) plan minutes by subject, last 7 days
  const doneTasks = await db
    .select()
    .from(planTasks)
    .where(and(eq(planTasks.userId, user.id), gte(planTasks.date, addDays(today, -6))));
  const bySubj = new Map<number, number>();
  for (const t of doneTasks.filter((t) => t.status === "done" && t.subjectId != null)) {
    bySubj.set(t.subjectId!, (bySubj.get(t.subjectId!) ?? 0) + t.estMin);
  }
  // fall back to lecture-hour mix from metrics if a fresh day has no completions yet
  let balance = ctx.subjects
    .map((s) => ({ name: s.name, value: bySubj.get(s.id) ?? 0, color: s.color }))
    .filter((x) => x.value > 0);
  if (balance.reduce((s, x) => s + x.value, 0) === 0) {
    const lecMix = ctx.subjects.map((s) => {
      const chs = ctx.chapters.filter((c) => c.subjectId === s.id).map((c) => c.id);
      const min = ctx.lectures.filter((l) => chs.includes(l.chapterId) && l.status === "completed")
        .reduce((x, l) => x + l.durationMin, 0);
      return { name: s.name, value: min, color: s.color };
    });
    balance = lecMix;
  }

  const last7 = ctx.metrics.filter((m) => diffDays(today, m.date) < 7 && m.date <= today);
  const weekHours = Math.round(last7.reduce((s, m) => s + m.studyMin, 0) / 60);
  const weekQ = last7.reduce((s, m) => s + m.questions, 0);
  const weekRev = last7.reduce((s, m) => s + m.revisionsDone, 0);
  const weekLec = last7.reduce((s, m) => s + m.lecturesDone, 0);

  return (
    <div>
      <PageHeader title="Analytics" sub="Meaningful signals only — what changed, what needs attention" />

      <div className="mb-4 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Card><Stat label="Study time · 7d" value={`${weekHours}h`} sub={`avg ${Math.round((weekHours * 60) / 7)} min/day`} /></Card>
        <Card><Stat label="Questions · 7d" value={String(weekQ)} tone="good" sub={`avg ${Math.round(weekQ / 7)}/day`} /></Card>
        <Card><Stat label="Lectures · 7d" value={String(weekLec)} sub={`${fmtMin(weekLec * 90)} of watching`} /></Card>
        <Card><Stat label="Revisions · 7d" value={String(weekRev)} tone={weekRev < 3 ? "warn" : "good"} sub={weekRev < 3 ? "revision consistency low" : "healthy cadence"} /></Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="animate-fade-up delay-1">
          <CardHeader icon={<Clock size={15} />} title="Study hours" sub="Last 30 days" />
          <HoursArea data={hoursData} />
        </Card>
        <Card className="animate-fade-up delay-2">
          <CardHeader icon={<Target size={15} />} title="Questions solved" sub="Last 30 days" />
          <QuestionsBar data={qData} />
        </Card>
        <Card className="animate-fade-up delay-3">
          <CardHeader icon={<BarChart3 size={15} />} title="Accuracy trend" sub="Attempted practice · %" />
          <TrendLine data={accData} dataKey="acc" color="#A78BFA" unit="%" />
        </Card>
        <Card className="animate-fade-up delay-4">
          <CardHeader icon={<History size={15} />} title="Backlog trend" sub="Pending lectures · last 30 days" />
          <TrendLine data={blData} dataKey="backlog" color="#FB7185" />
        </Card>
        <Card className="animate-fade-up delay-4">
          <CardHeader icon={<PieIcon size={15} />} title="Subject balance" sub="Where your executed time went · 7d" />
          <BalanceDonut data={balance} />
          <div className="mt-1 flex justify-center gap-3">
            {balance.map((b) => (
              <span key={b.name} className="flex items-center gap-1 text-[10px] text-ink-3">
                <span className="size-1.5 rounded-full" style={{ background: b.color }} /> {b.name}
              </span>
            ))}
          </div>
        </Card>
        <Card accent className="animate-fade-up delay-5">
          <CardHeader icon={<Sparkles size={15} className="text-accent" />} title="Insight engine" sub="What your data is saying right now" />
          <ul className="space-y-3">
            {insights.map((ins, i) => (
              <li key={i} className="flex gap-2.5 text-xs leading-relaxed text-ink-2">
                <span
                  className="mt-1 size-1.5 shrink-0 rounded-full"
                  style={{ background: ins.tone === "good" ? "#34D399" : ins.tone === "warn" ? "#FBBF24" : ins.tone === "bad" ? "#FB7185" : "#38BDF8" }}
                />
                {ins.text}
              </li>
            ))}
          </ul>
          <div className="mt-4 text-right">
            <Chip color="#34D399">updated {fmtDate(today)}</Chip>
          </div>
        </Card>
      </div>
    </div>
  );
}
