import Link from "next/link";
import {
  Flame, History, Repeat2, ClipboardList, ArrowRight, Sparkles,
  BookOpen, PenLine, Gauge, AlarmClock, Zap, HeartPulse, Megaphone, Quote, Target,
} from "lucide-react";
import { Card, CardHeader, Bar, Ring, Chip } from "@/components/ui";
import { TaskList } from "@/components/task-list";
import { OnboardingCTA } from "@/components/onboarding-cta";
import { ReplanButton, LinkBtn } from "@/components/widgets";
import { Spark } from "@/components/charts";
import {
  getUser, getContext, ensurePlan, tasksFor, completionStats, subjectStats,
  streak, backlogPlan, generateInsights, todayStr, fmtMin, fmtDate,
  fmtDateFull, diffDays, availableMinutesFor,
} from "@/lib/engine";
import { nowRecommendation, preparationHealth, quoteOfDay, backlogBreakdown } from "@/lib/ops";

export const dynamic = "force-dynamic";

export default async function Dashboard() {
  const user = await getUser();
  if (!user) return <OnboardingCTA />;

  const today = todayStr();
  await ensurePlan(user.id);
  const ctx = await getContext(user.id);
  const stats = completionStats(ctx);
  const subj = subjectStats(ctx, today);
  const st = streak(ctx, today);
  const bp = backlogPlan(ctx, today);
  const bd = backlogBreakdown(ctx, today);
  const tasks = await tasksFor(user.id, today);
  const pending = tasks.filter((t) => t.status === "pending");
  const done = tasks.filter((t) => t.status === "done");
  const plannedMin = tasks.reduce((s, t) => s + t.estMin, 0);
  const doneMin = done.reduce((s, t) => s + t.estMin, 0);
  const cap = availableMinutesFor(ctx, today);
  const dueRevs = ctx.revisions.filter(
    (r) => r.status !== "completed" && r.status !== "skipped" && r.dueDate <= today
  );
  const nextTest = ctx.tests
    .filter((t) => t.status === "scheduled" && t.scheduledAt >= today)
    .sort((a, b) => (a.scheduledAt < b.scheduledAt ? -1 : 1))[0];
  const insights = generateInsights(ctx, today);
  const subjectColors = new Map(ctx.subjects.map((s) => [s.id, s.color]));
  const chapterOf = (lecId: number) => ctx.lectures.find((l) => l.id === lecId)?.chapterId ?? null;
  const backlogTrend = ctx.metrics.slice(-21).map((m) => m.backlogCount);
  const now = nowRecommendation(ctx, tasks, today);
  const health = preparationHealth(ctx, today);
  const quote = quoteOfDay(today, ctx.settings?.motivation ?? true);
  const promised = tasks.filter((t) => t.promised);
  const promisedPct = promised.length ? Math.round((promised.filter((t) => t.status === "done").length / promised.length) * 100) : 0;
  const announcement = ctx.announcements[0];

  const currentChapters = ctx.chapters.filter((c) => c.isCurrent);
  const upcomingClasses = currentChapters
    .map((ch) => {
      const upcoming = ctx.lectures
        .filter((l) => l.chapterId === ch.id && l.status !== "completed" && l.taughtAt && l.taughtAt > today)
        .sort((a, b) => (a.taughtAt! < b.taughtAt! ? -1 : 1))[0];
      return upcoming ? { ch, lec: upcoming } : null;
    })
    .filter(Boolean) as { ch: (typeof currentChapters)[number]; lec: (typeof ctx.lectures)[number] }[];

  const hour = new Date().getHours();
  const greet = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";

  return (
    <div className="space-y-5">
      {/* announcement */}
      {announcement && (
        <div className="flex items-start gap-2.5 rounded-2xl border border-line bg-panel px-4 py-3 animate-fade-up">
          <Megaphone size={14} className="mt-0.5 shrink-0 text-warn" />
          <p className="text-xs leading-relaxed text-ink-2">{announcement.text}</p>
        </div>
      )}

      {/* greeting */}
      <div className="flex flex-wrap items-end justify-between gap-4 animate-fade-up">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight md:text-[28px]">
            {greet}, <span className="text-accent">{user.name.split(" ")[0]}</span>
          </h1>
          <p className="mt-1 text-sm text-ink-3">
            {user.exam} · {user.className} · {{ school: "Regular School", dummy: "Dummy School", dropper: "Dropper", college: "College + Prep", self: "Self-study", other: "Self-study" }[user.studentType] ?? "Student"} · {ctx.batch?.name}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Chip color="#34D399"><Flame size={11} /> {st}-day streak</Chip>
          <Chip color={bd.totalCount > 15 ? "#FB7185" : "#A5ABBB"}><History size={11} /> {bd.totalCount} backlog items</Chip>
          <Chip color={dueRevs.length ? "#FBBF24" : "#A5ABBB"}><Repeat2 size={11} /> {dueRevs.length} revisions due</Chip>
          {nextTest && (
            <Chip color="#E879F9">
              <ClipboardList size={11} /> {nextTest.title} in {diffDays(nextTest.scheduledAt, today)}d
            </Chip>
          )}
        </div>
      </div>

      <div className="grid grid-cols-12 gap-4">
        {/* WHAT SHOULD I DO NOW */}
        <Card accent className="col-span-12 lg:col-span-4 animate-fade-up delay-1">
          <CardHeader icon={<Zap size={15} className="text-accent" />} title="What should I do now?" sub="One answer, computed live" />
          {now.task ? (
            <div>
              <Link href="/study" className="group block rounded-xl border border-accent/30 bg-accent/[0.06] p-4 transition hover:border-accent/60">
                <div className="text-[10px] font-semibold uppercase tracking-[0.16em] text-accent">{now.headline}</div>
                <div className="mt-1.5 font-display text-lg font-semibold leading-snug text-ink group-hover:text-accent">
                  {now.task.title}
                </div>
                <div className="mt-1 font-mono text-[11px] tabular text-ink-3">{fmtMin(now.task.estMin)}</div>
              </Link>
              <p className="mt-3 text-[11px] leading-relaxed text-ink-3">
                <span className="font-semibold text-ink-2">Why this:</span> {now.explain}
              </p>
              <Link
                href="/study"
                className="mt-3 inline-flex items-center gap-2 rounded-xl bg-accent px-4 py-2.5 text-sm font-bold text-black transition hover:bg-accent-2"
              >
                Start studying <ArrowRight size={14} />
              </Link>
            </div>
          ) : (
            <div>
              <div className="rounded-xl border border-accent/30 bg-accent/[0.06] p-4 font-display text-sm font-semibold text-ink">{now.headline}</div>
              <p className="mt-3 text-[11px] leading-relaxed text-ink-3">{now.explain}</p>
            </div>
          )}
        </Card>

        {/* today's plan */}
        <Card className="col-span-12 md:col-span-8 lg:col-span-5 animate-fade-up delay-2">
          <CardHeader
            icon={<Sparkles size={15} className="text-accent" />}
            title="Today's plan"
            sub={`${fmtMin(plannedMin)} planned · ${fmtMin(doneMin)} done · capacity ${fmtMin(cap)}`}
            right={<ReplanButton />}
          />
          <TaskList tasks={pending.slice(0, 5)} subjectColors={subjectColors} chapterOf={chapterOf} />
          {pending.length > 5 && (
            <div className="mt-2 text-center"><LinkBtn href="/today">View all {tasks.length} tasks →</LinkBtn></div>
          )}
          <div className="mt-4 border-t border-line pt-3">
            <div className="mb-1 flex justify-between text-[11px]">
              <span className="text-ink-3">Day completion</span>
              <span className="tabular text-ink-2">{Math.round((doneMin / Math.max(1, plannedMin)) * 100)}%</span>
            </div>
            <Bar pct={(doneMin / Math.max(1, plannedMin)) * 100} />
          </div>
        </Card>

        {/* readiness + health */}
        <Card className="col-span-12 md:col-span-4 lg:col-span-3 animate-fade-up delay-3">
          <div className="flex items-center justify-between gap-4">
            <div>
              <div className="text-[10px] font-semibold uppercase tracking-[0.16em] text-ink-3">Overall readiness</div>
              <div className="mt-1 font-display text-4xl font-bold tabular text-ink">{stats.readiness}%</div>
              <div className="mt-1 text-[10px] text-ink-3">L {stats.lecturePct}% · R {stats.revisionPct}% · P {stats.practicePct}% · A {stats.avgAcc}%</div>
            </div>
            <Ring pct={health.score} size={96} stroke={9} color={health.color} sub={health.label.toLowerCase()} />
          </div>
          <div className="mt-3 border-t border-line pt-3">
            <div className="mb-1.5 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-ink-3">
              <HeartPulse size={11} style={{ color: health.color }} /> Preparation health · <span style={{ color: health.color }}>{health.label}</span>
            </div>
            <ul className="space-y-1">
              {health.reasons.map((r, i) => (
                <li key={i} className="text-[11px] leading-relaxed text-ink-3">· {r}</li>
              ))}
            </ul>
          </div>
        </Card>

        {/* metric tiles */}
        {[
          { icon: <BookOpen size={15} />, label: "Lecture progress", val: `${stats.lecturePct}%`, sub: `${stats.doneLec} of ${stats.totalLec} watched`, pct: stats.lecturePct, c: "#38BDF8" },
          { icon: <Repeat2 size={15} />, label: "Revision cycles", val: `${stats.revisionPct}%`, sub: `${stats.doneRevs} of ${stats.totalRevs} stages done`, pct: stats.revisionPct, c: "#34D399" },
          { icon: <PenLine size={15} />, label: "Practice coverage", val: `${stats.practicePct}%`, sub: `${stats.donePractice} of ${stats.totalPractice} sets done`, pct: stats.practicePct, c: "#A78BFA" },
          { icon: <Target size={15} />, label: "Today's promise", val: promised.length ? `${promisedPct}%` : "—", sub: promised.length ? `${promised.filter((t) => t.status === "done").length}/${promised.length} promised tasks kept` : "star tasks on Today", pct: promisedPct || 0, c: "#FBBF24" },
        ].map((t, i) => (
          <Card key={t.label} className={`col-span-6 lg:col-span-3 animate-fade-up delay-${i + 2}`}>
            <div className="flex items-center justify-between">
              <span className="grid size-8 place-items-center rounded-lg border border-line bg-panel-2 text-ink-2">{t.icon}</span>
              <span className="font-display text-2xl font-bold tabular" style={{ color: t.c }}>{t.val}</span>
            </div>
            <div className="mt-3 text-[13px] font-medium text-ink">{t.label}</div>
            <div className="text-[11px] text-ink-3">{t.sub}</div>
            <Bar pct={t.pct} color={t.c} className="mt-3" />
          </Card>
        ))}

        {/* backlog breakdown compact */}
        <Card className="col-span-12 md:col-span-4 animate-fade-up delay-3">
          <CardHeader icon={<History size={15} />} title="Backlog" sub="type-wise · time-weighted" right={<LinkBtn href="/backlog">Kill it →</LinkBtn>} />
          <div className="flex items-end justify-between">
            <div>
              <div className="font-display text-3xl font-bold tabular" style={{ color: bd.totalMin > 1800 ? "var(--color-danger)" : "var(--color-ink)" }}>
                {fmtMin(bd.totalMin)}
              </div>
              <div className="mt-0.5 text-xs text-ink-3">{bd.totalCount} items total</div>
            </div>
            <LinkBtn href="/backlog">balanced kill ≈ {bp.daysNeeded}d</LinkBtn>
          </div>
          <div className="mt-3 flex h-2 w-full gap-px overflow-hidden rounded-full">
            {bd.slices.filter((s) => s.minutes > 0).map((s) => (
              <span key={s.key} style={{ width: `${(s.minutes / Math.max(1, bd.totalMin)) * 100}%`, background: s.color }} title={`${s.label}: ${fmtMin(s.minutes)}`} />
            ))}
          </div>
          <div className="mt-2 flex flex-wrap gap-x-3 gap-y-1">
            {bd.slices.filter((s) => s.count > 0).map((s) => (
              <span key={s.key} className="flex items-center gap-1 text-[10px] text-ink-3">
                <span className="size-1.5 rounded-full" style={{ background: s.color }} /> {s.label} {s.count}
              </span>
            ))}
          </div>
          <div className="mt-3"><Spark data={backlogTrend} color={bd.totalMin > 1800 ? "#FB7185" : "#34D399"} /></div>
        </Card>

        {/* subjects */}
        <Card className="col-span-12 md:col-span-4 animate-fade-up delay-4">
          <CardHeader icon={<BookOpen size={15} />} title="Subject progress" right={<LinkBtn href="/prep">Prep map →</LinkBtn>} />
          <div className="space-y-3.5">
            {subj.map((s) => (
              <Link key={s.id} href={`/subjects/${s.slug}`} className="-m-1 block rounded-lg p-1 transition hover:bg-panel-2">
                <div className="mb-1 flex items-center justify-between text-[12px]">
                  <span className="font-medium" style={{ color: s.color }}>{s.name}</span>
                  <span className="tabular text-ink-3">{s.completed}/{s.total} ch · {s.lecturePct}%</span>
                </div>
                <Bar pct={s.lecturePct} color={s.color} />
              </Link>
            ))}
          </div>
          <div className="mt-4 space-y-2 border-t border-line pt-3">
            {upcomingClasses.slice(0, 2).map(({ ch, lec }) => (
              <div key={lec.id} className="flex items-center justify-between gap-2 rounded-lg border border-line bg-panel-2 px-3 py-2">
                <div className="min-w-0">
                  <div className="truncate text-xs font-medium text-ink">{lec.title}</div>
                  <div className="text-[10px] text-ink-3">{ctx.subjects.find((s) => s.id === ch.subjectId)?.name} · next class</div>
                </div>
                <Chip>{fmtDate(lec.taughtAt!)}</Chip>
              </div>
            ))}
          </div>
        </Card>

        {/* tests + insights */}
        <Card className="col-span-12 md:col-span-4 animate-fade-up delay-5">
          <CardHeader icon={<ClipboardList size={15} />} title="Tests" right={<LinkBtn href="/tests">All →</LinkBtn>} />
          <div className="space-y-2">
            {nextTest && (
              <div className="rounded-xl border border-warn/25 bg-warn/[0.06] px-3 py-2.5">
                <div className="text-xs font-semibold text-ink">{nextTest.title}</div>
                <div className="mt-0.5 text-[11px] text-ink-3">{fmtDate(nextTest.scheduledAt)} · in {diffDays(nextTest.scheduledAt, today)} days · prep auto-added</div>
              </div>
            )}
            {ctx.tests
              .filter((t) => t.status === "attempted")
              .sort((a, b) => (a.scheduledAt > b.scheduledAt ? -1 : 1))
              .slice(0, 2)
              .map((t) => (
                <div key={t.id} className="flex items-center justify-between rounded-lg border border-line bg-panel-2 px-3 py-2">
                  <div className="min-w-0 text-xs">
                    <div className="truncate font-medium text-ink">{t.title}</div>
                    <div className="text-[10px] text-ink-3">{fmtDate(t.scheduledAt)}</div>
                  </div>
                  <span className="font-mono text-xs font-semibold tabular" style={{ color: (t.obtainedMarks ?? 0) / t.totalMarks >= 0.55 ? "#34D399" : "#FBBF24" }}>
                    {t.obtainedMarks}/{t.totalMarks}
                  </span>
                </div>
              ))}
          </div>
          <div className="mt-3 border-t border-line pt-3">
            <div className="mb-1.5 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-ink-3">
              <AlarmClock size={11} /> Insight engine
            </div>
            <ul className="space-y-1.5">
              {insights.slice(0, 2).map((ins, i) => (
                <li key={i} className="flex gap-2 text-[11px] leading-relaxed text-ink-2">
                  <span className="mt-1 size-1.5 shrink-0 rounded-full" style={{ background: ins.tone === "good" ? "#34D399" : ins.tone === "warn" ? "#FBBF24" : "#FB7185" }} />
                  {ins.text}
                </li>
              ))}
            </ul>
          </div>
        </Card>
      </div>

      {/* quote + CTA */}
      {quote && (
        <div className="flex items-center gap-2.5 px-1 animate-fade-up delay-5">
          <Quote size={12} className="shrink-0 text-ink-3" />
          <p className="text-xs italic text-ink-3">{quote}</p>
        </div>
      )}
      <Link
        href="/today"
        className="group flex items-center justify-between rounded-2xl border border-accent/25 bg-gradient-to-r from-accent/[0.08] to-transparent px-5 py-4 transition hover:border-accent/50 animate-fade-up delay-5"
      >
        <div>
          <div className="font-display text-sm font-semibold text-ink">Open today's full plan</div>
          <div className="text-xs text-ink-3">{pending.length} pending · star your promise · evening check-in</div>
        </div>
        <span className="grid size-9 place-items-center rounded-full border border-accent/40 text-accent transition group-hover:bg-accent group-hover:text-black">
          <ArrowRight size={16} />
        </span>
      </Link>
    </div>
  );
}
