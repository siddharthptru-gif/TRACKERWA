import Link from "next/link";
import { notFound } from "next/navigation";
import { Layers, AlertTriangle, TrendingUp } from "lucide-react";
import { Card, CardHeader, Bar, Chip, Stat } from "@/components/ui";
import { PageHeader } from "@/components/shell";
import { OnboardingCTA } from "@/components/onboarding-cta";
import {
  getUser, getContext, subjectStats, lectureProgress, chapterPractice,
  nextAction, todayStr,
} from "@/lib/engine";

export const dynamic = "force-dynamic";

const STATUS_CHIP: Record<string, { label: string; color: string }> = {
  completed: { label: "Completed", color: "#34D399" },
  in_progress: { label: "In progress", color: "#38BDF8" },
  not_started: { label: "Upcoming", color: "#6b7280" },
};

export default async function SubjectDetail({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const user = await getUser();
  if (!user) return <OnboardingCTA />;
  const today = todayStr();
  const ctx = await getContext(user.id);
  const stats = subjectStats(ctx, today).find((s) => s.slug === slug);
  if (!stats) notFound();

  const chapterRows = stats.chapters
    .slice()
    .sort((a, b) => a.position - b.position)
    .map((c) => {
      const lp = lectureProgress(ctx, c.id);
      const pr = chapterPractice(ctx, c.id);
      const practiceDone = pr.filter((p) => p.status === "completed").length;
      return { c, lp, practiceDone, practiceTotal: pr.length, next: nextAction(ctx, c.id, today) };
    });

  return (
    <div>
      <PageHeader
        title={stats.name}
        sub={`${stats.completed} of ${stats.total} chapters complete · running: ${stats.current?.name ?? "none"}`}
        right={<Chip color={stats.color}>{stats.lecturePct}% lectures</Chip>}
      />

      <div className="mb-4 grid grid-cols-2 gap-4 lg:grid-cols-4">
        {[
          { label: "Lecture progress", value: `${stats.lecturePct}%` },
          { label: "Backlog lectures", value: String(stats.backlog), tone: stats.backlog > 5 ? "bad" as const : undefined },
          { label: "Avg mastery", value: `${stats.avgMastery || "—"}%` },
          { label: "Weak chapters", value: String(stats.weak.length), tone: stats.weak.length ? "warn" as const : "good" as const },
        ].map((s) => (
          <Card key={s.label}><Stat {...s} /></Card>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2 animate-fade-up delay-1">
          <CardHeader icon={<Layers size={15} />} title="Chapters" sub="Click a chapter for its full tracker" />
          <div className="divide-y divide-line">
            {chapterRows.map(({ c, lp, practiceDone, practiceTotal, next }) => {
              const st = STATUS_CHIP[c.status] ?? STATUS_CHIP.not_started;
              return (
                <Link key={c.id} href={`/chapters/${c.id}`} className="flex items-center gap-3 px-1 py-2.5 transition hover:bg-panel-2">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="truncate text-[13px] font-medium text-ink">{c.name}</span>
                      {c.isCurrent && <Chip color="#38BDF8">LIVE</Chip>}
                    </div>
                    <div className="mt-0.5 truncate text-[11px] text-ink-3">Next: {next}</div>
                  </div>
                  <div className="hidden w-40 shrink-0 sm:block">
                    <div className="mb-1 flex justify-between text-[10px] text-ink-3">
                      <span>{lp.done}/{lp.total} lectures</span>
                      <span>{practiceDone}/{practiceTotal} practice</span>
                    </div>
                    <Bar pct={lp.pct} color={stats.color} />
                  </div>
                  <Chip color={st.color} className="shrink-0">{st.label}</Chip>
                </Link>
              );
            })}
          </div>
        </Card>

        <div className="space-y-4">
          <Card className="animate-fade-up delay-2">
            <CardHeader icon={<TrendingUp size={15} className="text-accent" />} title="Strong chapters" sub="Mastery ≥ 78%" />
            {stats.strong.length === 0 ? (
              <p className="text-xs text-ink-3">Complete revisions to push chapters into the strong zone.</p>
            ) : (
              <ul className="space-y-1.5">
                {stats.strong.slice(0, 6).map((c) => (
                  <li key={c.id}>
                    <Link href={`/chapters/${c.id}`} className="flex items-center justify-between rounded-lg px-2 py-1.5 text-xs transition hover:bg-panel-2">
                      <span className="text-ink-2">{c.name}</span>
                      <span className="tabular text-accent">{c.mastery}%</span>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </Card>
          <Card className="animate-fade-up delay-3">
            <CardHeader icon={<AlertTriangle size={15} className="text-danger" />} title="Weak chapters" sub="Mastery < 55% · prioritised in planner" />
            {stats.weak.length === 0 ? (
              <p className="text-xs text-ink-3">No weak chapters flagged. Test analysis will surface them automatically.</p>
            ) : (
              <ul className="space-y-1.5">
                {stats.weak.slice(0, 6).map((c) => (
                  <li key={c.id}>
                    <Link href={`/chapters/${c.id}`} className="flex items-center justify-between rounded-lg px-2 py-1.5 text-xs transition hover:bg-panel-2">
                      <span className="text-ink-2">{c.name}</span>
                      <span className="tabular text-danger">{c.mastery}%</span>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
