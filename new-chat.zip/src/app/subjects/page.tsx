import Link from "next/link";
import { Layers, ArrowRight, AlertTriangle, CheckCircle2, History, Radio } from "lucide-react";
import { Card, CardHeader, Bar, Chip, Empty } from "@/components/ui";
import { PageHeader } from "@/components/shell";
import { OnboardingCTA } from "@/components/onboarding-cta";
import { getUser, getContext, subjectStats, todayStr } from "@/lib/engine";

export const dynamic = "force-dynamic";

export default async function SubjectsPage() {
  const user = await getUser();
  if (!user) return <OnboardingCTA />;
  const today = todayStr();
  const ctx = await getContext(user.id);
  const stats = subjectStats(ctx, today);

  return (
    <div>
      <PageHeader title="Subjects" sub="Physics · Chemistry · Mathematics — deep-dive into each" />
      {stats.length === 0 ? (
        <Card><Empty title="No subjects yet" body="Run onboarding to import your batch subjects." actionLabel="Open onboarding" actionHref="/onboarding" /></Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-3">
          {stats.map((s, i) => (
            <Link key={s.id} href={`/subjects/${s.slug}`} className="group">
              <Card className={`h-full transition group-hover:border-line-2 animate-fade-up delay-${i + 1}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className="grid size-9 place-items-center rounded-xl border border-line bg-panel-2" style={{ color: s.color }}>
                      <Layers size={16} />
                    </span>
                    <div>
                      <div className="font-display text-base font-semibold" style={{ color: s.color }}>{s.name}</div>
                      <div className="text-[11px] text-ink-3">{s.total} chapters in batch</div>
                    </div>
                  </div>
                  <ArrowRight size={15} className="text-ink-3 transition group-hover:translate-x-0.5 group-hover:text-ink" />
                </div>

                <div className="mt-4">
                  <div className="mb-1 flex justify-between text-[11px] text-ink-3">
                    <span>Chapters completed</span>
                    <span className="tabular text-ink-2">{s.completed}/{s.total}</span>
                  </div>
                  <Bar pct={(s.completed / Math.max(1, s.total)) * 100} color={s.color} />
                </div>

                <div className="mt-4 grid grid-cols-2 gap-2 text-[11px]">
                  <div className="rounded-lg border border-line bg-panel-2 p-2.5">
                    <div className="flex items-center gap-1 text-ink-3"><Radio size={10} style={{ color: s.color }} /> Running now</div>
                    <div className="mt-1 truncate font-medium text-ink">{s.current?.name ?? "—"}</div>
                  </div>
                  <div className="rounded-lg border border-line bg-panel-2 p-2.5">
                    <div className="flex items-center gap-1 text-ink-3"><History size={10} className="text-danger" /> Backlog</div>
                    <div className="mt-1 font-medium tabular" style={{ color: s.backlog > 5 ? "var(--color-danger)" : "var(--color-ink)" }}>
                      {s.backlog} lectures
                    </div>
                  </div>
                </div>

                <div className="mt-3 flex flex-wrap gap-1.5">
                  <Chip color="#34D399"><CheckCircle2 size={10} /> {s.strong.length} strong</Chip>
                  <Chip color={s.weak.length ? "#FB7185" : "#A5ABBB"}><AlertTriangle size={10} /> {s.weak.length} weak</Chip>
                  <Chip>mastery {s.avgMastery || "—"}%</Chip>
                </div>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
