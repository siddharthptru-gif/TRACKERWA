import { CalendarRange, Brain, ArrowUpRight } from "lucide-react";
import { Card, CardHeader, Chip, Bar } from "@/components/ui";
import { PageHeader } from "@/components/shell";
import { TaskList } from "@/components/task-list";
import { OnboardingCTA } from "@/components/onboarding-cta";
import {
  getUser, getContext, ensurePlan, generatePlan, tasksFor, todayStr, fmtMin,
  fmtDate, dayName, addDays, availableMinutesFor,
} from "@/lib/engine";

export const dynamic = "force-dynamic";

const TIERS = [
  { tier: "High priority", items: "Today's running lecture · test day · test prep (≤3d) · overdue DPPs · due revisions", color: "#FB7185" },
  { tier: "Medium priority", items: "Backlog dose (oldest-first) · weak-topic drills · module practice · PYQs", color: "#FBBF24" },
  { tier: "Low priority", items: "Extra questions · optional revision · exploratory practice", color: "#38BDF8" },
];

export default async function PlannerPage() {
  const user = await getUser();
  if (!user) return <OnboardingCTA />;

  const today = todayStr();
  await ensurePlan(user.id);

  // pre-generate the next 3 days idempotently so the week view is full
  for (let i = 1; i <= 3; i++) {
    const d = addDays(today, i);
    const t = await tasksFor(user.id, d);
    if (t.length === 0) await generatePlan(user.id, d);
  }

  const ctx = await getContext(user.id);
  const subjectColors = new Map(ctx.subjects.map((s) => [s.id, s.color]));
  const chapterOf = (lecId: number) => ctx.lectures.find((l) => l.id === lecId)?.chapterId ?? null;
  const cap = availableMinutesFor(ctx, today);

  const days = [];
  for (let i = 0; i < 5; i++) {
    const d = addDays(today, i);
    const tasks = await tasksFor(user.id, d);
    days.push({ date: d, tasks });
  }

  return (
    <div>
      <PageHeader
        title="Planner"
        sub="Auto-generated · priority-scored · capacity-aware · recalibrates daily"
        right={<Chip color="#34D399">capacity {fmtMin(cap)}/day</Chip>}
      />

      <div className="mb-4 grid gap-4 lg:grid-cols-3 animate-fade-up delay-1">
        {TIERS.map((t) => (
          <Card key={t.tier} className="!p-4">
            <div className="flex items-center gap-2">
              <span className="size-2 rounded-full" style={{ background: t.color }} />
              <span className="text-xs font-semibold uppercase tracking-wider text-ink">{t.tier}</span>
            </div>
            <p className="mt-2 text-[11px] leading-relaxed text-ink-3">{t.items}</p>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-5">
        {days.map((d, i) => {
          const total = d.tasks.reduce((s, t) => s + t.estMin, 0);
          const doneMin = d.tasks.filter((t) => t.status === "done").reduce((s, t) => s + t.estMin, 0);
          const isToday = i === 0;
          return (
            <Card key={d.date} accent={isToday} className={`animate-fade-up delay-${Math.min(5, i + 1)}`}>
              <div className="mb-3 flex items-center justify-between">
                <div>
                  <div className="font-display text-sm font-semibold text-ink">
                    {isToday ? "Today" : dayName(d.date)}
                  </div>
                  <div className="text-[11px] text-ink-3">{fmtDate(d.date)}</div>
                </div>
                <div className="text-right font-mono text-[11px] tabular text-ink-3">
                  <div>{fmtMin(total)}</div>
                  {doneMin > 0 && <div className="text-accent">{fmtMin(doneMin)} done</div>}
                </div>
              </div>
              <Bar pct={(total / cap) * 100} className="mb-3" />
              <TaskList tasks={d.tasks} subjectColors={subjectColors} chapterOf={chapterOf} compact />
            </Card>
          );
        })}
      </div>

      <Card className="mt-4 animate-fade-up delay-5">
        <CardHeader icon={<Brain size={15} />} title="How the engine thinks" sub="The same logic powers the AI assistant's answers" />
        <div className="grid gap-4 text-xs leading-relaxed text-ink-3 md:grid-cols-3">
          <div>
            <span className="font-semibold text-ink-2">1 · Protect the present.</span> Running-chapter lectures are
            locked in first — clearing backlog never eats today's class time.
          </div>
          <div>
            <span className="font-semibold text-ink-2">2 · Respect memory.</span> Spaced revisions fire at 1/3/7/15/30-day
            intervals and outrank almost everything, because forgotten chapters are silent rank-killers.
          </div>
          <div className="flex items-start gap-1.5">
            <span className="font-semibold text-ink-2">3 · Adapt daily.</span> Evening check-ins scale tomorrow's load
            (0.7×–1.1×) so plans stay realistic, not heroic.
            <a href="/ai" className="mt-0.5 inline-flex items-center gap-0.5 text-accent hover:underline">Ask the AI <ArrowUpRight size={11} /></a>
          </div>
        </div>
      </Card>
    </div>
  );
}
