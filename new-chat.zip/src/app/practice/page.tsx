import Link from "next/link";
import { PenLine, AlertTriangle, Target } from "lucide-react";
import { Card, CardHeader, Chip, Stat, Bar, PRACTICE_STATUS } from "@/components/ui";
import { PageHeader } from "@/components/shell";
import { OnboardingCTA } from "@/components/onboarding-cta";
import { PracticeStatus } from "@/components/widgets";
import { getUser, getContext } from "@/lib/engine";

export const dynamic = "force-dynamic";

const TYPE_ORDER = ["dpp", "module", "pyq_main", "pyq_adv"];
const TYPE_LABEL: Record<string, string> = {
  dpp: "DPP", module: "Module", pyq_main: "PYQ · M", pyq_adv: "PYQ · A",
};

export default async function PracticePage() {
  const user = await getUser();
  if (!user) return <OnboardingCTA />;
  const ctx = await getContext(user.id);

  const totalQ = ctx.practice.reduce((s, p) => s + p.totalQuestions, 0);
  const solvedQ = ctx.practice.reduce((s, p) => s + p.solved, 0);
  const focus = ctx.practice.filter((p) => p.status === "weak" || p.status === "needs_revision");
  const done = ctx.practice.filter((p) => p.status === "completed").length;

  return (
    <div>
      <PageHeader title="Practice" sub="DPPs · Modules · PYQs — the part that actually produces rank" />

      <div className="mb-4 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Card><Stat label="Questions solved" value={solvedQ.toLocaleString("en-IN")} sub={`of ${totalQ.toLocaleString("en-IN")} assigned`} /></Card>
        <Card><Stat label="Coverage" value={`${Math.round((solvedQ / Math.max(1, totalQ)) * 100)}%`} tone="good" /></Card>
        <Card><Stat label="Sets completed" value={`${done}/${ctx.practice.length}`} /></Card>
        <Card><Stat label="Needs attention" value={String(focus.length)} tone={focus.length ? "warn" : "good"} sub="weak / needs revision" /></Card>
      </div>

      {focus.length > 0 && (
        <Card className="mb-4 border-warn/25 animate-fade-up delay-1">
          <CardHeader icon={<AlertTriangle size={15} className="text-warn" />} title="Focus list" sub="These sets drag your accuracy — the planner already injects them as drills" />
          <div className="grid gap-2 md:grid-cols-2">
            {focus.slice(0, 6).map((p) => {
              const ch = ctx.chapters.find((c) => c.id === p.chapterId)!;
              return (
                <Link key={p.id} href={`/chapters/${ch.id}`} className="flex items-center justify-between rounded-xl border border-line bg-panel-2 px-3 py-2.5 transition hover:border-warn/40">
                  <div className="min-w-0">
                    <div className="truncate text-xs font-medium text-ink">{ch.name} · {TYPE_LABEL[p.type]}</div>
                    <div className="text-[10px] text-ink-3">
                      {p.solved}/{p.totalQuestions}q{p.accuracy != null ? ` · ${Math.round(p.accuracy)}% accuracy` : ""}
                    </div>
                  </div>
                  <PracticeStatus id={p.id} status={p.status} />
                </Link>
              );
            })}
          </div>
        </Card>
      )}

      <div className="space-y-4">
        {ctx.subjects.map((s, si) => {
          const chs = ctx.chapters.filter((c) => c.subjectId === s.id).sort((a, b) => a.position - b.position);
          const items = chs.flatMap((c) => ctx.practice.filter((p) => p.chapterId === c.id));
          const sSolved = items.reduce((x, p) => x + p.solved, 0);
          const sTotal = items.reduce((x, p) => x + p.totalQuestions, 0);
          return (
            <Card key={s.id} className={`animate-fade-up delay-${Math.min(5, si + 2)}`}>
              <CardHeader
                icon={<PenLine size={15} style={{ color: s.color }} />}
                title={s.name}
                sub={`${sSolved.toLocaleString("en-IN")}/${sTotal.toLocaleString("en-IN")} questions · ${Math.round((sSolved / Math.max(1, sTotal)) * 100)}%`}
                right={
                  <div className="hidden sm:block w-36">
                    <Bar pct={(sSolved / Math.max(1, sTotal)) * 100} color={s.color} />
                  </div>
                }
              />
              <div className="overflow-x-auto">
                <table className="w-full min-w-[640px] text-left text-xs">
                  <thead>
                    <tr className="text-[10px] uppercase tracking-wider text-ink-3">
                      <th className="pb-2 pr-3 font-medium">Chapter</th>
                      {TYPE_ORDER.map((t) => (
                        <th key={t} className="pb-2 pr-3 font-medium">{TYPE_LABEL[t]}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-line">
                    {chs.map((c) => (
                      <tr key={c.id} className="align-middle">
                        <td className="py-2 pr-3">
                          <Link href={`/chapters/${c.id}`} className="block max-w-[220px] truncate font-medium text-ink-2 transition hover:text-ink">
                            {c.name}
                          </Link>
                        </td>
                        {TYPE_ORDER.map((t) => {
                          const p = ctx.practice.find((x) => x.chapterId === c.id && x.type === t);
                          if (!p) return <td key={t} className="py-2 pr-3 text-ink-3">—</td>;
                          const meta = PRACTICE_STATUS[p.status] ?? PRACTICE_STATUS.not_started;
                          return (
                            <td key={t} className="py-2 pr-3">
                              <div className="flex items-center gap-2">
                                <span className="w-14 font-mono text-[10px] tabular" style={{ color: meta.color }}>
                                  {p.solved}/{p.totalQuestions}
                                </span>
                                <PracticeStatus id={p.id} status={p.status} />
                              </div>
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          );
        })}
      </div>

      <Card className="mt-4 animate-fade-up delay-5">
        <div className="flex items-start gap-2.5 text-xs leading-relaxed text-ink-3">
          <Target size={14} className="mt-0.5 shrink-0 text-accent" />
          <p>
            <span className="font-semibold text-ink-2">Status guide:</span> mark a set{" "}
            <span className="text-danger font-medium">Weak</span> when accuracy &lt; 55% — it moves to the focus list and
            gets drilled in tomorrow&apos;s plan. Mark <span className="text-warn font-medium">Needs revision</span> when the
            underlying theory has faded — a revision stage gets scheduled for the chapter.
          </p>
        </div>
      </Card>
    </div>
  );
}
