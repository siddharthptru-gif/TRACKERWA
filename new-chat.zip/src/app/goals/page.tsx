import { Trophy, Target, CalendarDays, Flame, Star } from "lucide-react";
import { Card, CardHeader, Chip, Stat, Bar } from "@/components/ui";
import { PageHeader } from "@/components/shell";
import { OnboardingCTA } from "@/components/onboarding-cta";
import { GoalForm } from "@/components/widgets";
import {
  getUser, getContext, completionStats, todayStr, fmtDate, diffDays,
} from "@/lib/engine";

export const dynamic = "force-dynamic";

export default async function GoalsPage() {
  const user = await getUser();
  if (!user) return <OnboardingCTA />;
  const today = todayStr();
  const ctx = await getContext(user.id);
  const g = ctx.goals;
  const stats = completionStats(ctx);

  const last7 = ctx.metrics.filter((m) => diffDays(today, m.date) < 7 && m.date <= today);
  const weekQ = last7.reduce((s, m) => s + m.questions, 0);
  const todayMetric = ctx.metrics.find((m) => m.date === today);
  const todayMin = todayMetric?.studyMin ?? 0;

  const monthStart = today.slice(0, 8) + "01";
  const chaptersThisMonth = ctx.chapters.filter(
    (c) => c.status === "completed" && c.completedAt && c.completedAt >= monthStart
  ).length;

  const daysMain = g?.examDateMain ? diffDays(g.examDateMain, today) : null;
  const daysAdv = g?.examDateAdv ? diffDays(g.examDateAdv, today) : null;

  const goalRows = [
    {
      icon: <Flame size={15} />, label: "Daily study target",
      cur: todayMin, target: g?.dailyMinutes ?? user.dailyMinutes, unit: "min",
      note: `${Math.round(todayMin)}/${g?.dailyMinutes ?? user.dailyMinutes} min today`,
    },
    {
      icon: <Target size={15} />, label: "Weekly questions",
      cur: weekQ, target: g?.weeklyQuestions ?? 450, unit: "q",
      note: `${weekQ}/${g?.weeklyQuestions ?? 450} questions this week`,
    },
    {
      icon: <Star size={15} />, label: "Monthly chapters",
      cur: chaptersThisMonth, target: g?.monthlyChapters ?? 9, unit: "ch",
      note: `${chaptersThisMonth}/${g?.monthlyChapters ?? 9} chapters this month`,
    },
  ];

  return (
    <div>
      <PageHeader title="Goals" sub="Targets are only useful when progress-to-goal is always visible" />

      <div className="mb-4 grid gap-4 md:grid-cols-2">
        <Card accent className="animate-fade-up delay-1">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span className="grid size-9 place-items-center rounded-xl bg-accent/15 text-accent"><Trophy size={16} /></span>
              <div>
                <div className="font-display text-sm font-semibold text-ink">JEE Main</div>
                <div className="text-[11px] text-ink-3">target rank under {(g?.targetRankMain ?? 500).toLocaleString("en-IN")}</div>
              </div>
            </div>
            <div className="text-right">
              <div className="font-display text-2xl font-bold tabular text-accent">{daysMain ?? "—"}</div>
              <div className="text-[10px] uppercase tracking-wider text-ink-3">days left · {g?.examDateMain ? fmtDate(g.examDateMain) : ""}</div>
            </div>
          </div>
          <div className="mt-4">
            <div className="mb-1 flex justify-between text-[11px] text-ink-3">
              <span>Preparation trajectory</span>
              <span className="tabular">{stats.readiness}%</span>
            </div>
            <Bar pct={stats.readiness} />
            <p className="mt-2 text-[11px] leading-relaxed text-ink-3">
              A sub-{g?.targetRankMain ?? 500} rank typically needs practice coverage ≥ 80% and accuracy ≥ 75% in the final stretch.
              You are at {stats.practicePct}% / {stats.avgAcc}% — {stats.practicePct >= 60 ? "on trajectory if the weekly question target keeps hitting." : "bias the next two weeks toward questions over lectures."}
            </p>
          </div>
        </Card>

        <Card className="animate-fade-up delay-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span className="grid size-9 place-items-center rounded-xl border border-line bg-panel-2 text-ink-2"><Star size={16} /></span>
              <div>
                <div className="font-display text-sm font-semibold text-ink">JEE Advanced</div>
                <div className="text-[11px] text-ink-3">target rank under {(g?.targetRankAdv ?? 1200).toLocaleString("en-IN")}</div>
              </div>
            </div>
            <div className="text-right">
              <div className="font-display text-2xl font-bold tabular text-ink">{daysAdv ?? "—"}</div>
              <div className="text-[10px] uppercase tracking-wider text-ink-3">days left · {g?.examDateAdv ? fmtDate(g.examDateAdv) : ""}</div>
            </div>
          </div>
          <p className="mt-4 text-[11px] leading-relaxed text-ink-3">
            Advanced preparation is measured by PYQ-Advanced coverage:{" "}
            <span className="font-semibold text-ink-2">
              {ctx.practice.filter((p) => p.type === "pyq_adv" && p.status === "completed").length} of{" "}
              {ctx.practice.filter((p) => p.type === "pyq_adv").length} chapter sets done.
            </span>{" "}
            After each full mock, your weakest section automatically shapes the following week&apos;s plan.
          </p>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2 animate-fade-up delay-3">
          <CardHeader icon={<CalendarDays size={15} />} title="Rhythm targets" sub="Live progress against your daily / weekly / monthly goals" />
          <div className="space-y-4">
            {goalRows.map((r) => (
              <div key={r.label} className="flex items-center gap-4">
                <span className="grid size-9 shrink-0 place-items-center rounded-lg border border-line bg-panel-2 text-ink-2">{r.icon}</span>
                <div className="min-w-0 flex-1">
                  <div className="mb-1 flex items-baseline justify-between">
                    <span className="text-[13px] font-medium text-ink">{r.label}</span>
                    <span className="text-[11px] tabular text-ink-3">{r.note}</span>
                  </div>
                  <Bar pct={(r.cur / Math.max(1, r.target)) * 100} />
                </div>
              </div>
            ))}
          </div>
          <div className="mt-5 grid grid-cols-3 gap-3">
            <Stat label="Current readiness" value={`${stats.readiness}%`} tone="good" />
            <Stat label="Target rank (Main)" value={`< ${(g?.targetRankMain ?? 500).toLocaleString("en-IN")}`} />
            <Stat label="Batch" value={ctx.batch?.name.split("—")[0].trim() ?? "—"} sub="manual sync" />
          </div>
        </Card>

        <Card className="animate-fade-up delay-4">
          <CardHeader icon={<Trophy size={15} />} title="Edit goals" sub="Plans recalibrate immediately" />
          <GoalForm
            initial={{
              dailyMinutes: g?.dailyMinutes ?? user.dailyMinutes,
              weeklyQuestions: g?.weeklyQuestions ?? 450,
              monthlyChapters: g?.monthlyChapters ?? 9,
              targetRankMain: g?.targetRankMain ?? 500,
              targetRankAdv: g?.targetRankAdv ?? 1200,
              examDateMain: g?.examDateMain,
              examDateAdv: g?.examDateAdv,
            }}
          />
        </Card>
      </div>
    </div>
  );
}
