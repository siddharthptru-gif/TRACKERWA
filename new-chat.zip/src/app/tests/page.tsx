import { ClipboardList, TrendingUp, CalendarClock, Microscope } from "lucide-react";
import { Card, CardHeader, Chip, Stat, Bar } from "@/components/ui";
import { PageHeader } from "@/components/shell";
import { OnboardingCTA } from "@/components/onboarding-cta";
import { TestAnalysisForm } from "@/components/widgets2";
import { TrendLine } from "@/components/charts";
import { getUser, getContext, todayStr, fmtDate, fmtDateFull, diffDays } from "@/lib/engine";

export const dynamic = "force-dynamic";

export default async function TestsPage() {
  const user = await getUser();
  if (!user) return <OnboardingCTA />;
  const today = todayStr();
  const ctx = await getContext(user.id);

  const attempted = ctx.tests
    .filter((t) => t.status === "attempted")
    .sort((a, b) => (a.scheduledAt < b.scheduledAt ? -1 : 1));
  const upcoming = ctx.tests
    .filter((t) => t.status === "scheduled")
    .sort((a, b) => (a.scheduledAt < b.scheduledAt ? -1 : 1));

  const fullPart = attempted.filter((t) => t.type !== "chapter");
  const trend = fullPart.map((t) => ({
    d: fmtDate(t.scheduledAt),
    score: Math.round(((t.obtainedMarks ?? 0) / t.totalMarks) * 100),
  }));
  const best = attempted.reduce((m, t) => Math.max(m, t.obtainedMarks ?? 0), 0);
  const avg = attempted.length
    ? Math.round(attempted.reduce((s, t) => s + ((t.obtainedMarks ?? 0) / t.totalMarks) * 100, 0) / attempted.length)
    : 0;
  const last = fullPart[fullPart.length - 1];

  return (
    <div>
      <PageHeader title="Tests" sub="Attempts, trends and what the scores are telling you" />

      <div className="mb-4 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Card><Stat label="Attempted" value={String(attempted.length)} sub="part + full + chapter" /></Card>
        <Card><Stat label="Average score" value={`${avg}%`} tone={avg >= 55 ? "good" : "warn"} /></Card>
        <Card><Stat label="Best score" value={String(best)} tone="good" sub={last ? `last: ${last.obtainedMarks}/${last.totalMarks}` : undefined} /></Card>
        <Card><Stat label="Next test" value={upcoming[0] ? `in ${diffDays(upcoming[0].scheduledAt, today)}d` : "—"} tone="warn" sub={upcoming[0]?.title} /></Card>
      </div>

      {upcoming.length > 0 && (
        <div className="mb-4 grid gap-4 md:grid-cols-2">
          {upcoming.map((t) => (
            <Card key={t.id} accent className="animate-fade-up delay-1">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <CalendarClock size={14} className="text-warn" />
                    <span className="font-display text-sm font-semibold text-ink">{t.title}</span>
                    <Chip color="#E879F9">{t.type}</Chip>
                  </div>
                  <div className="mt-1 text-xs text-ink-3">
                    {fmtDateFull(t.scheduledAt)} · in {diffDays(t.scheduledAt, today)} days · {t.totalMarks} marks
                  </div>
                  <p className="mt-1 text-[11px] text-ink-3">Prep blocks are auto-scheduled in your planner 3 days out.</p>
                </div>
                {diffDays(t.scheduledAt, today) <= 0 && <TestAnalysisForm id={t.id} max={t.totalMarks} />}
              </div>
            </Card>
          ))}
        </div>
      )}

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2 animate-fade-up delay-2">
          <CardHeader icon={<TrendingUp size={15} />} title="Score trend" sub="Part + full syllabus tests · % of total" />
          {trend.length < 2 ? (
            <p className="py-8 text-center text-xs text-ink-3">Attempt at least two tests to see a trend.</p>
          ) : (
            <TrendLine data={trend} dataKey="score" color="#34D399" unit="%" />
          )}
        </Card>

        <Card className="animate-fade-up delay-3">
          <CardHeader icon={<ClipboardList size={15} />} title="Subject split" sub="Latest full/part test" />
          {last ? (
            <div className="space-y-3">
              {[
                { n: "Physics", v: last.physicsMarks ?? 0, c: "#38BDF8" },
                { n: "Chemistry", v: last.chemistryMarks ?? 0, c: "#A78BFA" },
                { n: "Mathematics", v: last.mathsMarks ?? 0, c: "#FBBF24" },
              ].map((x) => (
                <div key={x.n}>
                  <div className="mb-1 flex justify-between text-[11px]">
                    <span style={{ color: x.c }}>{x.n}</span>
                    <span className="tabular text-ink-3">{x.v}/100</span>
                  </div>
                  <Bar pct={x.v} color={x.c} />
                </div>
              ))}
              <p className="pt-1 text-[11px] leading-relaxed text-ink-3">
                Weakest section this attempt:{" "}
                <span className="font-semibold text-ink-2">
                  {[
                    { n: "Physics", v: last.physicsMarks ?? 0 },
                    { n: "Chemistry", v: last.chemistryMarks ?? 0 },
                    { n: "Mathematics", v: last.mathsMarks ?? 0 },
                  ].sort((a, b) => a.v - b.v)[0].n}
                </span>{" "}
                — PYQ blocks have been biased towards it this week.
              </p>
            </div>
          ) : (
            <p className="py-8 text-center text-xs text-ink-3">No tests attempted yet.</p>
          )}
        </Card>
      </div>

      {/* deterministic test analysis */}
      {(() => {
        const analyzed = [...attempted].reverse().find((t) => t.qAttempted != null);
        if (!analyzed) return null;
        const acc = analyzed.qAttempted ? Math.round(((analyzed.qCorrect ?? 0) / analyzed.qAttempted) * 100) : 0;
        const misses = [
          { k: "Conceptual", v: analyzed.mConceptual ?? 0, c: "#FB7185" },
          { k: "Calculation", v: analyzed.mCalculation ?? 0, c: "#FBBF24" },
          { k: "Silly", v: analyzed.mSilly ?? 0, c: "#FB923C" },
          { k: "Time mgmt", v: analyzed.mTime ?? 0, c: "#A78BFA" },
        ];
        const worst = [...misses].sort((a, b) => b.v - a.v)[0];
        const totalM = Math.max(1, misses.reduce((s, m) => s + m.v, 0));
        const insights: string[] = [];
        if (acc < 60) insights.push(`Accuracy ${acc}% is below the 60% floor — attempt selection needs tightening.`);
        if (worst && worst.v > 0) insights.push(`${worst.k} mistakes dominate (${worst.v} of ${totalM} flagged errors) — ${worst.k === "Conceptual" ? "schedule concept revisions, not more questions" : worst.k === "Calculation" ? "slow down mid-steps; do error-book drills" : worst.k === "Silly" ? "re-check units/signs before marking" : "do timed question sets"}.`);
        if ((analyzed.qUnattempted ?? 0) > 10) insights.push(`${analyzed.qUnattempted} unattempted questions — build stamina with longer PYQ blocks this week.`);
        const splits = [
          { n: "Physics", v: analyzed.physicsMarks ?? 0 }, { n: "Chemistry", v: analyzed.chemistryMarks ?? 0 }, { n: "Mathematics", v: analyzed.mathsMarks ?? 0 },
        ];
        const weakSplit = [...splits].sort((a, b) => a.v - b.v)[0];
        insights.push(`${weakSplit.n} was the weakest section (${weakSplit.v}/100) — planner has biased next week's PYQ blocks toward it.`);
        return (
          <Card className="mt-4 animate-fade-up delay-3">
            <CardHeader icon={<Microscope size={15} />} title={`Test analysis — ${analyzed.title}`} sub="Deterministic rules, no AI" />
            <div className="grid gap-4 md:grid-cols-3">
              <div className="grid grid-cols-2 gap-3">
                <Stat label="Attempted" value={String(analyzed.qAttempted ?? "—")} />
                <Stat label="Accuracy" value={`${acc}%`} tone={acc >= 60 ? "good" : "warn"} />
                <Stat label="Correct" value={String(analyzed.qCorrect ?? "—")} />
                <Stat label="Unattempted" value={String(analyzed.qUnattempted ?? "—")} />
              </div>
              <div>
                <div className="mb-2 text-[10px] font-semibold uppercase tracking-[0.14em] text-ink-3">Mistake taxonomy</div>
                <div className="space-y-2">
                  {misses.map((m) => (
                    <div key={m.k}>
                      <div className="mb-0.5 flex justify-between text-[10px]"><span className="text-ink-3">{m.k}</span><span className="tabular text-ink-2">{m.v}</span></div>
                      <Bar pct={(m.v / totalM) * 100} color={m.c} />
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <div className="mb-2 text-[10px] font-semibold uppercase tracking-[0.14em] text-ink-3">Generated insights</div>
                <ul className="space-y-1.5">
                  {insights.map((s, i) => <li key={i} className="text-[11px] leading-relaxed text-ink-2">· {s}</li>)}
                </ul>
              </div>
            </div>
          </Card>
        );
      })()}

      <Card className="mt-4 animate-fade-up delay-4">
        <CardHeader icon={<ClipboardList size={15} />} title="Attempt history" />
        <div className="overflow-x-auto">
          <table className="w-full min-w-[560px] text-left text-xs">
            <thead>
              <tr className="text-[10px] uppercase tracking-wider text-ink-3">
                <th className="pb-2 pr-3 font-medium">Test</th>
                <th className="pb-2 pr-3 font-medium">Date</th>
                <th className="pb-2 pr-3 font-medium">Type</th>
                <th className="pb-2 pr-3 font-medium">Score</th>
                <th className="pb-2 font-medium">%</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {[...attempted].reverse().map((t) => {
                const p = Math.round(((t.obtainedMarks ?? 0) / t.totalMarks) * 100);
                return (
                  <tr key={t.id}>
                    <td className="py-2 pr-3 font-medium text-ink-2">{t.title}</td>
                    <td className="py-2 pr-3 tabular text-ink-3">{fmtDate(t.scheduledAt)}</td>
                    <td className="py-2 pr-3"><Chip>{t.type}</Chip></td>
                    <td className="py-2 pr-3 tabular text-ink">{t.obtainedMarks}/{t.totalMarks}</td>
                    <td className="py-2 tabular font-semibold" style={{ color: p >= 55 ? "#34D399" : p >= 40 ? "#FBBF24" : "#FB7185" }}>{p}%</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
