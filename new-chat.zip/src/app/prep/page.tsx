import Link from "next/link";
import { Map as MapIcon, AlertTriangle, TrendingUp, GitCompareArrows } from "lucide-react";
import { Card, CardHeader, Chip, Stat } from "@/components/ui";
import { PageHeader } from "@/components/shell";
import { OnboardingCTA } from "@/components/onboarding-cta";
import { getUser, getContext, subjectStats, todayStr } from "@/lib/engine";
import { chapterPrepBreakdown } from "@/lib/ops";

export const dynamic = "force-dynamic";

const CELL = ["bg-panel-3", "bg-danger/70", "bg-warn/60", "bg-warn", "bg-accent/80", "bg-accent"];
const cellFor = (pct: number) =>
  CELL[pct <= 0 ? 0 : pct <= 25 ? 1 : pct <= 50 ? 2 : pct <= 75 ? 3 : pct <= 90 ? 4 : 5];

export default async function PrepPage() {
  const user = await getUser();
  if (!user) return <OnboardingCTA />;
  const today = todayStr();
  const ctx = await getContext(user.id);
  const stats = subjectStats(ctx, today);

  const bySubject = stats.map((s) => {
    const rows = s.chapters
      .slice()
      .sort((a, b) => a.position - b.position)
      .map((c) => ({ c, prep: chapterPrepBreakdown(ctx, c.id) }));
    const overall = rows.length ? Math.round(rows.reduce((x, r) => x + r.prep.total, 0) / rows.length) : 0;
    return { s, rows, overall };
  }).sort((a, b) => b.s.position - a.s.position || a.overall - b.overall);

  const weakest = [...bySubject].sort((a, b) => a.overall - b.overall)[0];

  return (
    <div>
      <PageHeader
        title="My Preparation"
        sub="The full preparation map — every chapter scored from lectures, DPPs, PYQs, revision, tests and notes"
        right={<Chip color="#34D399">click any chapter to drill down</Chip>}
      />

      {/* subject comparison */}
      <div className="mb-4 grid gap-4 md:grid-cols-3">
        {bySubject.map(({ s, overall }, i) => (
          <Card key={s.id} className={`animate-fade-up delay-${i + 1} flex items-center justify-between`}>
            <div className="flex items-center gap-2.5">
              <GitCompareArrows size={15} style={{ color: s.color }} />
              <span className="font-display text-sm font-semibold" style={{ color: s.color }}>{s.name}</span>
            </div>
            <span className="font-display text-2xl font-bold tabular text-ink">{overall}%</span>
          </Card>
        ))}
      </div>
      <div className="mb-5 rounded-xl border border-warn/25 bg-warn/[0.06] px-4 py-3 text-xs text-ink-2 animate-fade-up delay-2">
        <span className="font-semibold text-warn">{weakest?.s.name} needs the most attention</span> —{" "}
        {weakest?.overall}% overall vs {Math.max(...bySubject.map((x) => x.overall))}% in your strongest subject.
        The planner already biases PYQ blocks towards it.
      </div>

      <div className="space-y-5">
        {bySubject.map(({ s, rows, overall }, si) => (
          <Card key={s.id} className={`animate-fade-up delay-${Math.min(5, si + 2)}`}>
            <CardHeader
              icon={<MapIcon size={15} style={{ color: s.color }} />}
              title={s.name}
              sub={`${s.completed}/${s.total} chapters complete · overall ${overall}%`}
              right={
                <div className="flex items-center gap-1 text-[9px] text-ink-3">
                  <span>0%</span>
                  {CELL.map((c) => <span key={c} className={`size-2.5 rounded-sm ${c}`} />)}
                  <span>100%</span>
                </div>
              }
            />

            {/* preparation heatmap */}
            <div className="mb-4 flex flex-wrap gap-1">
              {rows.map(({ c, prep }) => (
                <Link
                  key={c.id}
                  href={`/chapters/${c.id}`}
                  title={`${c.name} — ${prep.total}% (${prep.level})`}
                  className={`h-6 w-9 rounded-[5px] transition hover:ring-2 hover:ring-white/30 ${cellFor(prep.total)}`}
                />
              ))}
            </div>

            <div className="grid gap-2 md:grid-cols-2">
              {rows.map(({ c, prep }) => (
                <Link
                  key={c.id}
                  href={`/chapters/${c.id}`}
                  className="flex items-center gap-3 rounded-xl border border-line bg-panel-2 px-3 py-2.5 transition hover:border-line-2"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="truncate text-xs font-medium text-ink">{c.name}</span>
                      {c.isCurrent && <Chip color="#38BDF8">LIVE</Chip>}
                      {c.manualLevel && <Chip color="#FBBF24">{c.manualLevel}</Chip>}
                    </div>
                    <div className="mt-1 flex h-1.5 w-full gap-0.5">
                      {(
                        [
                          ["lectures", "#38BDF8"], ["dpp", "#FBBF24"], ["practice", "#A78BFA"],
                          ["pyq", "#F97316"], ["revision", "#34D399"], ["tests", "#E879F9"], ["notes", "#9CA3AF"],
                        ] as const
                      ).map(([k, color]) => (
                        <span
                          key={k}
                          title={`${k} ${prep[k]}%`}
                          className="h-full rounded-sm first:rounded-l-full last:rounded-r-full"
                          style={{ width: `${prep[k]}%`, background: color, opacity: 0.9 }}
                        />
                      ))}
                    </div>
                    <div className="mt-1 flex gap-2 text-[9px] text-ink-3">
                      <span>L {prep.lectures}%</span><span>DPP {prep.dpp}%</span><span>PYQ {prep.pyq}%</span><span>Rev {prep.revision}%</span>
                    </div>
                  </div>
                  <div className="shrink-0 text-right">
                    <div className="font-display text-base font-bold tabular" style={{ color: prep.total >= 76 ? "var(--color-accent)" : prep.total >= 51 ? "var(--color-ink)" : prep.total >= 26 ? "var(--color-warn)" : "var(--color-ink-3)" }}>
                      {prep.total}%
                    </div>
                    <div className="text-[9px] uppercase tracking-wider text-ink-3">{prep.level}</div>
                  </div>
                </Link>
              ))}
            </div>
          </Card>
        ))}
      </div>

      <div className="mt-5 grid gap-4 md:grid-cols-2">
        <Card className="animate-fade-up delay-4">
          <CardHeader icon={<AlertTriangle size={15} className="text-danger" />} title="Weakest chapters overall" sub="Prep < 50% with batch exposure" />
          <ul className="space-y-1.5">
            {bySubject
              .flatMap(({ s, rows }) => rows.filter(({ c, prep }) => prep.total < 50 && c.status !== "not_started").map(({ c, prep }) => ({ c, prep, color: s.color })))
              .sort((a, b) => a.prep.total - b.prep.total)
              .slice(0, 6)
              .map(({ c, prep, color }) => (
                <li key={c.id}>
                  <Link href={`/chapters/${c.id}`} className="flex items-center justify-between rounded-lg px-2 py-1.5 text-xs transition hover:bg-panel-2">
                    <span className="text-ink-2">{c.name}</span>
                    <span className="tabular" style={{ color }}>{prep.total}%</span>
                  </Link>
                </li>
              ))}
          </ul>
        </Card>
        <Card className="animate-fade-up delay-5">
          <CardHeader icon={<TrendingUp size={15} className="text-accent" />} title="Strongest chapters" sub="Prep ≥ 76%" />
          <ul className="space-y-1.5">
            {bySubject
              .flatMap(({ s, rows }) => rows.filter(({ prep }) => prep.total >= 76).map(({ c, prep }) => ({ c, prep, color: s.color })))
              .sort((a, b) => b.prep.total - a.prep.total)
              .slice(0, 6)
              .map(({ c, prep, color }) => (
                <li key={c.id}>
                  <Link href={`/chapters/${c.id}`} className="flex items-center justify-between rounded-lg px-2 py-1.5 text-xs transition hover:bg-panel-2">
                    <span className="text-ink-2">{c.name}</span>
                    <span className="tabular" style={{ color }}>{prep.total}%</span>
                  </Link>
                </li>
              ))}
          </ul>
        </Card>
      </div>
    </div>
  );
}
