import { Sparkles } from "lucide-react";
import { Card, Chip } from "@/components/ui";
import { PageHeader } from "@/components/shell";
import { OnboardingCTA } from "@/components/onboarding-cta";
import { AiChat } from "@/components/ai-chat";
import { db } from "@/db";
import { aiMessages } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getUser } from "@/lib/engine";

export const dynamic = "force-dynamic";

export default async function AiPage() {
  const user = await getUser();
  if (!user) return <OnboardingCTA />;

  const history = await db.select().from(aiMessages).where(eq(aiMessages.userId, user.id));
  const initial = history
    .sort((a, b) => (a.createdAt?.getTime() ?? 0) - (b.createdAt?.getTime() ?? 0))
    .slice(-20)
    .map((m) => ({ role: m.role as "user" | "assistant", content: m.content }));

  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader
        title="Study Assistant"
        sub="Deterministic planner intelligence — grounded in your live tracker data · zero AI API"
        right={<Chip color="#34D399"><Sparkles size={10} /> rule engine · no AI API</Chip>}
      />
      <Card className="animate-fade-up delay-1">
        <AiChat initial={initial} />
      </Card>
      <p className="mt-3 text-center text-[11px] leading-relaxed text-ink-3">
        Every answer is computed from your actual database state at query time — no generic advice, no invented numbers.
      </p>
    </div>
  );
}
