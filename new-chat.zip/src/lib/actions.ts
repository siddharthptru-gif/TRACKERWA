"use server";

import { db } from "@/db";
import {
  users, lectures, chapters, practiceItems, revisionEvents, tests,
  planTasks, goals, checkins, dailyMetrics,
} from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import {
  getUser, getContext, todayStr, addDays, completeRevision,
  generatePlan, backlogPlan, aiAnswer, REVISION_STAGES, clamp,
} from "@/lib/engine";
import { seedDemo, type OnboardingPrefs } from "@/db/seed";

const refresh = () => revalidatePath("/", "layout");

async function bumpMetric(
  userId: number,
  date: string,
  patch: { studyMin?: number; lecturesDone?: number; revisionsDone?: number; questions?: number }
) {
  const existing = await db
    .select()
    .from(dailyMetrics)
    .where(and(eq(dailyMetrics.userId, userId), eq(dailyMetrics.date, date)));
  if (existing.length === 0) {
    await db.insert(dailyMetrics).values({
      userId, date,
      studyMin: patch.studyMin ?? 0,
      lecturesDone: patch.lecturesDone ?? 0,
      revisionsDone: patch.revisionsDone ?? 0,
      questions: patch.questions ?? 0,
      backlogCount: 0, accuracy: 0,
    });
  } else {
    const cur = existing[0];
    await db.update(dailyMetrics).set({
      studyMin: Math.max(0, cur.studyMin + (patch.studyMin ?? 0)),
      lecturesDone: Math.max(0, cur.lecturesDone + (patch.lecturesDone ?? 0)),
      revisionsDone: Math.max(0, cur.revisionsDone + (patch.revisionsDone ?? 0)),
      questions: Math.max(0, cur.questions + (patch.questions ?? 0)),
    }).where(eq(dailyMetrics.id, cur.id));
  }
}

async function scheduleChapterRevisions(chapterId: number, fromDate: string) {
  // don't double-schedule
  const existing = await db.select().from(revisionEvents).where(eq(revisionEvents.chapterId, chapterId));
  if (existing.some((r) => r.status !== "completed")) return;
  let d = fromDate;
  for (let stage = 1; stage <= 5; stage++) {
    d = addDays(d, REVISION_STAGES[stage - 1]);
    await db.insert(revisionEvents).values({ chapterId, stage, dueDate: d, status: "scheduled" });
  }
}

export async function markLectureComplete(lectureId: number, done: boolean) {
  const [lec] = await db.select().from(lectures).where(eq(lectures.id, lectureId));
  if (!lec) return;
  await db.update(lectures).set({
    status: done ? "completed" : "pending",
    completedAt: done ? new Date() : null,
  }).where(eq(lectures.id, lectureId));

  const chs = await db.select().from(chapters).where(eq(chapters.id, lec.chapterId));
  const ch = chs[0];
  if (!ch) return;
  if (done) {
    await db.update(chapters).set({
      mastery: clamp(ch.mastery + 3, 0, 100),
      status: ch.status === "not_started" ? "in_progress" : ch.status,
      startedAt: ch.startedAt ?? todayStr(),
    }).where(eq(chapters.id, ch.id));
  }
  // chapter finished? → enters revision cycle
  const all = await db.select().from(lectures).where(eq(lectures.chapterId, ch.id));
  if (done && all.every((l) => l.status === "completed")) {
    const today = todayStr();
    await db.update(chapters).set({
      status: "completed", completedAt: today, notesDone: true,
      mastery: clamp(ch.mastery + 10, 0, 100),
    }).where(eq(chapters.id, ch.id));
    await scheduleChapterRevisions(ch.id, today);
  }
}

export async function toggleTask(taskId: number) {
  const user = await getUser();
  if (!user) return;
  const [task] = await db.select().from(planTasks).where(eq(planTasks.id, taskId));
  if (!task) return;
  const done = task.status !== "done";
  await db.update(planTasks)
    .set({ status: done ? "done" : "pending" })
    .where(eq(planTasks.id, taskId));

  const sign = done ? 1 : -1;
  await bumpMetric(user.id, todayStr(), {
    studyMin: sign * Math.round(task.estMin),
    lecturesDone: task.kind === "lecture" || task.kind === "backlog" ? sign : 0,
    revisionsDone: task.kind === "revision" ? sign : 0,
    questions: ["dpp", "pyq", "practice", "weak_topic"].includes(task.kind) ? sign * 30 : 0,
  });

  // side-effects into the real tracker state
  if (task.refType === "lecture" && task.refId) {
    await markLectureComplete(task.refId, done);
  } else if (task.refType === "practice" && task.refId) {
    const [p] = await db.select().from(practiceItems).where(eq(practiceItems.id, task.refId));
    if (p) {
      await db.update(practiceItems).set({
        status: done ? "completed" : "in_progress",
        solved: done ? p.totalQuestions : Math.min(p.solved, p.totalQuestions - 1),
        accuracy: p.accuracy ?? 62,
        updatedAt: new Date(),
      }).where(eq(practiceItems.id, p.id));
    }
  } else if (task.refType === "revision" && task.refId && done) {
    const ctx = await getContext(user.id);
    await completeRevision(task.refId, ctx, 75, todayStr());
  }
  refresh();
}

export async function regeneratePlanAction() {
  const user = await getUser();
  if (!user) return;
  await generatePlan(user.id, todayStr());
  refresh();
}

export async function applyBacklogPlanAction() {
  const user = await getUser();
  if (!user) return;
  const ctx = await getContext(user.id);
  const today = todayStr();
  const bp = backlogPlan(ctx, today);
  for (const day of bp.days) {
    for (const item of day.items) {
      const ch = ctx.chapters.find((c) => c.id === item.chapterId);
      await db.insert(planTasks).values({
        userId: user.id, date: day.date, title: item.title,
        kind: "backlog", refType: "lecture", refId: item.id,
        subjectId: ch?.subjectId ?? null,
        estMin: item.durationMin, priority: 55,
        status: "pending",
        reason: `Backlog-clearing plan · oldest-first dose · ${ch?.name ?? ""}`,
        position: 50,
      });
    }
  }
  refresh();
}

export async function completeRevisionAction(revisionId: number, score: number) {
  const user = await getUser();
  if (!user) return;
  const ctx = await getContext(user.id);
  await completeRevision(revisionId, ctx, score, todayStr());
  await bumpMetric(user.id, todayStr(), { revisionsDone: 1, studyMin: 45 });
  refresh();
}

export async function toggleLectureAction(lectureId: number) {
  const user = await getUser();
  if (!user) return;
  const [lec] = await db.select().from(lectures).where(eq(lectures.id, lectureId));
  if (!lec) return;
  await markLectureComplete(lectureId, lec.status !== "completed");
  refresh();
}

export async function updatePracticeStatus(itemId: number, status: string) {
  const [p] = await db.select().from(practiceItems).where(eq(practiceItems.id, itemId));
  if (!p) return;
  await db.update(practiceItems).set({
    status,
    solved: status === "completed" ? p.totalQuestions : p.solved,
    accuracy: status === "completed" ? (p.accuracy ?? 64) : p.accuracy,
    updatedAt: new Date(),
  }).where(eq(practiceItems.id, itemId));
  refresh();
}

export async function logTestScore(testId: number, marks: number) {
  const [t] = await db.select().from(tests).where(eq(tests.id, testId));
  if (!t) return;
  const phy = Math.round(marks * 0.36);
  const chem = Math.round(marks * 0.34);
  await db.update(tests).set({
    status: "attempted",
    attemptedAt: new Date(),
    obtainedMarks: marks,
    physicsMarks: phy, chemistryMarks: chem, mathsMarks: marks - phy - chem,
  }).where(eq(tests.id, t.id));
  refresh();
}

export async function submitCheckin(form: {
  minutes: number; lecturesDone: number; questionsSolved: number;
  revisionsDone: number; testsAttempted: number; energy: number; note?: string;
}) {
  const user = await getUser();
  if (!user) return;
  const today = todayStr();
  const todays = await db.select().from(planTasks)
    .where(and(eq(planTasks.userId, user.id), eq(planTasks.date, today)));
  const total = todays.length;
  const doneN = todays.filter((t) => t.status === "done").length;
  const completion = total ? doneN / total : 0;

  await db.insert(checkins).values({
    userId: user.id, date: today,
    minutes: form.minutes, lecturesDone: form.lecturesDone,
    questionsSolved: form.questionsSolved, revisionsDone: form.revisionsDone,
    testsAttempted: form.testsAttempted, energy: form.energy,
    note: form.note ?? null, completionRate: completion,
  });

  await bumpMetric(user.id, today, {
    studyMin: form.minutes,
    lecturesDone: form.lecturesDone,
    questions: form.questionsSolved,
    revisionsDone: form.revisionsDone,
  });

  // adaptive load recalibration for tomorrow
  let load = user.adaptiveLoad;
  if (completion >= 0.95 && form.energy >= 3) load = clamp(load + 0.05, 0.7, 1.1);
  else if (completion < 0.7 || form.energy <= 2) load = clamp(load - 0.1, 0.7, 1.1);
  await db.update(users).set({ adaptiveLoad: load }).where(eq(users.id, user.id));

  // unfinished today → spread over the next 2 days, not dumped on tomorrow
  const unfinished = todays.filter((t) => t.status === "pending");
  for (const [i, t] of unfinished.entries()) {
    await db.update(planTasks).set({
      date: addDays(today, (i % 2) + 1),
      priority: t.priority + 3,
      reason: "Carried forward by evening check-in · redistributed",
    }).where(eq(planTasks.id, t.id));
  }
  refresh();
}

export async function saveGoalsAction(form: {
  dailyMinutes: number; weeklyQuestions: number; monthlyChapters: number;
  targetRankMain: number; targetRankAdv: number; examDateMain?: string; examDateAdv?: string;
}) {
  const user = await getUser();
  if (!user) return;
  const g = await db.select().from(goals).where(eq(goals.userId, user.id));
  const values = {
    dailyMinutes: form.dailyMinutes,
    weeklyQuestions: form.weeklyQuestions,
    monthlyChapters: form.monthlyChapters,
    targetRankMain: form.targetRankMain,
    targetRankAdv: form.targetRankAdv,
    examDateMain: form.examDateMain || null,
    examDateAdv: form.examDateAdv || null,
  };
  if (g.length) await db.update(goals).set(values).where(eq(goals.id, g[0].id));
  else await db.insert(goals).values({ userId: user.id, ...values });
  await db.update(users).set({ dailyMinutes: form.dailyMinutes, targetRank: form.targetRankMain }).where(eq(users.id, user.id));
  refresh();
}

export async function askAiAction(question: string) {
  const user = await getUser();
  if (!user) return "Set up your profile first.";
  return aiAnswer(user.id, question);
}

export async function runOnboardingAction(prefs: OnboardingPrefs) {
  await seedDemo(prefs);
  refresh();
}

export async function reseedAction() {
  await seedDemo({});
  refresh();
}
