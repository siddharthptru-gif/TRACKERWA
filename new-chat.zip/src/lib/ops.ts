import { db } from "@/db";
import {
  users, batches, subjects, chapters, lectures, practiceItems,
  revisionEvents, tests, planTasks, goals, dailyMetrics, checkins,
  studySessions, userSettings, weakTopics, errorBook, timetableBlocks, customEvents,
} from "@/db/schema";
import { eq, and } from "drizzle-orm";
import {
  type Ctx, chapterLectures, chapterPractice, lectureProgress, backlogItems,
  completionStats, subjectStats, todayStr, addDays, diffDays, fmtMin, clamp,
  viewMin, availableMinutesFor,
} from "@/lib/engine";

/* ══════════════ Chapter Prep Meter (explainable breakdown) ══════════════ */

export type PrepBreakdown = {
  lectures: number; dpp: number; practice: number; pyq: number;
  revision: number; tests: number; notes: number;
  total: number; level: string; override: boolean;
};

export const PREP_WEIGHTS = { lectures: 0.25, dpp: 0.15, practice: 0.15, pyq: 0.15, revision: 0.15, tests: 0.1, notes: 0.05 };

export function prepLevelLabel(pct: number): string {
  if (pct <= 0) return "Not started";
  if (pct <= 25) return "Started";
  if (pct <= 50) return "Basic";
  if (pct <= 75) return "Developing";
  if (pct <= 90) return "Strong";
  return "Complete";
}

export function chapterPrepBreakdown(ctx: Ctx, chapterId: number): PrepBreakdown {
  const ch = ctx.chapters.find((c) => c.id === chapterId)!;
  const lp = lectureProgress(ctx, chapterId);
  const pr = chapterPractice(ctx, chapterId);
  const of = (t: string) => pr.filter((p) => p.type === t);
  const pctOf = (items: typeof pr) =>
    items.length ? Math.round((items.reduce((s, p) => s + p.solved, 0) / items.reduce((s, p) => s + p.totalQuestions, 0)) * 100) : 0;

  const revs = ctx.revisions.filter((r) => r.chapterId === chapterId);
  const revDone = revs.filter((r) => r.status === "completed").length;

  const lecturePct = lp.pct;
  const dppPct = pctOf(of("dpp"));
  const practicePct = pctOf(of("module"));
  const pyqPct = pr.filter((p) => p.type.startsWith("pyq")).length
    ? pctOf(pr.filter((p) => p.type.startsWith("pyq"))) : 0;
  const revisionPct = ch.status === "completed"
    ? Math.round((revDone / Math.max(1, revs.length || ctx.revisionIntervals.length)) * 100)
    : Math.min(100, revDone ? 50 : 0);
  const testsPct = ch.status === "completed" ? 70 : ch.status === "in_progress" ? 30 : 0; // chapter-level tests enter via test analysis
  const notesPct = ch.notesDone ? 100 : ch.status === "not_started" ? 0 : 40;

  let total = Math.round(
    PREP_WEIGHTS.lectures * lecturePct +
    PREP_WEIGHTS.dpp * dppPct +
    PREP_WEIGHTS.practice * practicePct +
    PREP_WEIGHTS.pyq * pyqPct +
    PREP_WEIGHTS.revision * revisionPct +
    PREP_WEIGHTS.tests * testsPct +
    PREP_WEIGHTS.notes * notesPct
  );
  if (ch.prepOverride != null) total = ch.prepOverride;
  return {
    lectures: lecturePct, dpp: dppPct, practice: practicePct, pyq: pyqPct,
    revision: revisionPct, tests: testsPct, notes: notesPct,
    total, level: ch.manualLevel ?? prepLevelLabel(total), override: ch.prepOverride != null,
  };
}

/* ══════════════ Backlog — type-wise, time-weighted ══════════════ */

export type BacklogSlice = {
  key: string; label: string; count: number; minutes: number; color: string; detail: string;
};

export function backlogBreakdown(ctx: Ctx, today: string): { slices: BacklogSlice[]; totalMin: number; totalCount: number } {
  const speed = ctx.playbackSpeed;
  const lec = backlogItems(ctx, today);
  const lecMin = lec.reduce((s, l) => s + viewMin(Math.ceil(l.durationMin * (1 - (l.watchedPct ?? 0) / 100)), speed), 0);

  const dppPend = ctx.practice.filter((p) => {
    if (p.type !== "dpp" || p.status === "completed") return false;
    const ch = ctx.chapters.find((c) => c.id === p.chapterId);
    return ch && ch.status !== "not_started" && !ch.isCurrent;
  });
  const dppQ = dppPend.reduce((s, p) => s + (p.totalQuestions - p.solved), 0);

  const revDue = ctx.revisions.filter(
    (r) => r.status !== "completed" && r.status !== "skipped" && r.dueDate <= today
  );

  const testPend = ctx.tests.filter((t) => t.status === "scheduled" && t.scheduledAt < today);

  const pyqPend = ctx.practice.filter((p) => {
    if (!p.type.startsWith("pyq") || p.status === "completed") return false;
    const ch = ctx.chapters.find((c) => c.id === p.chapterId);
    return ch && ch.status === "completed";
  });
  const pyqQ = pyqPend.reduce((s, p) => s + (p.totalQuestions - p.solved), 0);

  const notesPend = ctx.chapters.filter(
    (c) => (c.status === "completed" || c.status === "in_progress") && !c.notesDone && !c.isCurrent
  ).length;

  const slices: BacklogSlice[] = [
    { key: "lecture", label: "Lectures", count: lec.length, minutes: lecMin, color: "#38BDF8", detail: `at ${speed}x speed` },
    { key: "dpp", label: "DPPs", count: dppPend.length, minutes: dppQ * 3, color: "#FBBF24", detail: `${dppQ} questions left` },
    { key: "revision", label: "Revisions", count: revDue.length, minutes: revDue.length * 45, color: "#34D399", detail: "due or overdue" },
    { key: "test", label: "Tests", count: testPend.length, minutes: testPend.length * 180, color: "#E879F9", detail: "pending attempts" },
    { key: "pyq", label: "PYQs", count: pyqQ, minutes: Math.round(pyqQ * 2.5), color: "#F97316", detail: "chapter-complete backlog" },
    { key: "notes", label: "Notes", count: notesPend, minutes: notesPend * 30, color: "#A78BFA", detail: "chapters without notes" },
  ];
  return {
    slices,
    totalMin: slices.reduce((s, x) => s + x.minutes, 0),
    totalCount: slices.reduce((s, x) => s + x.count, 0),
  };
}

/* ══════════════ BACKLOG KILLER (duration × mode) ══════════════ */

export type KillerItem = { title: string; minutes: number; kind: string; refType: string; refId: number; subjectId: number | null };
export type KillerPlanRow = { date: string; label: string; minutes: number; items: KillerItem[] };

export function backlogKiller(
  ctx: Ctx, today: string, days: number, mode: "safe" | "balanced" | "aggressive"
): {
  rows: KillerPlanRow[]; feasible: boolean; verdict: string;
  dailyBacklogMin: number; protectedMin: number;
} {
  const modeMult = mode === "safe" ? 1 : mode === "balanced" ? 1.5 : 2.2;
  const bd = backlogBreakdown(ctx, today);
  const currentChapters = ctx.chapters.filter((c) => c.isCurrent).length;
  const protectedMin = currentChapters * 80 + 45 + 60;
  const avail = ctx.user.dailyMinutes;
  const rawDose = Math.max(90, avail - protectedMin) * 0.8; // baseline dose share
  const dailyBacklogMin = Math.min(
    Math.round(rawDose * modeMult),
    Math.max(60, avail - Math.round(protectedMin * (mode === "aggressive" ? 0.7 : 1)))
  );

  // build typed item pool: lectures first, then DPP/PYQ mixes of completed chapters
  const pool: KillerItem[] = [];
  backlogItems(ctx, today)
    .sort((a, b) => ((a.taughtAt ?? "") < (b.taughtAt ?? "") ? -1 : 1))
    .forEach((l) => {
      const ch = ctx.chapters.find((c) => c.id === l.chapterId);
      pool.push({
        title: l.title,
        minutes: viewMin(Math.ceil(l.durationMin * (1 - (l.watchedPct ?? 0) / 100)), ctx.playbackSpeed),
        kind: "backlog", refType: "lecture", refId: l.id, subjectId: ch?.subjectId ?? null,
      });
    });
  ctx.practice
    .filter((p) => p.status !== "completed")
    .forEach((p) => {
      const ch = ctx.chapters.find((c) => c.id === p.chapterId);
      if (!ch || ch.status === "not_started" || ch.isCurrent) return;
      const perQ = p.type.startsWith("pyq") ? 2.5 : 3;
      pool.push({
        title: `${p.type.startsWith("pyq") ? "PYQs" : p.type.toUpperCase()} · ${ch.name} (${p.totalQuestions - p.solved}q)`,
        minutes: Math.max(20, Math.round((p.totalQuestions - p.solved) * perQ)),
        kind: p.type.startsWith("pyq") ? "pyq" : "dpp",
        refType: "practice", refId: p.id, subjectId: ch.subjectId,
      });
    });

  const needed = Math.ceil(bd.totalMin / Math.max(1, dailyBacklogMin));
  const feasible = needed <= days;
  const rows: KillerPlanRow[] = [];
  let poolIdx = 0;
  for (let d = 0; d < Math.min(days, Math.max(needed, 1)); d++) {
    const date = addDays(today, d);
    let budget = dailyBacklogMin;
    const items: KillerItem[] = [];
    let minutes = 0;
    while (poolIdx < pool.length && budget >= 20) {
      const it = pool[poolIdx++];
      items.push(it);
      minutes += it.minutes;
      budget -= it.minutes;
    }
    rows.push({ date, minutes, label: d === 0 ? "Today" : `Day ${d + 1}`, items });
    if (poolIdx >= pool.length) break;
  }
  return {
    rows, feasible, dailyBacklogMin, protectedMin,
    verdict: feasible
      ? `${mode === "safe" ? "Safe" : mode === "balanced" ? "Balanced" : "Aggressive"} mode clears ≈${fmtMin(bd.totalMin)} of typed backlog in ~${needed} of your ${days} days — ${fmtMin(dailyBacklogMin)}/day on backlog, ${fmtMin(protectedMin)}/day still protected for current batch + revision + practice.`
      : `${mode} mode needs ~${needed} days for this backlog — beyond your ${days}-day window. Try a longer window or a more aggressive mode; forcing ${fmtMin(Math.ceil(bd.totalMin / days))}/day would create an impossible schedule.`,
  };
}

/* ══════════════ WHAT SHOULD I DO NOW ══════════════ */

export function nowRecommendation(
  ctx: Ctx,
  tasks: { id: number; title: string; kind: string; estMin: number; priority: number; status: string; reason: string }[],
  today: string
): { task: (typeof tasks)[number] | null; headline: string; explain: string; remainingMin: number } {
  const cap = availableMinutesFor(ctx, today);
  const doneMin = tasks.filter((t) => t.status === "done").reduce((s, t) => s + t.estMin, 0);
  const remaining = Math.max(30, cap - doneMin);
  const pending = tasks.filter((t) => t.status === "pending");
  if (pending.length === 0) {
    return {
      task: null, headline: "Today's plan is complete.",
      remainingMin: remaining,
      explain: `Everything scheduled is done and you still have ≈${fmtMin(remaining)} of capacity. Best use: a PYQ block in your weakest subject — the planner will suggest it fresh tomorrow.`,
    };
  }
  const hour = new Date().getHours();
  const evening = hour >= 20;
  // prefer fitting tasks in the evening; small energy-aware reshuffle, fully deterministic
  const ranked = [...pending].sort((a, b) => {
    const fitA = a.estMin <= remaining ? 8 : 0;
    const fitB = b.estMin <= remaining ? 8 : 0;
    const evenA = evening && ["dpp", "pyq", "revision", "weak_topic"].includes(a.kind) ? 4 : 0;
    const evenB = evening && ["dpp", "pyq", "revision", "weak_topic"].includes(b.kind) ? 4 : 0;
    return b.priority + fitB + evenB - (a.priority + fitA + evenA);
  });
  const top = ranked[0];
  const kindWhy: Record<string, string> = {
    lecture: "your running batch chapter must stay on pace",
    backlog: "it is the oldest pending batch lecture and backlog only shrinks if touched daily",
    revision: "spaced memory decays fast past the due date",
    dpp: "this DPP is overdue and questions matter more than watching",
    pyq: "PYQ velocity is the single biggest rank lever",
    practice: "practice must stay parallel with the running chapter",
    weak_topic: "it was flagged weak by your test/DPP accuracy",
    test_prep: "a scheduled test is close and prep compounds",
    test: "a scheduled test is due",
  };
  return {
    task: top, remainingMin: remaining,
    headline: `Do this now — ${fmtMin(top.estMin)}`,
    explain: `Scored highest right now (${top.priority} pts) because ${kindWhy[top.kind] ?? "it tops the priority queue"}. It fits your remaining ≈${fmtMin(remaining)} today. Basis: ${top.reason}`,
  };
}

/* ══════════════ Preparation Health ══════════════ */

export function preparationHealth(ctx: Ctx, today: string): {
  score: number; label: "Excellent" | "Good" | "Stable" | "At Risk" | "Critical";
  color: string; reasons: string[];
} {
  const stats = completionStats(ctx);
  const bd = backlogBreakdown(ctx, today);
  const revDue = ctx.revisions.filter((r) => r.status !== "completed" && r.dueDate <= today).length;
  const revDone7 = ctx.metrics.filter((m) => diffDays(today, m.date) < 7 && m.date <= today)
    .reduce((s, m) => s + m.revisionsDone, 0);
  const m14 = [...ctx.metrics].reverse().find((m) => diffDays(today, m.date) >= 13);
  const blTrend = m14 ? backlogItems(ctx, today).length - m14.backlogCount : 0;
  const q7 = ctx.metrics.filter((m) => diffDays(today, m.date) < 7 && m.date <= today).reduce((s, m) => s + m.questions, 0);
  const adherent = ctx.metrics.filter((m) => diffDays(today, m.date) < 7 && m.date <= today && m.studyMin > 120).length;

  let score = 50;
  const reasons: string[] = [];
  score += (stats.readiness - 45) * 0.5;
  if (bd.totalCount > 25) { score -= 14; reasons.push(`Backlog volume is high (${bd.totalCount} items ≈ ${fmtMin(bd.totalMin)})`); }
  else if (bd.totalCount === 0) { score += 10; reasons.push("Zero backlog — capacity is being reinvested in PYQs"); }
  if (blTrend > 3) { score -= 10; reasons.push(`Backlog grew by ${blTrend} lectures over 14 days`); }
  else if (blTrend < -2) { score += 8; reasons.push(`Backlog shrank by ${-blTrend} lectures in 14 days`); }
  if (revDue > 5) { score -= 10; reasons.push(`${revDue} revisions overdue — memory debt compounding`); }
  else if (revDue <= 2 && revDone7 >= 3) { score += 10; reasons.push(`Strong revision cadence (${revDone7} this week)`); }
  if (q7 >= 350) { score += 10; reasons.push(`Practice velocity on target (${q7} questions this week)`); }
  else if (q7 < 180) { score -= 8; reasons.push(`Practice velocity low (${q7} questions this week)`); }
  if (adherent >= 5) { score += 8; reasons.push(`Schedule adherence ${adherent}/7 days`); }
  else if (adherent <= 2) { score -= 10; reasons.push(`Only ${adherent} fully-studied day(s) this week`); }
  if (stats.avgAcc < 55 && stats.avgAcc > 0) { score -= 6; reasons.push(`Average accuracy ${stats.avgAcc}% below the 60% floor`); }

  score = clamp(Math.round(score), 5, 98);
  const label =
    score >= 80 ? "Excellent" : score >= 65 ? "Good" : score >= 50 ? "Stable" : score >= 35 ? "At Risk" : "Critical";
  const color =
    score >= 80 ? "#34D399" : score >= 65 ? "#6EE7B7" : score >= 50 ? "#FBBF24" : score >= 35 ? "#FB923C" : "#FB7185";
  if (reasons.length === 0) reasons.push("All tracked signals are inside healthy bounds.");
  return { score, label, color, reasons: reasons.slice(0, 4) };
}

/* ══════════════ Weekly review (deterministic) ══════════════ */

export function weeklyReview(ctx: Ctx, today: string) {
  const last7 = ctx.metrics.filter((m) => diffDays(today, m.date) < 7 && m.date <= today);
  const prev7 = ctx.metrics.filter((m) => { const d = diffDays(today, m.date); return d >= 7 && d < 14; });
  const sum = (arr: typeof last7, k: "studyMin" | "questions" | "lecturesDone" | "revisionsDone") =>
    arr.reduce((s, m) => s + m[k], 0);
  const delta = (a: number, b: number) => (b === 0 ? (a > 0 ? 100 : 0) : Math.round(((a - b) / b) * 100));
  return {
    hours: { cur: Math.round(sum(last7, "studyMin") / 60), prev: Math.round(sum(prev7, "studyMin") / 60) },
    questions: { cur: sum(last7, "questions"), prev: sum(prev7, "questions") },
    lectures: { cur: sum(last7, "lecturesDone"), prev: sum(prev7, "lecturesDone") },
    revisions: { cur: sum(last7, "revisionsDone"), prev: sum(prev7, "revisionsDone") },
    delta,
  };
}

/* ══════════════ Motivation (rotate, deterministic by day) ══════════════ */

const QUOTES = [
  "Consistency beats intensity.",
  "One completed task is better than ten planned tasks.",
  "Your future rank is built by today's questions.",
  "Don't chase perfect days. Build consistent ones.",
  "Backlog is a list, not a verdict.",
  "Study the plan. Trust the process.",
  "Small progress is still progress.",
  "One lecture today is one less lecture tomorrow.",
];
export function quoteOfDay(today: string, enabled: boolean): string | null {
  if (!enabled) return null;
  const idx = Math.abs([...today].reduce((s, c) => s + c.charCodeAt(0), 0)) % QUOTES.length;
  return QUOTES[idx];
}

/* ══════════════ Export / Import ══════════════ */

export async function exportUserJSON(userId: number) {
  const data = {
    exportedAt: new Date().toISOString(),
    user: await db.select().from(users).where(eq(users.id, userId)),
    settings: await db.select().from(userSettings).where(eq(userSettings.userId, userId)),
    batch: await db.select().from(batches).where(eq(batches.userId, userId)),
    subjects: await db.select().from(subjects),
    chapters: await db.select().from(chapters),
    lectures: await db.select().from(lectures),
    practice: await db.select().from(practiceItems),
    revisions: await db.select().from(revisionEvents),
    tests: await db.select().from(tests).where(eq(tests.userId, userId)),
    plans: await db.select().from(planTasks).where(eq(planTasks.userId, userId)),
    metrics: await db.select().from(dailyMetrics).where(eq(dailyMetrics.userId, userId)),
    goalsRow: await db.select().from(goals).where(eq(goals.userId, userId)),
    checkins: await db.select().from(checkins).where(eq(checkins.userId, userId)),
    sessions: await db.select().from(studySessions).where(eq(studySessions.userId, userId)),
    errors: await db.select().from(errorBook).where(eq(errorBook.userId, userId)),
    timetable: await db.select().from(timetableBlocks).where(eq(timetableBlocks.userId, userId)),
    events: await db.select().from(customEvents).where(eq(customEvents.userId, userId)),
    weakTopics: await db.select().from(weakTopics),
  };
  return data;
}

/** bulk-import progress: expects { lectures: [{id,status,watchedPct}], practice: [{id,status,solved}] } */
export async function importProgressJSON(userId: number, payload: string): Promise<{ ok: boolean; message: string }> {
  try {
    const data = JSON.parse(payload);
    let lec = 0, pr = 0;
    if (Array.isArray(data.lectures)) {
      for (const l of data.lectures) {
        if (typeof l.id !== "number") continue;
        await db.update(lectures).set({
          status: l.status === "completed" ? "completed" : l.status === "partial" ? "partial" : "pending",
          watchedPct: clamp(Number(l.watchedPct) || (l.status === "completed" ? 100 : 0), 0, 100),
          completedAt: l.status === "completed" ? new Date() : null,
        }).where(eq(lectures.id, l.id));
        lec++;
      }
    }
    if (Array.isArray(data.practice)) {
      for (const p of data.practice) {
        if (typeof p.id !== "number") continue;
        await db.update(practiceItems).set({
          status: typeof p.status === "string" ? p.status : "in_progress",
          solved: clamp(Number(p.solved) || 0, 0, 100000),
        }).where(eq(practiceItems.id, p.id));
        pr++;
      }
    }
    return { ok: true, message: `Imported ${lec} lecture updates and ${pr} practice updates. Source tagged: imported.` };
  } catch (e) {
    return { ok: false, message: `Import failed: ${(e as Error).message}. Nothing was partially imported for invalid rows.` };
  }
}
