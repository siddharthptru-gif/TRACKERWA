"use server";

import { db } from "@/db";
import {
  users, lectures, chapters, practiceItems, revisionEvents, tests,
  planTasks, goals, dailyMetrics, userSettings, timetableBlocks,
  customEvents, studySessions, errorBook, announcements, aiMessages,
} from "@/db/schema";
import { eq, and, gte } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import {
  getUser, getContext, todayStr, addDays, generatePlan, clamp,
} from "@/lib/engine";
import { backlogKiller, exportUserJSON, importProgressJSON } from "@/lib/ops";

const refresh = () => revalidatePath("/", "layout");

/* ──────────────── lecture progress (partial % support) ──────────────── */

export async function updateLectureProgress(lectureId: number, pct: number) {
  const p = clamp(Math.round(pct), 0, 100);
  const [lec] = await db.select().from(lectures).where(eq(lectures.id, lectureId));
  if (!lec) return;
  const status = p >= 95 ? "completed" : p > 0 ? "partial" : "pending";
  await db.update(lectures).set({
    watchedPct: p,
    watchedMin: Math.round((p / 100) * lec.durationMin),
    status,
    completedAt: p >= 95 ? new Date() : null,
  }).where(eq(lectures.id, lectureId));

  if (p >= 95) {
    // maybe the chapter is now complete → revision cycle
    const all = await db.select().from(lectures).where(eq(lectures.chapterId, lec.chapterId));
    const ch = (await db.select().from(chapters).where(eq(chapters.id, lec.chapterId)))[0];
    if (ch && ch.status === "not_started") {
      await db.update(chapters).set({ status: "in_progress", startedAt: todayStr() }).where(eq(chapters.id, ch.id));
    }
    if (ch && all.every((l) => l.status === "completed" || l.id === lectureId)) {
      const today = todayStr();
      const existing = await db.select().from(revisionEvents).where(eq(revisionEvents.chapterId, ch.id));
      await db.update(chapters).set({ status: "completed", completedAt: today, notesDone: true, mastery: clamp(ch.mastery + 10, 0, 100) }).where(eq(chapters.id, ch.id));
      if (!existing.some((r) => r.status !== "completed")) {
        const user = await getUser();
        const settings = user
          ? (await db.select().from(userSettings).where(eq(userSettings.userId, user.id)))?.[0]
          : null;
        const csv = settings?.revisionIntervals ?? "1,3,7,15,30,60";
        const intervals = csv.split(",").map((x) => Math.max(1, Math.round(parseFloat(x) || 1)));
        let d = today;
        for (let stage = 1; stage <= intervals.length; stage++) {
          d = addDays(d, intervals[stage - 1]);
          await db.insert(revisionEvents).values({ chapterId: ch.id, stage, dueDate: d, status: "scheduled" });
        }
      }
    }
  }
  refresh();
}

/* ──────────────── chapter prep override ──────────────── */

export async function setChapterOverride(chapterId: number, pct: number | null, level: string | null) {
  await db.update(chapters).set({
    prepOverride: pct == null ? null : clamp(Math.round(pct), 0, 100),
    manualLevel: level,
  }).where(eq(chapters.id, chapterId));
  refresh();
}

/* ──────────────── practice counts (honest partials) ──────────────── */

export async function updatePracticeCounts(itemId: number, patch: { solved?: number; correct?: number; incorrect?: number }) {
  const [item] = await db.select().from(practiceItems).where(eq(practiceItems.id, itemId));
  if (!item) return;
  const solved = clamp(Math.round(patch.solved ?? item.solved), 0, item.totalQuestions);
  const correct = patch.correct != null ? clamp(Math.round(patch.correct), 0, solved) : item.correct;
  const incorrect = patch.incorrect != null ? clamp(Math.round(patch.incorrect), 0, solved) : item.incorrect;
  const accuracy = correct != null && solved > 0 ? Math.round((correct / solved) * 100) : item.accuracy;
  const status = solved >= item.totalQuestions ? "completed" : solved > 0 ? (accuracy != null && accuracy < 50 ? "weak" : "in_progress") : "not_started";
  await db.update(practiceItems).set({ solved, correct, incorrect, accuracy, status, updatedAt: new Date() })
    .where(eq(practiceItems.id, itemId));
  refresh();
}

/* ──────────────── test analysis ──────────────── */

export async function logTestFull(testId: number, f: {
  marks: number; attempted?: number; correct?: number; incorrect?: number; unattempted?: number;
  conceptual?: number; calculation?: number; silly?: number; time?: number;
}) {
  const [t] = await db.select().from(tests).where(eq(tests.id, testId));
  if (!t) return;
  const phy = Math.round(f.marks * 0.36);
  const chem = Math.round(f.marks * 0.34);
  await db.update(tests).set({
    status: "attempted", attemptedAt: new Date(), obtainedMarks: f.marks,
    physicsMarks: phy, chemistryMarks: chem, mathsMarks: f.marks - phy - chem,
    qAttempted: f.attempted ?? null, qCorrect: f.correct ?? null,
    qIncorrect: f.incorrect ?? null, qUnattempted: f.unattempted ?? null,
    mConceptual: f.conceptual ?? null, mCalculation: f.calculation ?? null,
    mSilly: f.silly ?? null, mTime: f.time ?? null,
  }).where(eq(tests.id, testId));
  refresh();
}

/* ──────────────── task editing: postpone / split / resize / delete ──────────────── */

export async function postponeTask(taskId: number, days: number) {
  const [t] = await db.select().from(planTasks).where(eq(planTasks.id, taskId));
  if (!t) return;
  await db.update(planTasks).set({
    date: addDays(t.date, clamp(days, 1, 7)),
    reason: `Postponed by you · ${t.reason}`,
  }).where(eq(planTasks.id, taskId));
  refresh();
}

export async function splitTask(taskId: number) {
  const [t] = await db.select().from(planTasks).where(eq(planTasks.id, taskId));
  if (!t || t.estMin < 30) return;
  const half = Math.floor(t.estMin / 2);
  await db.update(planTasks).set({
    estMin: half, title: `${t.title} (part 1)`, reason: `Split task · part 1 of 2 · ${t.reason}`,
  }).where(eq(planTasks.id, taskId));
  await db.insert(planTasks).values({
    userId: t.userId, date: addDays(t.date, 1), title: `${t.title} (part 2)`,
    kind: t.kind, refType: t.refType, refId: t.refId, subjectId: t.subjectId,
    estMin: t.estMin - half, priority: t.priority - 2,
    reason: `Split task · part 2 of 2 · auto-placed tomorrow`, position: t.position + 1,
    source: "manual",
  });
  refresh();
}

export async function resizeTask(taskId: number, estMin: number) {
  await db.update(planTasks).set({ estMin: clamp(Math.round(estMin), 10, 600) }).where(eq(planTasks.id, taskId));
  refresh();
}

export async function deleteTask(taskId: number) {
  await db.delete(planTasks).where(eq(planTasks.id, taskId));
  refresh();
}

/* ──────────────── capacity / replan ──────────────── */

export async function setAvailableToday(minutes: number) {
  const user = await getUser();
  if (!user) return "";
  const today = todayStr();
  const existing = await db.select().from(customEvents)
    .where(and(eq(customEvents.userId, user.id), eq(customEvents.date, today)));
  const capEv = existing.find((e) => e.kind === "custom");
  if (capEv) {
    await db.update(customEvents).set({ availableMinutes: minutes }).where(eq(customEvents.id, capEv.id));
  } else {
    await db.insert(customEvents).values({
      userId: user.id, date: today, label: "Adjusted availability", kind: "custom", availableMinutes: minutes,
    });
  }
  await generatePlan(user.id, today);
  refresh();
  return `Re-planned around ${Math.floor(minutes / 60)}h ${minutes % 60}m — running classes, due revisions and test prep were protected first.`;
}

export async function planMyDay() {
  const user = await getUser();
  if (!user) return;
  await generatePlan(user.id, todayStr());
  refresh();
}

/* ──────────────── backlog killer ──────────────── */

export async function applyKillerPlanAction(days: number, mode: "safe" | "balanced" | "aggressive") {
  const user = await getUser();
  if (!user) return;
  const ctx = await getContext(user.id);
  const kp = backlogKiller(ctx, todayStr(), days, mode);
  for (const [di, row] of kp.rows.entries()) {
    for (const [ii, it] of row.items.entries()) {
      await db.insert(planTasks).values({
        userId: user.id, date: row.date, title: it.title, kind: it.kind === "backlog" ? "backlog" : it.kind,
        refType: it.refType, refId: it.refId, subjectId: it.subjectId,
        estMin: it.minutes, priority: 56 - di,
        status: "pending",
        reason: `Backlog Killer · ${mode} mode · day ${di + 1} of ${kp.rows.length} · current batch still protected`,
        position: 40 + ii, source: "killer",
      });
    }
  }
  refresh();
}

/* ──────────────── study promise + sessions ──────────────── */

export async function togglePromise(taskId: number) {
  const [t] = await db.select().from(planTasks).where(eq(planTasks.id, taskId));
  if (!t) return;
  await db.update(planTasks).set({ promised: !t.promised }).where(eq(planTasks.id, taskId));
  refresh();
}

export async function startSession(taskId: number) {
  const user = await getUser();
  if (!user) return 0;
  const [row] = await db.insert(studySessions).values({
    userId: user.id, date: todayStr(), taskId, startedAt: new Date(), kind: "task", minutes: 0,
  }).returning();
  return row.id;
}

export async function finishSession(sessionId: number, payload: {
  minutes: number; outcome: "completed" | "partial" | "not"; pct?: number;
}) {
  const user = await getUser();
  if (!user) return;
  const [s] = await db.select().from(studySessions).where(eq(studySessions.id, sessionId));
  if (!s) return;
  await db.update(studySessions).set({ minutes: Math.max(0, Math.round(payload.minutes)), endedAt: new Date() })
    .where(eq(studySessions.id, sessionId));

  // metric bump
  const today = todayStr();
  const [metric] = await db.select().from(dailyMetrics)
    .where(and(eq(dailyMetrics.userId, user.id), eq(dailyMetrics.date, today)));
  if (metric) {
    await db.update(dailyMetrics).set({ studyMin: metric.studyMin + Math.round(payload.minutes) })
      .where(eq(dailyMetrics.id, metric.id));
  } else {
    await db.insert(dailyMetrics).values({ userId: user.id, date: today, studyMin: Math.round(payload.minutes) });
  }

  if (s.taskId) {
    const [task] = await db.select().from(planTasks).where(eq(planTasks.id, s.taskId));
    if (task) {
      if (payload.outcome === "completed") {
        await db.update(planTasks).set({ status: "done" }).where(eq(planTasks.id, task.id));
        if (task.refType === "lecture" && task.refId) await updateLectureProgress(task.refId, 100);
        else if (task.refType === "practice" && task.refId) {
          const [p] = await db.select().from(practiceItems).where(eq(practiceItems.id, task.refId));
          if (p) await updatePracticeCounts(p.id, { solved: p.totalQuestions });
        } else if (task.refType === "revision" && task.refId) {
          const { completeRevisionAction } = await import("@/lib/actions");
          await completeRevisionAction(task.refId, 75);
        }
      } else if (payload.outcome === "partial") {
        const pct = clamp(payload.pct ?? 50, 5, 95);
        await db.update(planTasks).set({
          title: `${task.title} (${pct}% done)`,
          estMin: Math.max(10, Math.round(task.estMin * (1 - pct / 100))),
          reason: `Partially completed (${pct}%) · remaining auto-resized`,
        }).where(eq(planTasks.id, task.id));
        if (task.refType === "lecture" && task.refId) {
          const [lec] = await db.select().from(lectures).where(eq(lectures.id, task.refId));
          if (lec) await updateLectureProgress(lec.id, Math.min(95, lec.watchedPct + pct * (1 - lec.watchedPct / 100)));
        }
      }
    }
  }
  refresh();
}

/* ──────────────── timetable & events ──────────────── */

export async function saveTimetableBlocks(blocks: {
  id?: number; dayOfWeek: number; startMin: number; endMin: number;
  kind: string; label: string; fixed: boolean; focus?: string;
}[]) {
  const user = await getUser();
  if (!user) return "Not signed in";
  // validation: sane ranges, no overlaps inside a scope (dayOfWeek)
  const clean = blocks
    .filter((b) => b.endMin > b.startMin && b.startMin >= 0 && b.endMin <= 1440)
    .map((b) => ({ ...b, startMin: Math.round(b.startMin), endMin: Math.round(b.endMin) }));
  for (const scope of new Set(clean.map((b) => b.dayOfWeek))) {
    const scoped = clean.filter((b) => b.dayOfWeek === scope).sort((a, b) => a.startMin - b.startMin);
    for (let i = 1; i < scoped.length; i++) {
      if (scoped[i].startMin < scoped[i - 1].endMin) {
        return `Overlap detected: "${scoped[i - 1].label}" and "${scoped[i].label}" — fixed blocks can never overlap.`;
      }
    }
  }
  await db.delete(timetableBlocks).where(eq(timetableBlocks.userId, user.id));
  for (const b of clean) {
    await db.insert(timetableBlocks).values({
      userId: user.id, dayOfWeek: b.dayOfWeek, startMin: b.startMin, endMin: b.endMin,
      kind: b.kind, label: b.label, fixed: b.fixed, focus: b.focus ?? "any",
    });
  }
  refresh();
  return "Timetable saved — planner availability recalculated around your fixed blocks.";
}

export async function addCustomEvent(f: { date: string; label: string; kind: string; availableMinutes: number }) {
  const user = await getUser();
  if (!user) return;
  await db.insert(customEvents).values({
    userId: user.id, date: f.date, label: f.label, kind: f.kind,
    availableMinutes: clamp(Math.round(f.availableMinutes), 0, 1440),
  });
  refresh();
}

export async function deleteCustomEvent(id: number) {
  await db.delete(customEvents).where(eq(customEvents.id, id));
  refresh();
}

/* ──────────────── settings ──────────────── */

export async function saveSettings(patch: {
  planningMode?: string; planningStyle?: string; playbackSpeed?: number;
  motivation?: boolean; revisionIntervals?: string; weeklyMinutes?: string;
  priorityOrder?: string; paceLectures?: number; paceQuestions?: number;
  paceRevisions?: number; paceBacklog?: number; studentType?: string;
}) {
  const user = await getUser();
  if (!user) return;
  const existing = await db.select().from(userSettings).where(eq(userSettings.userId, user.id));
  const { studentType, ...settingsPatch } = patch;
  if (existing.length) {
    await db.update(userSettings).set(settingsPatch).where(eq(userSettings.id, existing[0].id));
  } else {
    await db.insert(userSettings).values({ userId: user.id, ...settingsPatch });
  }
  if (studentType) {
    await db.update(users).set({ studentType }).where(eq(users.id, user.id));
  }
  refresh();
}

/* ──────────────── error book ──────────────── */

export async function addErrorEntry(f: {
  question: string; subjectId?: number | null; chapterId?: number | null;
  mistakeType: string; correctConcept?: string; reattemptDate?: string;
}) {
  const user = await getUser();
  if (!user) return;
  await db.insert(errorBook).values({
    userId: user.id, question: f.question,
    subjectId: f.subjectId ?? null, chapterId: f.chapterId ?? null,
    mistakeType: f.mistakeType, correctConcept: f.correctConcept ?? null,
    reattemptDate: f.reattemptDate ?? null,
    status: f.reattemptDate ? "reattempt_scheduled" : "open",
  });
  refresh();
}

export async function cycleErrorStatus(id: number) {
  const [e] = await db.select().from(errorBook).where(eq(errorBook.id, id));
  if (!e) return;
  const next = e.status === "open" ? "reattempt_scheduled" : e.status === "reattempt_scheduled" ? "mastered" : "open";
  await db.update(errorBook).set({
    status: next,
    reattemptDate: next === "reattempt_scheduled" ? addDays(todayStr(), 3) : e.reattemptDate,
  }).where(eq(errorBook.id, id));
  refresh();
}

/* ──────────────── import / export / resets / admin ──────────────── */

export async function exportDataAction(): Promise<string> {
  const user = await getUser();
  if (!user) return "{}";
  const data = await exportUserJSON(user.id);
  return JSON.stringify(data, null, 2);
}

export async function importDataAction(payload: string) {
  const user = await getUser();
  if (!user) return "Not signed in";
  const res = await importProgressJSON(user.id, payload);
  refresh();
  return res.message;
}

export async function resetTodayPlan() {
  const user = await getUser();
  if (!user) return;
  const today = todayStr();
  const rows = await db.select().from(planTasks)
    .where(and(eq(planTasks.userId, user.id), eq(planTasks.date, today), eq(planTasks.status, "pending")));
  for (const r of rows) await db.delete(planTasks).where(eq(planTasks.id, r.id));
  await generatePlan(user.id, today);
  refresh();
}

export async function resetPlanner() {
  const user = await getUser();
  if (!user) return;
  const rows = await db.select().from(planTasks)
    .where(and(eq(planTasks.userId, user.id), gte(planTasks.date, todayStr()), eq(planTasks.status, "pending")));
  for (const r of rows) await db.delete(planTasks).where(eq(planTasks.id, r.id));
  await generatePlan(user.id, todayStr());
  refresh();
}

export async function resetProgress() {
  const user = await getUser();
  if (!user) return;
  await db.update(lectures).set({ status: "pending", watchedPct: 0, watchedMin: 0, completedAt: null });
  await db.update(practiceItems).set({ status: "not_started", solved: 0, correct: null, incorrect: null, accuracy: null });
  await db.update(chapters).set({ status: "not_started", startedAt: null, completedAt: null, mastery: 0, prepOverride: null, manualLevel: null, isCurrent: false });
  await db.delete(revisionEvents);
  await db.delete(planTasks);
  await generatePlan(user.id, todayStr());
  refresh();
}

export async function saveAnnouncement(text: string) {
  const trimmed = text.trim();
  if (!trimmed) return;
  await db.insert(announcements).values({ text: trimmed });
  refresh();
}

export async function clearAssistantHistory() {
  const user = await getUser();
  if (!user) return;
  await db.delete(aiMessages).where(eq(aiMessages.userId, user.id));
  refresh();
}
