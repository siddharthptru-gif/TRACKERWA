import { db } from "@/db";
import {
  users, batches, subjects, chapters, lectures, practiceItems,
  revisionEvents, tests, planTasks, goals, dailyMetrics, weakTopics,
  checkins, aiMessages, userSettings, timetableBlocks, customEvents,
  errorBook, announcements, teachers,
} from "@/db/schema";
import { eq, and, lt, lte } from "drizzle-orm";

/* ══════════════════════════ date utilities ══════════════════════════ */

export function todayStr(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
    d.getDate()
  ).padStart(2, "0")}`;
}

export function addDays(dateStr: string, n: number): string {
  const d = new Date(dateStr + "T00:00:00");
  d.setDate(d.getDate() + n);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
    d.getDate()
  ).padStart(2, "0")}`;
}

export function diffDays(a: string, b: string): number {
  return Math.round(
    (new Date(a + "T00:00:00").getTime() - new Date(b + "T00:00:00").getTime()) /
      86400000
  );
}

export const fmtMin = (m: number) =>
  m >= 60 ? `${Math.floor(m / 60)}h ${m % 60 ? `${m % 60}m` : ""}`.trim() : `${m}m`;

export const fmtDate = (d: string) =>
  new Date(d + "T00:00:00").toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
  });

export const fmtDateFull = (d: string) =>
  new Date(d + "T00:00:00").toLocaleDateString("en-IN", {
    weekday: "long",
    day: "numeric",
    month: "long",
  });

export const dayName = (d: string) =>
  new Date(d + "T00:00:00").toLocaleDateString("en-IN", { weekday: "long" });

export const clamp = (v: number, lo: number, hi: number) =>
  Math.min(hi, Math.max(lo, v));

/* ══════════════════════════ core loaders ══════════════════════════ */

export async function getUser() {
  const all = await db.select().from(users);
  return all[0] ?? null;
}

export async function getContext(userId: number) {
  const [
    u, batchRows, subjectRows, chapterRows, lectureRows,
    practiceRows, revisionRows, testRows, goalRows, metricRows,
    weakRows, checkinRows, settingRows, blockRows, eventRows,
    errorRows, announcementRows, teacherRows,
  ] = await Promise.all([
    db.select().from(users).where(eq(users.id, userId)),
    db.select().from(batches).where(eq(batches.userId, userId)),
    db.select().from(subjects),
    db.select().from(chapters),
    db.select().from(lectures),
    db.select().from(practiceItems),
    db.select().from(revisionEvents),
    db.select().from(tests).where(eq(tests.userId, userId)),
    db.select().from(goals).where(eq(goals.userId, userId)),
    db.select().from(dailyMetrics).where(eq(dailyMetrics.userId, userId)),
    db.select().from(weakTopics),
    db.select().from(checkins).where(eq(checkins.userId, userId)),
    db.select().from(userSettings).where(eq(userSettings.userId, userId)),
    db.select().from(timetableBlocks).where(eq(timetableBlocks.userId, userId)),
    db.select().from(customEvents).where(eq(customEvents.userId, userId)),
    db.select().from(errorBook).where(eq(errorBook.userId, userId)),
    db.select().from(announcements),
    db.select().from(teachers),
  ]);
  const settings = settingRows[0] ?? null;
  return {
    user: u[0],
    batch: batchRows[0] ?? null,
    subjects: subjectRows.sort((a, b) => a.position - b.position),
    chapters: chapterRows,
    lectures: lectureRows,
    practice: practiceRows,
    revisions: revisionRows,
    tests: testRows,
    goals: goalRows[0] ?? null,
    metrics: metricRows.sort((a, b) => (a.date < b.date ? -1 : 1)),
    weakTopics: weakRows,
    checkins: checkinRows,
    settings,
    blocks: blockRows,
    events: eventRows,
    errorBook: errorRows,
    announcements: announcementRows.sort(
      (a, b) => (b.updatedAt?.getTime() ?? 0) - (a.updatedAt?.getTime() ?? 0)
    ),
    teachers: teacherRows,
    playbackSpeed: settings?.playbackSpeed ?? 1.5,
    revisionIntervals: parseIntervals(settings?.revisionIntervals),
  };
}

export function parseIntervals(csv?: string | null): number[] {
  const arr = (csv ?? "1,3,7,15,30,60")
    .split(",")
    .map((x) => parseFloat(x))
    .filter((x) => Number.isFinite(x) && x > 0)
    .map((x) => Math.max(1, Math.round(x)));
  return arr.length ? arr : [1, 3, 7, 15, 30, 60];
}

/** study minutes available on a date: weekly schedule → event override → safety floor */
export function availableMinutesFor(ctx: Ctx, date: string): number {
  const dow = new Date(date + "T00:00:00").getDay();
  let base = ctx.user.dailyMinutes;
  try {
    const wm = JSON.parse(ctx.settings?.weeklyMinutes ?? "{}") as Record<string, number>;
    if (typeof wm[String(dow)] === "number") base = wm[String(dow)];
  } catch { /* keep default */ }
  const ev = ctx.events.find((e) => e.date === date);
  if (ev) base = Math.min(base, ev.availableMinutes);
  return Math.max(0, Math.round(base * ctx.user.adaptiveLoad));
}

/** lecture viewing minutes at the student's preferred playback speed */
export const viewMin = (durMin: number, speed: number) =>
  Math.ceil(durMin / Math.max(0.5, speed || 1));
export type Ctx = Awaited<ReturnType<typeof getContext>>;

export const chapterLectures = (ctx: Ctx, chapterId: number) =>
  ctx.lectures
    .filter((l) => l.chapterId === chapterId)
    .sort((a, b) => a.position - b.position);

export const chapterPractice = (ctx: Ctx, chapterId: number) =>
  ctx.practice.filter((p) => p.chapterId === chapterId);

export function lectureProgress(ctx: Ctx, chapterId: number) {
  const ls = chapterLectures(ctx, chapterId);
  const done = ls.filter((l) => l.status === "completed").length;
  return { done, total: ls.length, pct: ls.length ? Math.round((done / ls.length) * 100) : 0 };
}

/* ══════════════════════════ backlog ══════════════════════════ */

export function backlogItems(ctx: Ctx, today: string) {
  return ctx.lectures.filter((l) => {
    if (l.status === "completed") return false;
    const ch = ctx.chapters.find((c) => c.id === l.chapterId);
    if (!ch) return false;
    if (ch.isCurrent) return false; // running classes are not backlog
    if (ch.status === "not_started") return false; // not taught yet
    return !l.taughtAt || l.taughtAt < today;
  });
}

export function backlogPlan(ctx: Ctx, fromDate: string) {
  const items = backlogItems(ctx, fromDate).sort((a, b) =>
    (a.taughtAt ?? "") < (b.taughtAt ?? "") ? -1 : 1
  );
  const speed = ctx.playbackSpeed;
  const totalMin = items.reduce(
    (s, l) => s + viewMin(Math.ceil(l.durationMin * (1 - (l.watchedPct ?? 0) / 100)), speed), 0
  );
  const currentChapters = ctx.chapters.filter((c) => c.isCurrent).length;
  const reserve =
    currentChapters * 80 + // keep pace with running classes (speed-adjusted)
    45 + // revision load
    60; // question practice load
  const dailyBudget = Math.max(90, ctx.user.dailyMinutes - reserve);
  const paceCap = Math.max(1, ctx.settings?.paceBacklog ?? 3);
  const perDay = clamp(Math.round(dailyBudget / 75), 1, paceCap);

  const days: { date: string; items: typeof items }[] = [];
  items.forEach((item, i) => {
    const d = Math.floor(i / perDay);
    if (!days[d]) days[d] = { date: addDays(fromDate, d), items: [] };
    days[d].items.push(item);
  });
  return {
    items,
    totalMin,
    perDay,
    dailyBudget,
    daysNeeded: Math.ceil(items.length / Math.max(1, perDay)),
    days,
    currentProtected: currentChapters * 90,
  };
}

/* ══════════════════════════ stats ══════════════════════════ */

export function completionStats(ctx: Ctx) {
  const totalLec = ctx.lectures.length;
  const doneLec = ctx.lectures.filter((l) => l.status === "completed").length;
  const revs = ctx.revisions;
  const doneRevs = revs.filter((r) => r.status === "completed").length;
  const practice = ctx.practice;
  const donePractice = practice.filter((p) => p.status === "completed").length;
  const attempted = ctx.tests.filter((t) => t.status === "attempted");
  const accItems = practice.filter((p) => p.accuracy != null);
  const avgAcc = accItems.length
    ? Math.round(accItems.reduce((s, p) => s + (p.accuracy ?? 0), 0) / accItems.length)
    : 0;
  const lecturePct = totalLec ? Math.round((doneLec / totalLec) * 100) : 0;
  const revisionPct = revs.length ? Math.round((doneRevs / revs.length) * 100) : 0;
  const practicePct = practice.length ? Math.round((donePractice / practice.length) * 100) : 0;
  const readiness = Math.round(
    0.4 * lecturePct + 0.25 * revisionPct + 0.25 * practicePct + 0.1 * (avgAcc / 1)
  );
  return {
    lecturePct, revisionPct, practicePct, avgAcc, readiness,
    doneLec, totalLec, doneRevs, totalRevs: revs.length,
    donePractice, totalPractice: practice.length,
    attemptedTests: attempted.length,
  };
}

export function subjectStats(ctx: Ctx, today: string) {
  return ctx.subjects.map((s) => {
    const chs = ctx.chapters.filter((c) => c.subjectId === s.id);
    const completed = chs.filter((c) => c.status === "completed").length;
    const current = chs.find((c) => c.isCurrent) ?? null;
    const lecs = ctx.lectures.filter((l) => chs.some((c) => c.id === l.chapterId));
    const doneLecs = lecs.filter((l) => l.status === "completed").length;
    const bl = ctx.lectures.filter((l) => {
      if (l.status === "completed") return false;
      const ch = chs.find((c) => c.id === l.chapterId);
      return ch && !ch.isCurrent && ch.status !== "not_started" && (!l.taughtAt || l.taughtAt < today);
    }).length;
    const weak = chs.filter(
      (c) => c.mastery > 0 && c.mastery < 55
    );
    const strong = chs.filter((c) => c.mastery >= 78);
    const masteryVals = chs.filter((c) => c.mastery > 0);
    const avgMastery = masteryVals.length
      ? Math.round(masteryVals.reduce((a, c) => a + c.mastery, 0) / masteryVals.length)
      : 0;
    return {
      ...s,
      chapters: chs,
      completed,
      total: chs.length,
      current,
      lecturePct: lecs.length ? Math.round((doneLecs / lecs.length) * 100) : 0,
      backlog: bl,
      weak,
      strong,
      avgMastery,
    };
  });
}

export function streak(ctx: Ctx, today: string) {
  const map = new Map(ctx.metrics.map((m) => [m.date, m.studyMin]));
  let count = 0;
  let cursor = today;
  // today may not be logged yet — don't break streak because of it
  if ((map.get(cursor) ?? 0) === 0) cursor = addDays(cursor, -1);
  while ((map.get(cursor) ?? 0) > 0) {
    count++;
    cursor = addDays(cursor, -1);
  }
  return count;
}

/* ══════════════════════════ the planner ══════════════════════════ */

type Candidate = {
  title: string;
  kind: string;
  refType?: string;
  refId?: number;
  subjectId?: number;
  estMin: number;
  priority: number;
  reason: string;
};

export async function candidatesFor(ctx: Ctx, date: string): Promise<Candidate[]> {
  const cands: Candidate[] = [];
  const dayDiff = (d: string) => diffDays(d, date);

  // 1. Tests — test day attempt / prep within 3 days
  for (const t of ctx.tests) {
    if (t.status !== "scheduled") continue;
    const dd = dayDiff(t.scheduledAt);
    if (dd === 0) {
      cands.push({
        title: `Attempt: ${t.title}`,
        kind: "test", refType: "test", refId: t.id,
        estMin: 180, priority: 100,
        reason: `Scheduled test today · ${t.totalMarks} marks`,
      });
    } else if (dd > 0 && dd <= 3) {
      cands.push({
        title: `Test prep: ${t.title}`,
        kind: "test_prep", refType: "test", refId: t.id,
        estMin: 75, priority: 90,
        reason: `${t.title} in ${dd} day${dd > 1 ? "s" : ""} — formula sheet + PYQ mix`,
      });
    }
  }

  // 2. Running chapters — the very next pending/partial lecture each
  for (const ch of ctx.chapters.filter((c) => c.isCurrent)) {
    const next = chapterLectures(ctx, ch.id).find((l) => l.status !== "completed");
    if (!next) continue;
    const remaining = Math.ceil(next.durationMin * (1 - (next.watchedPct ?? 0) / 100));
    const est = viewMin(remaining, ctx.playbackSpeed);
    const subject = ctx.subjects.find((s) => s.id === ch.subjectId);
    cands.push({
      title: next.watchedPct > 0 ? `${next.title} (resume ${Math.round(next.watchedPct)}%)` : next.title,
      kind: "lecture", refType: "lecture", refId: next.id, subjectId: ch.subjectId,
      estMin: est,
      priority: next.taughtAt && next.taughtAt >= date ? 97 : 94,
      reason:
        next.watchedPct > 0
          ? `Partially watched (${Math.round(next.watchedPct)}%) · ${fmtMin(est)} left at ${ctx.playbackSpeed}x`
          : next.taughtAt && next.taughtAt >= date
            ? `Today's class in ${ch.name} · running in batch · ${ctx.playbackSpeed}x speed`
            : `Running chapter · ${subject?.name ?? ""} class pace`,
    });
  }

  // 3. Revisions due / overdue (spaced repetition)
  for (const r of ctx.revisions) {
    if (r.status === "completed" || r.status === "skipped") continue;
    if (r.dueDate > date) continue;
    const ch = ctx.chapters.find((c) => c.id === r.chapterId);
    if (!ch) continue;
    const overdue = Math.max(0, diffDays(date, r.dueDate));
    cands.push({
      title: `Revision ${r.stage}: ${ch.name}`,
      kind: "revision", refType: "revision", refId: r.id, subjectId: ch.subjectId,
      estMin: 45,
      priority: overdue > 0 ? 88 : 78 - r.stage,
      reason: overdue > 0
        ? `Overdue by ${overdue} day${overdue > 1 ? "s" : ""} · spaced stage R${r.stage}`
        : `Spaced revision due today · stage R${r.stage} of 5`,
    });
  }

  // 4. Overdue / pending DPPs of completed chapters
  for (const p of ctx.practice) {
    if (p.type !== "dpp") continue;
    if (p.status === "completed") continue;
    const ch = ctx.chapters.find((c) => c.id === p.chapterId);
    if (!ch || ch.status !== "completed") continue;
    const daysSince = ch.completedAt ? Math.max(0, diffDays(date, ch.completedAt)) : 0;
    const overdue = daysSince >= 3;
    if (daysSince < 1) continue;
    cands.push({
      title: `DPP · ${ch.name} (${p.solved}/${p.totalQuestions}q)`,
      kind: "dpp", refType: "practice", refId: p.id, subjectId: ch.subjectId,
      estMin: 55,
      priority: overdue ? 80 : 58,
      reason: overdue
        ? `Overdue DPP · chapter completed ${daysSince} days ago`
        : p.status === "in_progress"
          ? `In progress · ${p.totalQuestions - p.solved} questions left`
          : `DPP for recently completed chapter`,
    });
  }

  // 5. Daily backlog dose — oldest first, never displacing running classes
  const bp = backlogPlan(ctx, date);
  const dose = Math.min(bp.perDay, 2 + (bp.items.length > 18 ? 1 : 0));
  backlogItems(ctx, date)
    .sort((a, b) => ((a.taughtAt ?? "") < (b.taughtAt ?? "") ? -1 : 1))
    .slice(0, dose)
    .forEach((l) => {
      const ch = ctx.chapters.find((c) => c.id === l.chapterId)!;
      const age = l.taughtAt ? Math.max(0, diffDays(date, l.taughtAt)) : 14;
      const remaining = Math.ceil(l.durationMin * (1 - (l.watchedPct ?? 0) / 100));
      cands.push({
        title: l.title,
        kind: "backlog", refType: "lecture", refId: l.id, subjectId: ch.subjectId,
        estMin: viewMin(remaining, ctx.playbackSpeed),
        priority: 36 + clamp(age, 0, 26),
        reason: `Backlog · taught ${age} days ago · ${ch.name}${l.watchedPct > 0 ? ` · resumes at ${Math.round(l.watchedPct)}%` : ""}`,
      });
    });

  // 6. Weak-topic drills
  ctx.weakTopics
    .filter((w) => !w.resolvedAt)
    .slice(0, 2)
    .forEach((w) => {
      const ch = ctx.chapters.find((c) => c.id === w.chapterId);
      if (!ch) return;
      cands.push({
        title: `Weak-topic drill: ${w.topic}`,
        kind: "weak_topic", refType: "chapter", refId: ch.id, subjectId: ch.subjectId,
        estMin: 40,
        priority: 44 + w.severity * 4,
        reason: `Flagged weak (${w.source}) in ${ch.name}`,
      });
    });

  // 7. PYQ block for the most mature completed chapter with pending PYQs
  const pyq = ctx.practice
    .filter((p) => p.type === "pyq_main" && p.status !== "completed")
    .map((p) => ({ p, ch: ctx.chapters.find((c) => c.id === p.chapterId)! }))
    .filter((x) => x.ch && x.ch.status === "completed")
    .sort((a, b) => ((a.ch.completedAt ?? "") < (b.ch.completedAt ?? "") ? -1 : 1))[0];
  if (pyq) {
    cands.push({
      title: `JEE Main PYQs · ${pyq.ch.name} (${pyq.p.solved}/${pyq.p.totalQuestions})`,
      kind: "pyq", refType: "practice", refId: pyq.p.id, subjectId: pyq.ch.subjectId,
      estMin: 45, priority: 40,
      reason: `PYQ velocity is the rank-maker · chapter done ${pyq.ch.completedAt ? fmtDate(pyq.ch.completedAt) : ""}`,
    });
  }

  // 8. Module practice for running chapter
  const runningCh = ctx.chapters.find((c) => c.isCurrent);
  if (runningCh) {
    const mod = ctx.practice.find(
      (p) => p.chapterId === runningCh.id && p.type === "module" && p.status !== "completed"
    );
    if (mod) {
      cands.push({
        title: `Module · ${runningCh.name} (${mod.solved}/${mod.totalQuestions}q)`,
        kind: "practice", refType: "practice", refId: mod.id, subjectId: runningCh.subjectId,
        estMin: 50, priority: 48,
        reason: `Keep practice parallel with the running chapter`,
      });
    }
  }

  // 9. Planning-style boost (user-configured emphasis)
  const style = ctx.settings?.planningStyle ?? "balanced";
  const boost: Record<string, number> =
    style === "backlog" ? { backlog: 22 }
    : style === "current" ? { lecture: 22 }
    : style === "revision" ? { revision: 22 }
    : style === "practice" ? { pyq: 14, practice: 14, weak_topic: 10 }
    : style === "exam" ? { test: 20, test_prep: 20 }
    : {};
  for (const c of cands) c.priority += boost[c.kind] ?? 0;

  return cands;
}

export async function generatePlan(userId: number, date: string) {
  const ctx = await getContext(userId);
  const cap = availableMinutesFor(ctx, date);
  const cands = (await candidatesFor(ctx, date)).sort(
    (a, b) => b.priority - a.priority || a.estMin - b.estMin
  );
  let used = 0;
  const chosen: Candidate[] = [];
  for (const c of cands) {
    const fits = used + c.estMin <= cap;
    if (fits || chosen.length === 0) {
      chosen.push(c);
      used += c.estMin;
    }
    if (used >= cap) break;
  }
  // remove previously auto-generated tasks for this date
  const existing = await db
    .select()
    .from(planTasks)
    .where(and(eq(planTasks.userId, userId), eq(planTasks.date, date)));
  for (const e of existing) {
    if (e.status === "pending") {
      await db.delete(planTasks).where(eq(planTasks.id, e.id));
    }
  }
  let pos = 0;
  for (const c of chosen) {
    await db.insert(planTasks).values({
      userId, date, title: c.title, kind: c.kind,
      refType: c.refType ?? null, refId: c.refId ?? null,
      subjectId: c.subjectId ?? null,
      estMin: c.estMin, priority: c.priority,
      reason: c.reason, position: pos++,
    });
  }
  return { chosen, used, cap };
}

export async function tasksFor(userId: number, date: string) {
  const rows = await db
    .select()
    .from(planTasks)
    .where(and(eq(planTasks.userId, userId), eq(planTasks.date, date)));
  return rows.sort((a, b) => b.priority - a.priority || a.position - b.position);
}

/** Idempotent daily entry point: backfills missed days, then ensures today's plan. */
export async function ensurePlan(userId: number) {
  const today = todayStr();
  const todays = await tasksFor(userId, today);
  if (todays.length > 0) return { regenerated: false };

  // ── missed-day recovery: redistribute instead of piling "overdue" ──
  const stale = await db
    .select()
    .from(planTasks)
    .where(and(eq(planTasks.userId, userId), lt(planTasks.date, today)));
  const missedPending = stale.filter((t) => t.status === "pending");
  if (missedPending.length > 0) {
    for (const m of missedPending) await db.delete(planTasks).where(eq(planTasks.id, m.id));
    const spreadDays = Math.max(2, Math.ceil(missedPending.length / 3));
    for (let i = 0; i < missedPending.length; i++) {
      const m = missedPending[i];
      const target = addDays(today, i % Math.min(3, spreadDays));
      await db.insert(planTasks).values({
        userId, date: target, title: m.title, kind: m.kind,
        refType: m.refType, refId: m.refId, subjectId: m.subjectId,
        estMin: m.estMin, priority: m.priority + 4,
        status: "pending",
        reason: `Recovered from a missed day · redistributed by the recovery engine`,
        position: 90 + i,
      });
    }
  }
  await generatePlan(userId, today);
  return { regenerated: true, recovered: missedPending.length };
}

/* ══════════════════════════ revision engine ══════════════════════════ */

export const REVISION_STAGES = [1, 3, 7, 15, 30, 60]; // default intervals (user-customizable)

export type RecallBand = "forgot" | "weak" | "average" | "good" | "excellent";
export const recallBand = (score: number): RecallBand =>
  score < 30 ? "forgot" : score < 50 ? "weak" : score < 70 ? "average" : score < 90 ? "good" : "excellent";

/** deterministic next-revision scheduler driven by recall feedback */
export function nextRevisionPlan(
  stage: number, score: number, intervals: number[]
): { nextStage: number; days: number } | null {
  const band = recallBand(score);
  if (band === "forgot") return { nextStage: Math.max(1, stage - 2), days: 1 };
  if (band === "weak") return { nextStage: Math.max(1, stage - 2), days: 2 };
  const nextStage = stage + 1;
  if (nextStage > intervals.length) return null;
  const base = intervals[Math.min(nextStage, intervals.length) - 1];
  const scale = band === "good" ? 1.3 : band === "excellent" ? 1.6 : 1;
  return { nextStage, days: Math.max(1, Math.round(base * scale)) };
}

export async function completeRevision(
  revisionId: number,
  ctx: Ctx,
  score: number,
  today: string
) {
  const rev = ctx.revisions.find((r) => r.id === revisionId);
  if (!rev) return;
  await db
    .update(revisionEvents)
    .set({ status: "completed", completedAt: new Date(), score, feedback: recallBand(score) })
    .where(eq(revisionEvents.id, revisionId));

  const plan = nextRevisionPlan(rev.stage, score, ctx.revisionIntervals);
  if (plan) {
    await db.insert(revisionEvents).values({
      chapterId: rev.chapterId,
      stage: plan.nextStage,
      dueDate: addDays(today, plan.days),
      status: "scheduled",
    });
  }
  // completing revisions lifts mastery a little (more for strong recall)
  const ch = ctx.chapters.find((c) => c.id === rev.chapterId);
  await db
    .update(chapters)
    .set({ mastery: clamp((ch?.mastery ?? 60) + (score >= 90 ? 6 : score < 50 ? 1 : 4), 0, 100) })
    .where(eq(chapters.id, rev.chapterId));
}

export function revisionLadder(ctx: Ctx, chapterId: number) {
  return ctx.revisions
    .filter((r) => r.chapterId === chapterId)
    .sort((a, b) => a.stage - b.stage || (a.dueDate < b.dueDate ? -1 : 1));
}

/* ══════════════════════════ next action per chapter ══════════════════════════ */

export function nextAction(ctx: Ctx, chapterId: number, today: string): string {
  const ch = ctx.chapters.find((c) => c.id === chapterId);
  if (!ch) return "—";
  const ls = chapterLectures(ctx, chapterId);
  const pendingLec = ls.find((l) => l.status !== "completed");
  if (pendingLec) return `Watch ${pendingLec.title.split("·")[0].trim()} · ${fmtMin(pendingLec.durationMin)}`;
  const rev = revisionLadder(ctx, chapterId).find(
    (r) => r.status !== "completed" && r.dueDate <= today
  );
  if (rev) return `Complete Revision ${rev.stage} · due ${fmtDate(rev.dueDate)}`;
  const dpp = ctx.practice.find(
    (p) => p.chapterId === chapterId && p.type === "dpp" && p.status !== "completed"
  );
  if (dpp) return `Finish DPP · ${dpp.totalQuestions - dpp.solved} questions left`;
  const pyq = ctx.practice.find(
    (p) => p.chapterId === chapterId && p.type === "pyq_main" && p.status !== "completed"
  );
  if (pyq) return `Solve JEE Main PYQs · ${pyq.solved}/${pyq.totalQuestions}`;
  if (!ch.notesDone) return "Consolidate short notes + formula sheet";
  return "Maintain via spaced revisions — scheduled";
}

/* ══════════════════════════ insights ══════════════════════════ */

export type Insight = { text: string; tone: "good" | "warn" | "bad" | "info" };

export function generateInsights(ctx: Ctx, today: string): Insight[] {
  const out: Insight[] = [];
  const m = ctx.metrics;
  const last7 = m.filter((x) => diffDays(today, x.date) < 7 && x.date <= today);
  const prev7 = m.filter((x) => {
    const d = diffDays(today, x.date);
    return d >= 7 && d < 14;
  });
  const q7 = last7.reduce((s, x) => s + x.questions, 0);
  const qPrev = prev7.reduce((s, x) => s + x.questions, 0);
  if (qPrev > 0 && q7 > qPrev * 1.15) {
    out.push({ tone: "good", text: `Your practice improved this week — ${q7} questions vs ${qPrev} last week (+${Math.round(((q7 - qPrev) / qPrev) * 100)}%).` });
  } else if (qPrev > 0 && q7 < qPrev * 0.85) {
    out.push({ tone: "warn", text: `Question volume dropped to ${q7} this week (${qPrev} last week). Protect at least one PYQ block daily.` });
  }

  const lecMin = last7.reduce((s, x) => s + x.lecturesDone * 90, 0);
  const qApprox = q7 * 3; // ~3 min/question
  if (lecMin > qApprox * 2 && q7 > 0) {
    out.push({ tone: "warn", text: "Lecture-heavy week: you're spending far more time watching than solving. Swap one lecture slot for a question block." });
  }

  const dueRevs = ctx.revisions.filter(
    (r) => r.status !== "completed" && r.status !== "skipped" && r.dueDate <= today
  );
  if (dueRevs.length > 0) {
    out.push({ tone: dueRevs.length >= 3 ? "bad" : "info", text: `${dueRevs.length} chapter${dueRevs.length > 1 ? "s" : ""} require${dueRevs.length === 1 ? "s" : ""} revision now — ≈${fmtMin(dueRevs.length * 45)} total.` });
  }

  const blNow = backlogItems(ctx, today).length;
  const bl14 = [...m].reverse().find((x) => diffDays(today, x.date) >= 13)?.backlogCount;
  if (bl14 != null && blNow > bl14) {
    out.push({ tone: "bad", text: `Backlog is trending up (${bl14} → ${blNow} pending lectures in 14 days). The backlog plan on /backlog fixes this in ~${backlogPlan(ctx, today).daysNeeded} days.` });
  } else if (blNow > 0) {
    out.push({ tone: "info", text: `Backlog at ${blNow} lectures (≈${fmtMin(backlogPlan(ctx, today).totalMin)}). At the protected daily dose it clears in ${backlogPlan(ctx, today).daysNeeded} days.` });
  }

  const subj = subjectStats(ctx, today);
  const weakest = [...subj].sort((a, b) => a.avgMastery - b.avgMastery)[0];
  if (weakest && weakest.avgMastery > 0) {
    out.push({ tone: "warn", text: `${weakest.name} is your weakest subject (avg mastery ${weakest.avgMastery}%). Bias next week's PYQ blocks toward it.` });
  }
  const h7 = Math.round(last7.reduce((s, x) => s + x.studyMin, 0) / 60);
  out.push({ tone: "info", text: `This week: ${h7}h studied, ${q7} attempted questions, ${last7.reduce((s, x) => s + x.revisionsDone, 0)} revisions.` });
  return out.slice(0, 5);
}

/* ══════════════════════════ AI assistant ══════════════════════════ */

export async function aiAnswer(userId: number, question: string): Promise<string> {
  const ctx = await getContext(userId);
  const today = todayStr();
  const q = question.toLowerCase();
  const stats = completionStats(ctx);
  const bp = backlogPlan(ctx, today);
  const tasks = await tasksFor(userId, today);
  const pending = tasks.filter((t) => t.status === "pending");

  await db.insert(aiMessages).values({ userId, role: "user", content: question });

  let answer: string;

  const numMatch = q.match(/(\d+)\s*(day|din)/);

  if ((q.includes("today") && (q.includes("study") || q.includes("do") || q.includes("plan") || q.includes("aaj"))) || q.includes("what should i")) {
    const top = pending.slice(0, 4);
    answer = `Here's your battle plan for today (${fmtDateFull(today)}):\n\n${top
      .map((t, i) => `**${i + 1}. ${t.title}** · ${fmtMin(t.estMin)}\n_${t.reason}_`)
      .join("\n\n")}\n\nTotal planned: **${fmtMin(tasks.reduce((s, t) => s + t.estMin, 0))}** against your ${fmtMin(ctx.user.dailyMinutes)} capacity. Start with #1 — it has the highest priority score.`;
  } else if (q.includes("backlog") && (q.includes("finish") || q.includes("clear") || q.includes("complete") || numMatch)) {
    const days = numMatch ? parseInt(numMatch[1]) : bp.daysNeeded;
    const possibleDays = bp.daysNeeded;
    const feasible = days >= possibleDays;
    answer = feasible
      ? `**Yes — ${days} days is realistic.**\n\nYou have **${bp.items.length} pending lectures** (≈${fmtMin(bp.totalMin)}).\n\nMy distribution:\n• **${bp.perDay} backlog lectures/day** (≈${fmtMin(bp.perDay * 90)})\n• Running classes protected: ${fmtMin(bp.currentProtected)}/day stays untouched\n• ${fmtMin(105)}/day reserved for revision + practice\n\nAt that pace the backlog clears in **${possibleDays} days** — ${days >= possibleDays ? `inside your ${days}-day window with ${days - possibleDays} spare day(s) as buffer.` : ""}`
      : `**Honestly? ${days} days is too aggressive without burning out.**\n\nYou have **${bp.items.length} pending lectures** (≈${fmtMin(bp.totalMin)}). Clearing them in ${days} days needs ${fmtMin(Math.ceil(bp.totalMin / days))}/day on backlog alone — that would cannibalise your running classes and revision.\n\nMy recommendation: **${bp.perDay}/day for ${possibleDays} days**. If you have a free Sunday, add +2 lectures and it drops to ~${possibleDays - 3} days.`;
  } else if (q.includes("backlog")) {
    const bySubj = ctx.subjects
      .map((s) => {
        const n = bp.items.filter((l) => {
          const ch = ctx.chapters.find((c) => c.id === l.chapterId);
          return ch?.subjectId === s.id;
        }).length;
        return n ? `• ${s.name}: **${n} lectures**` : null;
      })
      .filter(Boolean)
      .join("\n");
    answer = `You currently have **${bp.items.length} backlog lectures** (≈**${fmtMin(bp.totalMin)}**):\n\n${bySubj}\n\nPlan: **${bp.perDay} lectures/day** alongside your running classes → cleared in **${bp.daysNeeded} days**. Open /backlog to apply the distribution automatically.`;
  } else if (q.includes("revise") || q.includes("revision")) {
    const due = ctx.revisions.filter(
      (r) => r.status !== "completed" && r.status !== "skipped" && r.dueDate <= today
    );
    if (due.length === 0) {
      answer = `Your revision queue is clean — nothing due today. Use the spare slot for **PYQs of your oldest completed chapter**. The next revisions arrive automatically on their spaced schedule (1→3→7→15→30 days).`;
    } else {
      answer = `These revisions are due now, in priority order:\n\n${due
        .map((r) => {
          const ch = ctx.chapters.find((c) => c.id === r.chapterId)!;
          const od = Math.max(0, diffDays(today, r.dueDate));
          return `**• Revision ${r.stage} · ${ch.name}** — ${od > 0 ? `overdue ${od}d` : "due today"}`;
        })
        .join("\n")}\n\nDo them before any new lecture today — spaced memory decays fast past the due date.`;
    }
  } else if (q.includes("slow") || q.includes("not improving") || q.includes("stuck")) {
    const ins = generateInsights(ctx, today);
    answer = `I looked at your last 14 days. Here's the diagnosis:\n\n${ins
      .filter((i) => i.tone !== "good")
      .map((i) => `• ${i.text}`)
      .join("\n")}\n\n**Fix for this week:** keep running-class pace, raise question volume to ≥60/day, and never let a due revision slip past 48h.`;
  } else if (q.includes("priorit") || q.includes("which subject") || q.includes("weakest")) {
    const subj = subjectStats(ctx, today).sort((a, b) => a.avgMastery - b.avgMastery);
    answer = `Subject priority ranking, from your live data:\n\n${subj
      .map(
        (s, i) =>
          `**${i + 1}. ${s.name}** — mastery ${s.avgMastery || "—"}%, backlog ${s.backlog}, ${s.weak.length} weak chapter(s)`
      )
      .join("\n")}\n\n**${subj[0].name}** deserves the next PYQ block. ${subj[0].weak.length ? `Start with **${subj[0].weak[0].name}** — weakest chapter there.` : ""}`;
  } else if (q.includes("sunday") || q.includes("tomorrow") || q.includes("plan for")) {
    const target = q.includes("tomorrow") ? addDays(today, 1) : nextDayOfWeek(today, 0);
    await generatePlan(userId, target);
    const tt = (await tasksFor(userId, target)).filter((t) => t.status === "pending");
    answer = `Plan for **${dayName(target)}, ${fmtDate(target)}** — ${fmtMin(tt.reduce((s, t) => s + t.estMin, 0))} total:\n\n${tt
      .slice(0, 6)
      .map((t, i) => `**${i + 1}.** ${t.title} · ${fmtMin(t.estMin)}`)
      .join("\n")}\n\nIt's saved to your Planner. Full grid on /planner.`;
  } else if (q.includes("on track") || q.includes("track") || q.includes("rank")) {
    const g = ctx.goals;
    const daysLeft = g?.examDateMain ? diffDays(g.examDateMain, today) : null;
    answer = `Readiness check:\n\n• Overall preparation: **${stats.readiness}%**\n• Lectures: ${stats.lecturePct}% · Revision: ${stats.revisionPct}% · Practice: ${stats.practicePct}%\n• Avg accuracy: **${stats.avgAcc}%** · Tests attempted: ${stats.attemptedTests}\n${daysLeft != null ? `• JEE Main in **${daysLeft} days** · target rank under **${ctx.goals?.targetRankMain ?? 500}**\n\n` : "\n"}To hit a <${ctx.goals?.targetRankMain ?? 500} rank trajectory you need practice % above 80 by the last 60 days — you're at ${stats.practicePct}%. ${stats.practicePct >= 60 ? "On trajectory if the pace holds." : "Priority: convert watching-time into solving-time this week."}`;
  } else {
    const st = streak(ctx, today);
    answer = `Here's your current snapshot:\n\n• **Readiness ${stats.readiness}%** — lectures ${stats.lecturePct}%, revision ${stats.revisionPct}%, practice ${stats.practicePct}%\n• Backlog: **${bp.items.length} lectures** (clears in ${bp.daysNeeded} days at the protected dose)\n• Revisions due: **${ctx.revisions.filter((r) => r.status !== "completed" && r.dueDate <= today).length}**\n• Streak: **${st} day${st === 1 ? "" : "s"}**\n\nAsk me: "What should I study today?", "Can I clear my backlog in 10 days?", "Which subject should I prioritise?", or "Plan my Sunday".`;
  }

  await db.insert(aiMessages).values({ userId, role: "assistant", content: answer });
  return answer;
}

function nextDayOfWeek(from: string, dow: number): string {
  const d = new Date(from + "T00:00:00");
  const delta = (dow - d.getDay() + 7) % 7 || 7;
  return addDays(from, delta > 7 ? 7 : delta);
}
