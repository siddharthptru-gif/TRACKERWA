import "dotenv/config";
import { db } from "@/db";
import {
  users, batches, subjects, chapters, lectures, practiceItems,
  revisionEvents, tests, studySessions, planTasks, goals, checkins,
  dailyMetrics, weakTopics, aiMessages, userSettings, teachers,
  timetableBlocks, customEvents, errorBook, announcements,
} from "@/db/schema";
import { generatePlan, todayStr, addDays, REVISION_STAGES } from "@/lib/engine";
import { eq } from "drizzle-orm";

/* deterministic RNG so every fresh sandbox gets the same rich dataset */
function mulberry32(a: number) {
  return function () {
    let t = (a += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

type ChSpec = { name: string; w: number };

const PHYSICS: ChSpec[] = [
  { name: "Units, Dimensions & Measurement", w: 2 },
  { name: "Kinematics", w: 3 },
  { name: "Laws of Motion", w: 3 },
  { name: "Work, Energy & Power", w: 4 },
  { name: "Rotational Mechanics", w: 5 },
  { name: "Gravitation", w: 3 },
  { name: "Simple Harmonic Motion", w: 4 },
  { name: "Waves & Sound", w: 4 },
  { name: "Heat & Thermodynamics", w: 5 },
  { name: "Fluid Mechanics", w: 3 },
  { name: "Ray Optics", w: 4 },
  { name: "Wave Optics", w: 3 },
  { name: "Electrostatics", w: 5 },
  { name: "Current Electricity", w: 5 },
  { name: "Magnetism & EMI", w: 4 },
  { name: "Modern Physics", w: 4 },
];

const CHEMISTRY: ChSpec[] = [
  { name: "Mole Concept", w: 4 },
  { name: "Atomic Structure", w: 4 },
  { name: "Periodic Table & Periodicity", w: 3 },
  { name: "Chemical Bonding", w: 5 },
  { name: "Gaseous State", w: 3 },
  { name: "Chemical Thermodynamics", w: 5 },
  { name: "Chemical & Ionic Equilibrium", w: 5 },
  { name: "Redox Reactions", w: 3 },
  { name: "Electrochemistry", w: 5 },
  { name: "Chemical Kinetics", w: 4 },
  { name: "Solutions & Colligative Properties", w: 4 },
  { name: "Coordination Compounds", w: 4 },
  { name: "p-Block Elements", w: 3 },
  { name: "d & f Block Elements", w: 3 },
  { name: "General Organic Chemistry", w: 5 },
  { name: "Hydrocarbons", w: 4 },
  { name: "Alcohols, Phenols & Ethers", w: 4 },
  { name: "Aldehydes & Ketones", w: 5 },
  { name: "Amines", w: 3 },
];

const MATHS: ChSpec[] = [
  { name: "Quadratic Equations", w: 4 },
  { name: "Complex Numbers", w: 4 },
  { name: "Sequences & Series", w: 4 },
  { name: "Permutations & Combinations", w: 4 },
  { name: "Binomial Theorem", w: 3 },
  { name: "Trigonometric Ratios & Identities", w: 3 },
  { name: "Straight Lines", w: 3 },
  { name: "Circles", w: 4 },
  { name: "Conic Sections", w: 5 },
  { name: "Matrices & Determinants", w: 4 },
  { name: "Limits, Continuity & Differentiability", w: 5 },
  { name: "Application of Derivatives", w: 5 },
  { name: "Indefinite Integration", w: 4 },
  { name: "Definite Integration", w: 5 },
  { name: "Area Under Curves", w: 3 },
  { name: "Differential Equations", w: 4 },
  { name: "Vector Algebra", w: 4 },
  { name: "Three Dimensional Geometry", w: 4 },
];

const LEC_SUFFIX = [
  "Concepts & Illustrations",
  "Core Theory",
  "Problem Solving — Level 1",
  "Problem Solving — Level 2",
  "Advanced Patterns",
  "Rank-Booster Questions",
];

const WEAK: { chapter: string; topic: string; severity: number }[] = [
  { chapter: "Rotational Mechanics", topic: "Moment of inertia & parallel axis theorem", severity: 3 },
  { chapter: "Chemical & Ionic Equilibrium", topic: "Salt hydrolysis & buffer solutions", severity: 3 },
  { chapter: "Definite Integration", topic: "King's property applications", severity: 2 },
  { chapter: "Aldehydes & Ketones", topic: "Aldol condensation mechanisms", severity: 2 },
];

export type OnboardingPrefs = {
  name?: string;
  className?: string;
  exam?: string;
  batchName?: string;
  dailyMinutes?: number;
  schoolHours?: string;
  targetRank?: number;
};

export async function seedDemo(prefs: OnboardingPrefs = {}) {
  const rand = mulberry32(42);
  const today = todayStr();

  /* ── wipe all tables (demo reset) ── */
  for (const t of [
    planTasks, aiMessages, checkins, dailyMetrics, studySessions,
    revisionEvents, tests, practiceItems, weakTopics, lectures,
    chapters, subjects, batches, goals, users,
  ]) {
    await db.delete(t as never);
  }

  const [user] = await db.insert(users).values({
    name: prefs.name ?? "Aarav Sharma",
    email: "demo@tracker360.app",
    className: prefs.className ?? "Class 12",
    exam: prefs.exam ?? "JEE Main + Advanced",
    targetRank: prefs.targetRank ?? 500,
    dailyMinutes: prefs.dailyMinutes ?? 420,
    schoolHours: prefs.schoolHours ?? "8:00 AM – 2:00 PM",
    adaptiveLoad: 1,
  }).returning();

  const [batch] = await db.insert(batches).values({
    userId: user.id,
    name: prefs.batchName ?? "Arjuna JEE 2026 — PW Batch",
    exam: prefs.exam ?? "JEE Main + Advanced",
    source: "manual",
  }).returning();

  await db.insert(teachers).values([
    { batchId: batch.id, subjectSlug: "physics", name: "A. Sharma Sir" },
    { batchId: batch.id, subjectSlug: "chemistry", name: "R. Verma Ma'am" },
    { batchId: batch.id, subjectSlug: "mathematics", name: "S. Gupta Sir" },
  ]);

  await db.insert(userSettings).values({
    userId: user.id,
    planningMode: "hybrid",
    planningStyle: "balanced",
    playbackSpeed: 1.5,
    motivation: true,
    revisionIntervals: "1,3,7,15,30,60",
    weeklyMinutes: '{"0":560,"1":330,"2":330,"3":330,"4":330,"5":330,"6":520}',
    paceLectures: 3, paceQuestions: 60, paceRevisions: 1, paceBacklog: 2,
  });

  const [goal] = await db.insert(goals).values({
    userId: user.id,
    dailyMinutes: user.dailyMinutes,
    weeklyQuestions: 450,
    monthlyChapters: 9,
    targetRankMain: prefs.targetRank ?? 500,
    targetRankAdv: (prefs.targetRank ?? 500) * 2 + 200,
    examDateMain: addDays(today, 96),
    examDateAdv: addDays(today, 125),
  }).returning();
  void goal;

  const subjectDefs = [
    { name: "Physics", slug: "physics", color: "#38BDF8", defs: PHYSICS },
    { name: "Chemistry", slug: "chemistry", color: "#A78BFA", defs: CHEMISTRY },
    { name: "Mathematics", slug: "mathematics", color: "#FBBF24", defs: MATHS },
  ];

  let globalOrder = 0;
  const chapterIdByName = new Map<string, number>();
  const completedChapters: { id: number; completedAt: string }[] = [];
  const currentNext: { chapterId: number; title: string }[] = [];
  let backlogCount = 0;

  for (const [si, sd] of subjectDefs.entries()) {
    const [subject] = await db.insert(subjects).values({
      batchId: batch.id, name: sd.name, slug: sd.slug, color: sd.color, position: si,
    }).returning();

    const n = sd.defs.length;
    const completedCount = Math.floor(n * 0.56);
    const backlogChapters = si === 2 ? 2 : 1; // maths carries a heavier backlog
    const currentIdx = completedCount + backlogChapters;

    for (let ci = 0; ci < n; ci++) {
      const spec = sd.defs[ci];
      const isCompleted = ci < completedCount;
      const isBacklogCh = ci >= completedCount && ci < currentIdx;
      const isCurrent = ci === currentIdx;
      const lc = 6 + Math.floor(rand() * 4); // 6–9 lectures

      let status = "not_started";
      let startedAt: string | null = null;
      let completedAt: string | null = null;
      let mastery = 0;

      if (isCompleted) {
        status = "completed";
        completedAt = addDays(today, -(12 + Math.floor(rand() * 95) + (n - ci) * 2));
        startedAt = addDays(completedAt, -(5 + Math.floor(rand() * 6)));
        mastery = 55 + Math.floor(rand() * 38);
      } else if (isCurrent || isBacklogCh) {
        status = "in_progress";
        startedAt = addDays(today, -(isCurrent ? 5 : 12 + Math.floor(rand() * 25)));
        mastery = isCurrent ? 35 : 45;
      }

      const [chapter] = await db.insert(chapters).values({
        subjectId: subject.id,
        name: spec.name,
        position: globalOrder++,
        weightage: spec.w,
        status,
        isCurrent,
        startedAt,
        completedAt,
        notesDone: isCompleted ? rand() < 0.8 : isCurrent,
        mastery,
      }).returning();
      chapterIdByName.set(spec.name, chapter.id);

      /* ── lectures ── */
      for (let li = 0; li < lc; li++) {
        const dur = 75 + Math.floor(rand() * 31);
        let lStatus = "pending";
        let lCompletedAt: Date | null = null;
        let taughtAt: string | null = null;

        if (isCompleted) {
          lStatus = "completed";
          lCompletedAt = new Date(completedAt! + "T18:00:00");
          taughtAt = addDays(startedAt!, li);
        } else if (isCurrent) {
          const doneCount = Math.max(2, Math.floor(lc * 0.4));
          if (li < doneCount) {
            lStatus = "completed";
            taughtAt = addDays(today, -(doneCount - li));
            lCompletedAt = new Date(taughtAt + "T20:00:00");
          } else if (li === doneCount) {
            taughtAt = today; // today's live class
            currentNext.push({ chapterId: chapter.id, title: `${spec.name} L${li + 1}` });
          } else {
            taughtAt = addDays(today, (li - doneCount) * 2); // upcoming classes
          }
        } else if (isBacklogCh) {
          const doneCount = 2 + Math.floor(rand() * 3);
          if (li < doneCount) {
            lStatus = "completed";
            taughtAt = addDays(startedAt!, li);
            lCompletedAt = new Date(taughtAt + "T21:00:00");
          } else {
            taughtAt = addDays(today, -(4 + Math.floor(rand() * 24))); // taught, never watched
            backlogCount++;
          }
        }

        await db.insert(lectures).values({
          chapterId: chapter.id,
          title: `${spec.name} L${li + 1} · ${LEC_SUFFIX[Math.min(li, LEC_SUFFIX.length - 1)]}`,
          position: li,
          durationMin: dur,
          status: lStatus,
          completedAt: lCompletedAt,
          taughtAt,
        });
      }

      /* ── practice items ── */
      const pdefs: { type: string; title: string; total: number }[] = [
        { type: "dpp", title: `DPP · ${spec.name}`, total: 30 },
        { type: "module", title: `PW Module · ${spec.name}`, total: 85 + Math.floor(rand() * 40) },
        { type: "pyq_main", title: `JEE Main PYQs (2019–2025)`, total: 45 },
        { type: "pyq_adv", title: `JEE Advanced PYQs`, total: 25 },
      ];
      for (const pd of pdefs) {
        let pstatus = "not_started";
        let solved = 0;
        let acc: number | null = null;
        if (isCompleted) {
          const roll = rand();
          const completeBias = pd.type === "dpp" ? 0.62 : pd.type === "module" ? 0.5 : pd.type === "pyq_main" ? 0.45 : 0.28;
          if (roll < completeBias * (0.7 + spec.w * 0.08)) {
            pstatus = "completed";
            solved = pd.total;
            acc = 52 + Math.floor(rand() * 33);
          } else if (roll < completeBias + 0.22) {
            pstatus = rand() < 0.25 ? "needs_revision" : "in_progress";
            solved = Math.floor(pd.total * (0.2 + rand() * 0.6));
            acc = 42 + Math.floor(rand() * 30);
            if (acc < 52) pstatus = "weak";
          }
        } else if (isCurrent && pd.type !== "pyq_adv") {
          pstatus = "in_progress";
          solved = Math.floor(pd.total * (0.1 + rand() * 0.25));
          acc = 50 + Math.floor(rand() * 25);
        }
        const correct = acc != null && solved > 0 ? Math.round((solved * acc) / 100) : null;
        await db.insert(practiceItems).values({
          chapterId: chapter.id, type: pd.type, title: pd.title,
          totalQuestions: pd.total, solved, accuracy: acc, status: pstatus,
          correct, incorrect: correct != null ? solved - correct : null,
        });
      }

      if (isCompleted) completedChapters.push({ id: chapter.id, completedAt: completedAt! });
    }
  }

  /* ── revision cycles for completed chapters ── */
  for (const cc of completedChapters) {
    let stageDate = cc.completedAt;
    for (let stage = 1; stage <= 5; stage++) {
      stageDate = addDays(stageDate, REVISION_STAGES[stage - 1]);
      const past = stageDate < today;
      // leave realistic gaps: some due today, some overdue
      const done = past && rand() < 0.94;
      await db.insert(revisionEvents).values({
        chapterId: cc.id,
        stage,
        dueDate: stageDate,
        status: done ? "completed" : past ? "due" : "scheduled",
        completedAt: done ? new Date(stageDate + "T19:00:00") : null,
        score: done ? 58 + Math.floor(rand() * 38) : null,
      });
      if (!done && past) break; // stalled revision blocks later stages
    }
  }

  /* ── tests: 6 attempted + upcoming ── */
  const testMarks = [
    { title: "AITS Part Test 1", phy: 42, chem: 51, math: 38 },
    { title: "AITS Part Test 2", phy: 55, chem: 48, math: 44 },
    { title: "Full Syllabus Mock 1", phy: 49, chem: 60, math: 41 },
    { title: "AITS Part Test 3", phy: 62, chem: 58, math: 50 },
    { title: "AITS Part Test 4", phy: 58, chem: 66, math: 55 },
    { title: "Full Syllabus Mock 2", phy: 66, chem: 63, math: 58 },
  ];
  for (const [i, tm] of testMarks.entries()) {
    const when = addDays(today, -(84 - i * 14));
    const got = tm.phy + tm.chem + tm.math;
    await db.insert(tests).values({
      userId: user.id, title: tm.title,
      type: tm.title.includes("Full") ? "full" : "part",
      scheduledAt: when, attemptedAt: new Date(when + "T14:00:00"),
      totalMarks: 300, obtainedMarks: got,
      physicsMarks: tm.phy, chemistryMarks: tm.chem, mathsMarks: tm.math,
      qAttempted: 62 + Math.floor(rand() * 10), qCorrect: Math.round(got / 4.5),
      qIncorrect: 22 + Math.floor(rand() * 8), qUnattempted: 6 + Math.floor(rand() * 8),
      mConceptual: 5 + Math.floor(rand() * 5), mCalculation: 3 + Math.floor(rand() * 4),
      mSilly: 2 + Math.floor(rand() * 4), mTime: 1 + Math.floor(rand() * 3),
      status: "attempted",
    });
  }
  await db.insert(tests).values({
    userId: user.id, title: "Current Electricity — Chapter Test", type: "chapter",
    subjectId: chapterIdByName.get("Current Electricity") ?? null,
    scheduledAt: addDays(today, -10), attemptedAt: new Date(addDays(today, -10) + "T17:00:00"),
    totalMarks: 100, obtainedMarks: 61, status: "attempted",
  });
  await db.insert(tests).values([
    { userId: user.id, title: "AITS Part Test 5", type: "part", scheduledAt: addDays(today, 2), totalMarks: 300, status: "scheduled" },
    { userId: user.id, title: "Full Syllabus Mock 3", type: "full", scheduledAt: addDays(today, 9), totalMarks: 300, status: "scheduled" },
  ]);

  /* ── weak topics ── */
  const sources = ["AITS Part Test 4", "DPP accuracy < 50%", "Full Syllabus Mock 2", "Self assessment"];
  for (const [i, wk] of WEAK.entries()) {
    const cid = chapterIdByName.get(wk.chapter);
    if (!cid) continue;
    await db.insert(weakTopics).values({
      chapterId: cid, topic: wk.topic, severity: wk.severity, source: sources[i % sources.length],
    });
  }

  /* ── 35 days of daily metrics ── */
  for (let i = 35; i >= 1; i--) {
    const d = addDays(today, -i);
    const missed = (i === 21 || i === 12 || i === 7) && i > 6; // a few missed days, streak recent
    const base = 300 + Math.sin(i / 3.5) * 70 + rand() * 90;
    const studyMin = missed ? 0 : Math.round(base);
    const questions = missed ? 0 : Math.round(studyMin / 6.5 + rand() * 25);
    const accuracy = missed ? 0 : Math.round(54 + (35 - i) * 0.5 + rand() * 8);
    const bl = Math.max(
      backlogCount - 2,
      Math.round(31 - (35 - i) * 0.28 + Math.sin(i / 2.5) * 2)
    );
    await db.insert(dailyMetrics).values({
      userId: user.id, date: d,
      studyMin, questions, accuracy,
      backlogCount: bl,
      lecturesDone: missed ? 0 : 2 + Math.floor(rand() * 3),
      revisionsDone: missed ? 0 : Math.floor(rand() * 3),
    });
    if (!missed) {
      await db.insert(studySessions).values({
        userId: user.id, date: d, minutes: studyMin, kind: "study", quality: 2 + Math.floor(rand() * 4),
      });
    }
  }

  /* ── timetable blocks (a real dummy-student day) ── */
  const dayBlocks = [
    { dayOfWeek: -1, startMin: 330, endMin: 360, kind: "other", label: "Wake up + freshen up", fixed: true },
    { dayOfWeek: -1, startMin: 360, endMin: 420, kind: "personal", label: "Exercise + breakfast", fixed: true },
    { dayOfWeek: -1, startMin: 750, endMin: 810, kind: "meal", label: "Lunch", fixed: true },
    { dayOfWeek: -1, startMin: 960, endMin: 1020, kind: "pw_class", label: "PW live class (batch)", fixed: true },
    { dayOfWeek: -1, startMin: 1200, endMin: 1230, kind: "meal", label: "Dinner", fixed: true },
    { dayOfWeek: -1, startMin: 420, endMin: 600, kind: "study", label: "Deep study block", fixed: false, focus: "high" },
    { dayOfWeek: -1, startMin: 830, endMin: 950, kind: "study", label: "Practice block", fixed: false, focus: "medium" },
    { dayOfWeek: -1, startMin: 1030, endMin: 1170, kind: "study", label: "Evening study", fixed: false, focus: "medium" },
    { dayOfWeek: -1, startMin: 1230, endMin: 1260, kind: "study", label: "Formula recall (low energy)", fixed: false, focus: "low" },
  ];
  for (const b of dayBlocks) {
    if (b.kind === "sleep") continue;
    await db.insert(timetableBlocks).values({
      userId: user.id, dayOfWeek: b.dayOfWeek, startMin: b.startMin, endMin: b.endMin,
      kind: b.kind, label: b.label, fixed: b.fixed, focus: (b as { focus?: string }).focus ?? "any",
    });
  }
  await db.insert(timetableBlocks).values({ userId: user.id, dayOfWeek: -1, startMin: 1380, endMin: 1439, kind: "sleep", label: "Sleep", fixed: true });

  /* ── custom events ── */
  await db.insert(customEvents).values([
    { userId: user.id, date: addDays(today, 5), label: "Family function", kind: "function", availableMinutes: 120 },
    { userId: user.id, date: addDays(today, 12), label: "School unit test week starts", kind: "school_exam", availableMinutes: 180 },
  ]);

  /* ── error book ── */
  const errChapters = ["Rotational Mechanics", "Chemical & Ionic Equilibrium", "Definite Integration"];
  const errData = [
    { q: "MI of a disc about tangent — used wrong axis in parallel-axis shift", t: "conceptual", c: "I_tangent = I_cm + Md² with d = R for tangent in plane" },
    { q: "Buffer pH came out inverted — mixed up Henderson equation ratio", t: "formula", c: "pH = pKa + log([salt]/[acid])" },
    { q: "Definite integral sign error after King's property substitution", t: "calculation", c: "Re-check limits after x → a+b−x transform" },
  ];
  for (const [i, e] of errData.entries()) {
    const cid = chapterIdByName.get(errChapters[i]);
    if (!cid) continue;
    const ch = (await db.select().from(chapters)).find((c) => c.id === cid);
    await db.insert(errorBook).values({
      userId: user.id, chapterId: cid, subjectId: ch?.subjectId ?? null,
      question: e.q, mistakeType: e.t, correctConcept: e.c,
      status: i === 0 ? "reattempt_scheduled" : "open",
      reattemptDate: i === 0 ? addDays(today, 2) : null,
    });
  }

  await db.insert(announcements).values({
    text: "AITS Part Test 5 this Sunday — syllabus: full Mechanics + Mole Concept + Quadratic & Complex Numbers. Prep blocks are auto-added 3 days out.",
  });

  /* ── today's initial plan ── */
  await generatePlan(user.id, today);

  // promise the top two tasks + make one current-chapter lecture partially watched
  const todays = await db.select().from(planTasks).where(eq(planTasks.userId, user.id));
  const top2 = todays.filter((t) => t.date === today).sort((a, b) => b.priority - a.priority).slice(0, 2);
  for (const t of top2) await db.update(planTasks).set({ promised: true }).where(eq(planTasks.id, t.id));

  const currentLec = await db.select().from(lectures);
  const partial = currentLec.find((l) => l.taughtAt === today && l.status === "pending");
  if (partial) {
    await db.update(lectures).set({ watchedPct: 42, watchedMin: Math.round(partial.durationMin * 0.42), status: "partial" })
      .where(eq(lectures.id, partial.id));
    await generatePlan(user.id, today); // recompute with resume-aware estimates
    const regen = await db.select().from(planTasks).where(eq(planTasks.userId, user.id));
    for (const t of regen.filter((t) => t.date === today).sort((a, b) => b.priority - a.priority).slice(0, 2)) {
      await db.update(planTasks).set({ promised: true }).where(eq(planTasks.id, t.id));
    }
  }

  return { userId: user.id };
}

/* runnable directly: npx tsx src/db/seed.ts */
const isMain = process.argv[1] && process.argv[1].replace(/\\/g, "/").endsWith("src/db/seed.ts");
if (isMain) {
  seedDemo()
    .then((r) => {
      console.log("seeded demo dataset, userId =", r.userId);
      process.exit(0);
    })
    .catch((e) => {
      console.error(e);
      process.exit(1);
    });
}
