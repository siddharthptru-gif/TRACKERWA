import {
  pgTable,
  serial,
  integer,
  text,
  timestamp,
  date,
  boolean,
  real,
} from "drizzle-orm/pg-core";

/* ───────────────────────────── identity ───────────────────────────── */

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  className: text("class_name").notNull().default("Class 12"),
  exam: text("exam").notNull().default("JEE Main + Advanced"),
  targetRank: integer("target_rank").notNull().default(500),
  dailyMinutes: integer("daily_minutes").notNull().default(420),
  schoolHours: text("school_hours").notNull().default("8:00 AM – 2:00 PM"),
  adaptiveLoad: real("adaptive_load").notNull().default(1),
  studentType: text("student_type").notNull().default("dummy"), // school | dummy | dropper | college | self | other
  targetYear: integer("target_year").notNull().default(2026),
  photoUrl: text("photo_url"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});

/* every knob the deterministic planner respects */
export const userSettings = pgTable("user_settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  planningMode: text("planning_mode").notNull().default("hybrid"), // auto | manual | hybrid
  planningStyle: text("planning_style").notNull().default("balanced"), // balanced | backlog | current | revision | practice | exam
  playbackSpeed: real("playback_speed").notNull().default(1.5),
  motivation: boolean("motivation").notNull().default(true),
  revisionIntervals: text("revision_intervals").notNull().default("1,3,7,15,30,60"),
  // minutes available per weekday 0=Sun..6=Sat (JSON)
  weeklyMinutes: text("weekly_minutes")
    .notNull()
    .default('{"0":540,"1":360,"2":360,"3":360,"4":360,"5":360,"6":480}'),
  priorityOrder: text("priority_order")
    .notNull()
    .default("class,revision,dpp,test,backlog,practice,pyq,optional"),
  // pace targets per day
  paceLectures: integer("pace_lectures").notNull().default(3),
  paceQuestions: integer("pace_questions").notNull().default(60),
  paceRevisions: integer("pace_revisions").notNull().default(1),
  paceBacklog: integer("pace_backlog").notNull().default(2),
});

export const batches = pgTable("batches", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  exam: text("exam").notNull().default("JEE Main + Advanced"),
  source: text("source").notNull().default("manual"), // pw_authorized | manual | imported
  syncedAt: timestamp("synced_at", { withTimezone: true }).defaultNow(),
});

export const teachers = pgTable("teachers", {
  id: serial("id").primaryKey(),
  batchId: integer("batch_id").notNull(),
  subjectSlug: text("subject_slug").notNull(),
  name: text("name").notNull(),
});

/* ───────────────────────────── syllabus ───────────────────────────── */

export const subjects = pgTable("subjects", {
  id: serial("id").primaryKey(),
  batchId: integer("batch_id").notNull(),
  name: text("name").notNull(),
  slug: text("slug").notNull(),
  color: text("color").notNull().default("#38BDF8"),
  position: integer("position").notNull().default(0),
});

export const chapters = pgTable("chapters", {
  id: serial("id").primaryKey(),
  subjectId: integer("subject_id").notNull(),
  name: text("name").notNull(),
  position: integer("position").notNull().default(0),
  weightage: integer("weightage").notNull().default(3),
  status: text("status").notNull().default("not_started"),
  isCurrent: boolean("is_current").notNull().default(false),
  startedAt: date("started_at", { mode: "string" }),
  completedAt: date("completed_at", { mode: "string" }),
  notesDone: boolean("notes_done").notNull().default(false),
  mastery: integer("mastery").notNull().default(0),
  prepOverride: integer("prep_override"), // manual chapter prep % override
  manualLevel: text("manual_level"), // weak | average | strong | mastered
});

export const lectures = pgTable("lectures", {
  id: serial("id").primaryKey(),
  chapterId: integer("chapter_id").notNull(),
  title: text("title").notNull(),
  position: integer("position").notNull().default(0),
  durationMin: integer("duration_min").notNull().default(90),
  status: text("status").notNull().default("pending"), // pending | partial | completed | skipped
  watchedPct: real("watched_pct").notNull().default(0),
  watchedMin: integer("watched_min").notNull().default(0),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  taughtAt: date("taught_at", { mode: "string" }),
  source: text("source").notNull().default("manual"),
});

/* ───────────────────────────── practice ───────────────────────────── */

export const practiceItems = pgTable("practice_items", {
  id: serial("id").primaryKey(),
  chapterId: integer("chapter_id").notNull(),
  type: text("type").notNull(), // dpp | module | pyq_main | pyq_adv
  title: text("title").notNull(),
  totalQuestions: integer("total_questions").notNull().default(30),
  solved: integer("solved").notNull().default(0),
  correct: integer("correct"),
  incorrect: integer("incorrect"),
  accuracy: real("accuracy"),
  status: text("status").notNull().default("not_started"), // not_started | in_progress | completed | weak | needs_revision
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});

/* ───────────────────────────── revision ───────────────────────────── */

export const revisionEvents = pgTable("revision_events", {
  id: serial("id").primaryKey(),
  chapterId: integer("chapter_id").notNull(),
  stage: integer("stage").notNull().default(1),
  dueDate: date("due_date", { mode: "string" }).notNull(),
  status: text("status").notNull().default("scheduled"), // scheduled | due | completed | skipped
  completedAt: timestamp("completed_at", { withTimezone: true }),
  score: real("score"), // recall 0–100
  feedback: text("feedback"), // forgot | weak | average | good | excellent
});

/* ───────────────────────────── tests ───────────────────────────── */

export const tests = pgTable("tests", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  subjectId: integer("subject_id"),
  title: text("title").notNull(),
  type: text("type").notNull().default("part"), // chapter | part | subject | full | mock
  scheduledAt: date("scheduled_at", { mode: "string" }).notNull(),
  attemptedAt: timestamp("attempted_at", { withTimezone: true }),
  totalMarks: integer("total_marks").notNull().default(300),
  obtainedMarks: integer("obtained_marks"),
  physicsMarks: integer("physics_marks"),
  chemistryMarks: integer("chemistry_marks"),
  mathsMarks: integer("maths_marks"),
  qAttempted: integer("q_attempted"),
  qCorrect: integer("q_correct"),
  qIncorrect: integer("q_incorrect"),
  qUnattempted: integer("q_unattempted"),
  mConceptual: integer("m_conceptual"),
  mCalculation: integer("m_calculation"),
  mSilly: integer("m_silly"),
  mTime: integer("m_time"),
  status: text("status").notNull().default("scheduled"), // scheduled | attempted | missed | rescheduled
});

/* ───────────────────────────── life constraints ───────────────────────────── */

export const timetableBlocks = pgTable("timetable_blocks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  dayOfWeek: integer("day_of_week").notNull().default(-1), // -1 = every day
  startMin: integer("start_min").notNull(), // minutes from midnight
  endMin: integer("end_min").notNull(),
  kind: text("kind").notNull(), // sleep | school | college | travel | meal | pw_class | coaching | study | break | exercise | personal | other
  label: text("label").notNull(),
  fixed: boolean("fixed").notNull().default(true), // fixed blocks are never overwritten by planner
  focus: text("focus").notNull().default("any"), // high | medium | low | any (study blocks)
});

export const customEvents = pgTable("custom_events", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  date: date("date", { mode: "string" }).notNull(),
  label: text("label").notNull(),
  kind: text("kind").notNull().default("holiday"), // holiday | sick | travel | function | school_exam | rest
  availableMinutes: integer("available_minutes").notNull().default(0),
});

/* ───────────────────────────── execution ───────────────────────────── */

export const studySessions = pgTable("study_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  date: date("date", { mode: "string" }).notNull(),
  minutes: integer("minutes").notNull().default(0),
  kind: text("kind").notNull().default("study"),
  quality: integer("quality").notNull().default(3),
  taskId: integer("task_id"),
  startedAt: timestamp("started_at", { withTimezone: true }),
  endedAt: timestamp("ended_at", { withTimezone: true }),
  note: text("note"),
});

export const planTasks = pgTable("plan_tasks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  date: date("date", { mode: "string" }).notNull(),
  title: text("title").notNull(),
  kind: text("kind").notNull(),
  refType: text("ref_type"),
  refId: integer("ref_id"),
  subjectId: integer("subject_id"),
  estMin: integer("est_min").notNull().default(60),
  priority: integer("priority").notNull().default(50),
  status: text("status").notNull().default("pending"), // pending | done | skipped
  reason: text("reason").notNull().default(""),
  position: integer("position").notNull().default(0),
  generated: boolean("generated").notNull().default(true),
  promised: boolean("promised").notNull().default(false),
  source: text("source").notNull().default("engine"), // engine | manual | killer | recovery
});

export const errorBook = pgTable("error_book", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  subjectId: integer("subject_id"),
  chapterId: integer("chapter_id"),
  question: text("question").notNull(),
  mistakeType: text("mistake_type").notNull().default("conceptual"), // conceptual | calculation | silly | formula | reading | time | guess
  correctConcept: text("correct_concept"),
  status: text("status").notNull().default("open"), // open | reattempt_scheduled | mastered
  reattemptDate: date("reattempt_date", { mode: "string" }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});

/* ───────────────────────────── goals & check-ins ───────────────────────────── */

export const goals = pgTable("goals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  dailyMinutes: integer("daily_minutes").notNull().default(420),
  weeklyQuestions: integer("weekly_questions").notNull().default(450),
  monthlyChapters: integer("monthly_chapters").notNull().default(9),
  targetRankMain: integer("target_rank_main").notNull().default(500),
  targetRankAdv: integer("target_rank_adv").notNull().default(1200),
  examDateMain: date("exam_date_main", { mode: "string" }),
  examDateAdv: date("exam_date_adv", { mode: "string" }),
});

export const checkins = pgTable("checkins", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  date: date("date", { mode: "string" }).notNull(),
  minutes: integer("minutes").notNull().default(0),
  lecturesDone: integer("lectures_done").notNull().default(0),
  questionsSolved: integer("questions_solved").notNull().default(0),
  revisionsDone: integer("revisions_done").notNull().default(0),
  testsAttempted: integer("tests_attempted").notNull().default(0),
  energy: integer("energy").notNull().default(3),
  note: text("note"),
  completionRate: real("completion_rate").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});

export const dailyMetrics = pgTable("daily_metrics", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  date: date("date", { mode: "string" }).notNull(),
  studyMin: integer("study_min").notNull().default(0),
  questions: integer("questions").notNull().default(0),
  accuracy: real("accuracy").notNull().default(0),
  backlogCount: integer("backlog_count").notNull().default(0),
  lecturesDone: integer("lectures_done").notNull().default(0),
  revisionsDone: integer("revisions_done").notNull().default(0),
});

export const weakTopics = pgTable("weak_topics", {
  id: serial("id").primaryKey(),
  chapterId: integer("chapter_id").notNull(),
  topic: text("topic").notNull(),
  severity: integer("severity").notNull().default(2),
  source: text("source").notNull().default("test analysis"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  resolvedAt: timestamp("resolved_at", { withTimezone: true }),
});

export const aiMessages = pgTable("ai_messages", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  role: text("role").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});

/* global announcements managed from the admin panel */
export const announcements = pgTable("announcements", {
  id: serial("id").primaryKey(),
  text: text("text").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});
