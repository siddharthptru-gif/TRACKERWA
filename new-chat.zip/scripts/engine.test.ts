/*
 * Tracker 360 — deterministic engine test suite
 * Run: npx tsx scripts/engine.test.ts
 * Tests pure planning/revision/backlog logic with crafted fixtures (no DB needed for pure fns;
 * DB-backed integration checks are skipped when DATABASE_URL is absent).
 */
import "dotenv/config";
import assert from "node:assert";
import {
  nextRevisionPlan, recallBand, parseIntervals, viewMin, availableMinutesFor,
  clamp, todayStr, addDays, diffDays, type Ctx,
} from "../src/lib/engine";
import {
  backlogKiller, backlogBreakdown, nowRecommendation, preparationHealth,
  chapterPrepBreakdown, prepLevelLabel, quoteOfDay,
} from "../src/lib/ops";

let passed = 0;
const t = (name: string, fn: () => void) => {
  try { fn(); passed++; console.log(`  ✓ ${name}`); }
  catch (e) { console.error(`  ✗ ${name}\n    ${(e as Error).message}`); process.exitCode = 1; }
};

/* ── minimal ctx fixture ── */
function makeCtx(overrides: Partial<Ctx> = {}): Ctx {
  const today = todayStr();
  const base: any = {
    user: {
      id: 1, name: "Test Student", email: "t@t.dev", className: "Class 12",
      exam: "JEE", targetRank: 500, dailyMinutes: 420, schoolHours: "",
      adaptiveLoad: 1, studentType: "dummy", targetYear: 2026, photoUrl: null, createdAt: null,
    },
    batch: null,
    subjects: [
      { id: 1, batchId: 1, name: "Physics", slug: "physics", color: "#38BDF8", position: 0 },
      { id: 2, batchId: 1, name: "Chemistry", slug: "chemistry", color: "#A78BFA", position: 1 },
    ],
    chapters: [
      { id: 10, subjectId: 1, name: "Kinematics", position: 0, weightage: 3, status: "completed", isCurrent: false, startedAt: addDays(today, -60), completedAt: addDays(today, -20), notesDone: true, mastery: 70, prepOverride: null, manualLevel: null },
      { id: 11, subjectId: 1, name: "NLM", position: 1, weightage: 4, status: "in_progress", isCurrent: true, startedAt: addDays(today, -4), completedAt: null, notesDone: true, mastery: 35, prepOverride: null, manualLevel: null },
      { id: 12, subjectId: 1, name: "WEP", position: 2, weightage: 4, status: "in_progress", isCurrent: false, startedAt: addDays(today, -15), completedAt: null, notesDone: false, mastery: 45, prepOverride: null, manualLevel: null },
      { id: 13, subjectId: 2, name: "Mole Concept", position: 3, weightage: 4, status: "not_started", isCurrent: false, startedAt: null, completedAt: null, notesDone: false, mastery: 0, prepOverride: null, manualLevel: null },
    ],
    lectures: [
      { id: 100, chapterId: 10, title: "Kin L1", position: 0, durationMin: 90, status: "completed", watchedPct: 100, watchedMin: 90, completedAt: new Date(), taughtAt: addDays(today, -50), source: "manual" },
      { id: 101, chapterId: 10, title: "Kin L2", position: 1, durationMin: 90, status: "completed", watchedPct: 100, watchedMin: 90, completedAt: new Date(), taughtAt: addDays(today, -49), source: "manual" },
      { id: 102, chapterId: 11, title: "NLM L1", position: 0, durationMin: 100, status: "completed", watchedPct: 100, watchedMin: 100, completedAt: new Date(), taughtAt: addDays(today, -2), source: "manual" },
      { id: 103, chapterId: 11, title: "NLM L2", position: 1, durationMin: 120, status: "partial", watchedPct: 50, watchedMin: 60, completedAt: null, taughtAt: today, source: "manual" },
      { id: 104, chapterId: 12, title: "WEP L1", position: 0, durationMin: 90, status: "pending", watchedPct: 0, watchedMin: 0, completedAt: null, taughtAt: addDays(today, -10), source: "manual" },
      { id: 105, chapterId: 12, title: "WEP L2", position: 1, durationMin: 90, status: "pending", watchedPct: 0, watchedMin: 0, completedAt: null, taughtAt: addDays(today, -8), source: "manual" },
      { id: 106, chapterId: 12, title: "WEP L3", position: 2, durationMin: 90, status: "pending", watchedPct: 25, watchedMin: 22, completedAt: null, taughtAt: addDays(today, -5), source: "manual" },
    ],
    practice: [
      { id: 200, chapterId: 10, type: "dpp", title: "DPP Kin", totalQuestions: 30, solved: 30, correct: 22, incorrect: 8, accuracy: 73, status: "completed", updatedAt: null },
      { id: 201, chapterId: 10, type: "pyq_main", title: "PYQ Kin", totalQuestions: 45, solved: 10, correct: null, incorrect: null, accuracy: null, status: "in_progress", updatedAt: null },
    ],
    revisions: [
      { id: 300, chapterId: 10, stage: 2, dueDate: addDays(today, -1), status: "due", completedAt: null, score: null, feedback: null },
    ],
    tests: [],
    goals: null,
    metrics: Array.from({ length: 15 }, (_, i) => ({
      id: 400 + i, userId: 1, date: addDays(today, -(14 - i)),
      studyMin: 300, questions: 60, accuracy: 65, backlogCount: 20 - i, lecturesDone: 2, revisionsDone: 1,
    })),
    weakTopics: [],
    checkins: [],
    settings: {
      id: 1, userId: 1, planningMode: "hybrid", planningStyle: "balanced", playbackSpeed: 1.5,
      motivation: true, revisionIntervals: "1,3,7,15,30,60",
      weeklyMinutes: '{"0":540,"1":360,"2":360,"3":360,"4":360,"5":360,"6":480}',
      priorityOrder: "class,revision,dpp,test,backlog,practice,pyq,optional",
      paceLectures: 3, paceQuestions: 60, paceRevisions: 1, paceBacklog: 2,
    },
    blocks: [], events: [], errorBook: [], announcements: [], teachers: [],
    playbackSpeed: 1.5, revisionIntervals: [1, 3, 7, 15, 30, 60],
  };
  return { ...base, ...overrides } as Ctx;
}

console.log("\nRevision engine");
t("recall bands are deterministic", () => {
  assert.equal(recallBand(10), "forgot");
  assert.equal(recallBand(45), "weak");
  assert.equal(recallBand(60), "average");
  assert.equal(recallBand(85), "good");
  assert.equal(recallBand(100), "excellent");
});
t("forgot → regress two stages, due tomorrow", () => {
  const p = nextRevisionPlan(4, 15, [1, 3, 7, 15, 30, 60]);
  assert.deepEqual(p, { nextStage: 2, days: 1 });
});
t("weak → regress two stages, due in 2 days", () => {
  const p = nextRevisionPlan(3, 40, [1, 3, 7, 15, 30, 60]);
  assert.deepEqual(p, { nextStage: 1, days: 2 });
});
t("average → standard next interval", () => {
  assert.deepEqual(nextRevisionPlan(2, 60, [1, 3, 7, 15, 30, 60]), { nextStage: 3, days: 7 });
});
t("good → interval ×1.3, excellent → ×1.6 (rounded, min 1)", () => {
  assert.deepEqual(nextRevisionPlan(1, 80, [1, 3, 7, 15, 30, 60]), { nextStage: 2, days: Math.round(3 * 1.3) });
  assert.deepEqual(nextRevisionPlan(1, 95, [1, 3, 7, 15, 30, 60]), { nextStage: 2, days: Math.round(3 * 1.6) });
});
t("final stage complete → no new revision", () => {
  assert.equal(nextRevisionPlan(6, 70, [1, 3, 7, 15, 30, 60]), null);
});
t("custom intervals are respected", () => {
  assert.deepEqual(nextRevisionPlan(1, 60, [2, 5, 12]), { nextStage: 2, days: 5 });
  assert.deepEqual(parseIntervals("2,5,12"), [2, 5, 12]);
  assert.deepEqual(parseIntervals("garbage"), [1, 3, 7, 15, 30, 60]);
});

console.log("\nTime math");
t("playback speed adjusts estimates", () => {
  assert.equal(viewMin(120, 2), 60);
  assert.equal(viewMin(90, 1.5), 60);
  assert.equal(viewMin(90, 1), 90);
  assert.equal(viewMin(91, 1.5), 61); // ceil
});
t("capacity: weekday hours × adaptive load, event override, floor 0", () => {
  const ctx = makeCtx();
  const mon = "2026-03-02"; // a Monday
  assert.equal(new Date(mon + "T00:00:00").getDay(), 1);
  assert.equal(availableMinutesFor(ctx, mon), 360);
  const loaded = makeCtx();
  loaded.user = { ...loaded.user, adaptiveLoad: 0.5 } as Ctx["user"];
  assert.equal(availableMinutesFor(loaded, mon), 180);
  const ev = makeCtx();
  ev.events = [{ id: 1, userId: 1, date: mon, label: "sick", kind: "sick", availableMinutes: 60 } as Ctx["events"][number]];
  assert.equal(availableMinutesFor(ev, mon), 60);
});
t("date helpers are timezone-safe", () => {
  assert.equal(diffDays(addDays("2026-01-01", 5), "2026-01-01"), 5);
  assert.equal(addDays("2026-12-31", 1), "2027-01-01");
});

console.log("\nBacklog breakdown (typed, time-weighted)");
t("partial-watched backlog lectures count remaining time only", () => {
  const ctx = makeCtx();
  const bd = backlogBreakdown(ctx, todayStr());
  const lec = bd.slices.find((s) => s.key === "lecture")!;
  assert.equal(lec.count, 3); // WEP L1, L2, L3
  // L1: 90/1.5=60, L2: 60, L3: ceil(67.5/1.5)=45 → 165
  assert.equal(lec.minutes, viewMin(90, 1.5) + viewMin(90, 1.5) + viewMin(Math.ceil(90 * 0.75), 1.5));
});
t("revision backlog counts due+overdue at 45min each", () => {
  const bd = backlogBreakdown(makeCtx(), todayStr());
  const rev = bd.slices.find((s) => s.key === "revision")!;
  assert.equal(rev.count, 1);
  assert.equal(rev.minutes, 45);
});
t("not-started chapters and current chapters never become backlog", () => {
  const ctx = makeCtx();
  ctx.lectures.push({ id: 107, chapterId: 13, title: "Mole L1", position: 0, durationMin: 90, status: "pending", watchedPct: 0, watchedMin: 0, completedAt: null, taughtAt: addDays(todayStr(), -30), source: "manual" } as Ctx["lectures"][number]);
  ctx.lectures.push({ id: 108, chapterId: 11, title: "NLM L3", position: 2, durationMin: 90, status: "pending", watchedPct: 0, watchedMin: 0, completedAt: null, taughtAt: addDays(todayStr(), -1), source: "manual" } as Ctx["lectures"][number]);
  const bd = backlogBreakdown(ctx, todayStr());
  assert.equal(bd.slices.find((s) => s.key === "lecture")!.count, 3);
});

console.log("\nBacklog Killer");
t("feasibility is honest and plan never exceeds window", () => {
  const ctx = makeCtx();
  const kp = backlogKiller(ctx, todayStr(), 7, "aggressive");
  assert.ok(kp.rows.length <= 7);
  assert.equal(typeof kp.feasible, "boolean");
  assert.ok(kp.dailyBacklogMin <= ctx.user.dailyMinutes);
  assert.ok(kp.protectedMin > 0); // current batch protected
});
t("aggressive mode clears more per day than safe", () => {
  const ctx = makeCtx();
  const safe = backlogKiller(ctx, todayStr(), 14, "safe");
  const agg = backlogKiller(ctx, todayStr(), 14, "aggressive");
  assert.ok(agg.dailyBacklogMin > safe.dailyBacklogMin);
});
t("killer rows never create impossible schedules", () => {
  const ctx = makeCtx();
  const kp = backlogKiller(ctx, todayStr(), 30, "aggressive");
  for (const r of kp.rows) {
    assert.ok(r.minutes <= ctx.user.dailyMinutes, `day ${r.date} overflow`);
    for (const it of r.items) assert.ok(it.minutes > 0);
  }
});

console.log("\nNOW engine");
t("selects exactly one highest-scored pending task and explains why", () => {
  const ctx = makeCtx();
  const tasks = [
    { id: 1, title: "A", kind: "lecture", estMin: 90, priority: 97, status: "pending", reason: "running class" },
    { id: 2, title: "B", kind: "revision", estMin: 45, priority: 88, status: "pending", reason: "due" },
    { id: 3, title: "C", kind: "pyq", estMin: 45, priority: 40, status: "pending", reason: "pyq" },
  ];
  const rec = nowRecommendation(ctx, tasks, todayStr());
  assert.ok(rec.task);
  assert.ok(rec.explain.length > 20);
  assert.ok(rec.task!.priority >= 88);
});
t("all-done state redirects to PYQ advice", () => {
  const rec = nowRecommendation(makeCtx(), [{ id: 1, title: "A", kind: "lecture", estMin: 90, priority: 97, status: "done", reason: "" }], todayStr());
  assert.equal(rec.task, null);
  assert.match(rec.headline, /complete/i);
});

console.log("\nPrep meters & health");
t("chapter prep breakdown weights all components and respects manual override", () => {
  const ctx = makeCtx();
  const prep = chapterPrepBreakdown(ctx, 10);
  assert.equal(prep.lectures, 100);
  assert.ok(prep.total >= 40 && prep.total <= 100);
  assert.equal(prepLevelLabel(0), "Not started");
  assert.equal(prepLevelLabel(80), "Strong");
  assert.equal(prepLevelLabel(100), "Complete");
  const o = makeCtx();
  const ch = o.chapters.find((c) => c.id === 10)!;
  (ch as { prepOverride: number | null }).prepOverride = 42;
  assert.equal(chapterPrepBreakdown(o, 10).total, 42);
});
t("health response includes score, label and reasons", () => {
  const h = preparationHealth(makeCtx(), todayStr());
  assert.ok(h.score >= 5 && h.score <= 98);
  assert.ok(["Excellent", "Good", "Stable", "At Risk", "Critical"].includes(h.label));
  assert.ok(h.reasons.length >= 1);
});
t("motivation is deterministic per day and respects the off switch", () => {
  const d = todayStr();
  assert.equal(quoteOfDay(d, true), quoteOfDay(d, true));
  assert.equal(quoteOfDay(d, false), null);
});

console.log(`\n${passed} checks ${process.exitCode ? "FAILED" : "passed"}\n`);
